import React from "react";
import { BrowserRouter as Router, useRoutes } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";

// Import pages
import StudentDashboard from "./pages/student-dashboard";
import ApplicantReviewPage from "./pages/applicant-review-page";
import ProjectApplicationPage from "./pages/project-application-page";
import FacultyDashboard from "./pages/faculty-dashboard";
import ProjectSearchPage from "./pages/project-search-page";
import FacultyProfile from "./pages/faculty-profile";
import StudentProfile from "./pages/student-profile";
import LandingPage from "./pages/landing-page";
import AuthenticationPage from "./pages/authentication-page";
import MeetingScheduler from "./pages/meeting-scheduler";

const ProjectRoutes = () => {
  let element = useRoutes([
    { path: "/", element: <StudentDashboard /> },
    { path: "/student-dashboard", element: <StudentDashboard /> },
    { path: "/applicant-review-page", element: <ApplicantReviewPage /> },
    { path: "/applicant-review-page/:id", element: <ApplicantReviewPage /> },
    { path: "/project-application-page", element: <ProjectApplicationPage /> },
    { path: "/faculty-dashboard", element: <FacultyDashboard /> },
    { path: "/project-search-page", element: <ProjectSearchPage /> },
    { path: "/faculty-profile", element: <FacultyProfile /> },
    { path: "/student-profile", element: <StudentProfile /> },
    { path: "/landing-page", element: <LandingPage /> },
    { path: "/authentication-page", element: <AuthenticationPage /> },
    { path: "/meeting-scheduler", element: <MeetingScheduler /> },
  ]);

  return element;
};

const Routes = () => {
  return (
    <Router>
      <ScrollToTop />
      <ProjectRoutes />
    </Router>
  );
};

export default Routes;