import React from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";

const ProfileCompletion = ({ userData }) => {
  // Calculate what's missing from the profile
  const missingItems = [];
  
  if (!userData.resumeUploaded) {
    missingItems.push({
      name: "Resume",
      icon: "FileText",
      link: "/student-profile",
    });
  }
  
  if (!userData.githubLink) {
    missingItems.push({
      name: "GitHub Profile",
      icon: "Github",
      link: "/student-profile",
    });
  }
  
  if (!userData.linkedinLink) {
    missingItems.push({
      name: "LinkedIn Profile",
      icon: "Linkedin",
      link: "/student-profile",
    });
  }

  // Stats for the dashboard
  const stats = [
    {
      name: "Applied Projects",
      value: 4,
      icon: "ClipboardList",
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
    {
      name: "Shortlisted",
      value: 1,
      icon: "ListChecks",
      color: "text-warning",
      bgColor: "bg-warning-light",
    },
    {
      name: "Selected",
      value: 1,
      icon: "CheckCircle",
      color: "text-success",
      bgColor: "bg-success-light",
    },
    {
      name: "Upcoming Meetings",
      value: 2,
      icon: "Calendar",
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
  ];

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Profile Completion
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Complete your profile to increase your chances of being selected.
            </p>
          </div>
          <div className="mt-4 sm:mt-0">
            <Link
              to="/student-profile"
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Edit" size={16} className="mr-2" />
              Edit Profile
            </Link>
          </div>
        </div>

        <div className="mt-6">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-sm font-medium text-gray-700">
                  {userData.profileCompletion}% Complete
                </span>
                {userData.profileCompletion === 100 && (
                  <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-light text-success">
                    <Icon name="Check" size={12} className="mr-1" />
                    Complete
                  </span>
                )}
              </div>
              <span className="text-sm text-gray-500">
                {userData.profileCompletion}/100
              </span>
            </div>
            <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-primary h-2.5 rounded-full"
                style={{ width: `${userData.profileCompletion}%` }}
              ></div>
            </div>
          </div>

          {missingItems.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-700">
                Missing information:
              </h4>
              <ul className="mt-2 space-y-2">
                {missingItems.map((item, index) => (
                  <li key={index}>
                    <Link
                      to={item.link}
                      className="flex items-center text-sm text-primary hover:text-primary-dark"
                    >
                      <Icon name={item.icon} size={16} className="mr-2" />
                      Add your {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-gray-200">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-gray-200">
          {stats.map((stat, index) => (
            <div key={index} className="px-6 py-5">
              <div className="flex items-center">
                <div
                  className={`flex-shrink-0 rounded-md p-3 ${stat.bgColor}`}
                >
                  <Icon name={stat.icon} size={20} className={stat.color} />
                </div>
                <div className="ml-4">
                  <div className="text-2xl font-semibold text-gray-900">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-500">{stat.name}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfileCompletion;