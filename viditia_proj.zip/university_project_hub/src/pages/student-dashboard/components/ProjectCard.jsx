import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const ProjectCard = ({ project, onWithdraw }) => {
  const [showDetails, setShowDetails] = useState(false);
  const [confirmWithdraw, setConfirmWithdraw] = useState(false);

  // Status badge configuration
  const statusConfig = {
    Applied: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Clock",
    },
    Shortlisted: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "ListChecks",
    },
    Selected: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Rejected: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  const config = statusConfig[project.status];

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleWithdraw = () => {
    if (confirmWithdraw) {
      onWithdraw(project.id);
      setConfirmWithdraw(false);
    } else {
      setConfirmWithdraw(true);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">
              {project.title}
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              {project.faculty} • {project.department}
            </p>
          </div>
          <div
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
          >
            <Icon name={config.icon} size={14} className="mr-1" />
            {project.status}
          </div>
        </div>

        <div className="mt-4 flex items-center text-sm text-gray-500">
          <Icon name="Calendar" size={16} className="mr-1.5" />
          Applied on {formatDate(project.appliedDate)}
        </div>

        <div className="mt-4 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            className="inline-flex items-center text-sm font-medium text-primary hover:text-primary-dark"
          >
            {showDetails ? "Hide Details" : "View Details"}
            <Icon
              name={showDetails ? "ChevronUp" : "ChevronDown"}
              size={16}
              className="ml-1"
            />
          </button>

          {project.status !== "Selected" && project.status !== "Rejected" && (
            <div>
              {confirmWithdraw ? (
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setConfirmWithdraw(false)}
                    className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleWithdraw}
                    className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-white bg-error hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-error"
                  >
                    Confirm
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleWithdraw}
                  className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="X" size={14} className="mr-1.5" />
                  Withdraw
                </button>
              )}
            </div>
          )}
        </div>

        {showDetails && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="space-y-3">
              <div>
                <h4 className="text-sm font-medium text-gray-900">
                  Project Description
                </h4>
                <p className="mt-1 text-sm text-gray-500">
                  {project.description}
                </p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-900">Domain</h4>
                <p className="mt-1 text-sm text-gray-500">{project.domain}</p>
              </div>
              {project.status === "Shortlisted" && (
                <div className="bg-warning-light bg-opacity-50 p-3 rounded-md">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Icon
                        name="AlertCircle"
                        size={18}
                        className="text-warning"
                      />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-warning">
                        You've been shortlisted!
                      </h3>
                      <div className="mt-1 text-sm text-gray-700">
                        <p>
                          Prepare for an interview with the faculty. Check your
                          notifications for details.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {project.status === "Selected" && (
                <div className="bg-success-light bg-opacity-50 p-3 rounded-md">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Icon
                        name="CheckCircle"
                        size={18}
                        className="text-success"
                      />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-success">
                        Congratulations! You've been selected!
                      </h3>
                      <div className="mt-1 text-sm text-gray-700">
                        <p>
                          The faculty will contact you with next steps. Check
                          your email for further instructions.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {project.status === "Rejected" && (
                <div className="bg-error-light bg-opacity-50 p-3 rounded-md">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Icon name="XCircle" size={18} className="text-error" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-error">
                        Application not selected
                      </h3>
                      <div className="mt-1 text-sm text-gray-700">
                        <p>
                          Don't be discouraged. Browse more projects and continue
                          applying.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectCard;