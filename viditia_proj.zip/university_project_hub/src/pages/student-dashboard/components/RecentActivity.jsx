import React from "react";
import Icon from "../../../components/AppIcon";

const RecentActivity = ({ activities }) => {
  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffTime / (1000 * 60));

    if (diffDays > 0) {
      return diffDays === 1 ? "Yesterday" : `${diffDays} days ago`;
    } else if (diffHours > 0) {
      return `${diffHours} ${diffHours === 1 ? "hour" : "hours"} ago`;
    } else {
      return `${diffMinutes} ${diffMinutes === 1 ? "minute" : "minutes"} ago`;
    }
  };

  // Activity icon and color configuration
  const activityConfig = {
    status_change: {
      icon: "RefreshCw",
      bgColor: "bg-warning-light",
      iconColor: "text-warning",
    },
    application: {
      icon: "Send",
      bgColor: "bg-primary-light",
      iconColor: "text-primary",
    },
    selection: {
      icon: "CheckCircle",
      bgColor: "bg-success-light",
      iconColor: "text-success",
    },
    rejection: {
      icon: "XCircle",
      bgColor: "bg-error-light",
      iconColor: "text-error",
    },
    meeting: {
      icon: "Calendar",
      bgColor: "bg-primary-light",
      iconColor: "text-primary",
    },
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Recent Activity
        </h3>
      </div>
      <div className="px-6 py-5">
        {activities.length > 0 ? (
          <div className="flow-root">
            <ul className="-mb-8">
              {activities.map((activity, activityIdx) => {
                const config = activityConfig[activity.type];
                return (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {activityIdx !== activities.length - 1 ? (
                        <span
                          className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200"
                          aria-hidden="true"
                        ></span>
                      ) : null}
                      <div className="relative flex items-start space-x-3">
                        <div>
                          <div
                            className={`relative px-1 ${config.bgColor} rounded-full flex items-center justify-center h-10 w-10`}
                          >
                            <Icon
                              name={config.icon}
                              size={20}
                              className={config.iconColor}
                            />
                          </div>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div>
                            <div className="text-sm">
                              <span className="font-medium text-gray-900">
                                {activity.project}
                              </span>
                            </div>
                            <p className="mt-0.5 text-sm text-gray-500">
                              {formatDate(activity.date)}
                            </p>
                          </div>
                          <div className="mt-2 text-sm text-gray-700">
                            <p>{activity.message}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          <div className="text-center py-6">
            <Icon
              name="Activity"
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No recent activity
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Your recent activities will appear here.
            </p>
          </div>
        )}
      </div>
      {activities.length > 0 && (
        <div className="border-t border-gray-200 px-6 py-3">
          <button
            type="button"
            className="text-sm font-medium text-primary hover:text-primary-dark w-full text-center"
          >
            View all activity
          </button>
        </div>
      )}
    </div>
  );
};

export default RecentActivity;