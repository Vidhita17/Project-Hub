import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import DashboardHeader from "./components/DashboardHeader";
import ProfileCompletion from "./components/ProfileCompletion";
import ProjectCard from "./components/ProjectCard";
import RecentActivity from "./components/RecentActivity";
import UpcomingMeetings from "./components/UpcomingMeetings";

const StudentDashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock user data
  const userData = {
    name: "Alex Johnson",
    email: "alex.johnson@university.edu",
    department: "Computer Science",
    semester: "7th Semester",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    profileCompletion: 75,
    resumeUploaded: true,
    githubLink: "https://github.com/alexjohnson",
    linkedinLink: "https://linkedin.com/in/alexjohnson",
  };

  // Mock applied projects data
  const appliedProjects = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      faculty: "Dr. Sarah Williams",
      department: "Computer Science",
      appliedDate: "2023-10-15",
      status: "Shortlisted",
      description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy.",
      domain: "Artificial Intelligence",
    },
    {
      id: 2,
      title: "Blockchain for Supply Chain Management",
      faculty: "Prof. Michael Chen",
      department: "Information Systems",
      appliedDate: "2023-10-10",
      status: "Applied",
      description: "Implementation of blockchain technology to improve transparency and efficiency in supply chain management systems.",
      domain: "Blockchain",
    },
    {
      id: 3,
      title: "Smart City IoT Network Architecture",
      faculty: "Dr. Emily Rodriguez",
      department: "Electrical Engineering",
      appliedDate: "2023-09-28",
      status: "Selected",
      description: "Designing an efficient IoT network architecture for smart city applications with focus on scalability and security.",
      domain: "Internet of Things",
    },
    {
      id: 4,
      title: "Quantum Computing Algorithms for Optimization Problems",
      faculty: "Prof. James Wilson",
      department: "Physics",
      appliedDate: "2023-09-20",
      status: "Rejected",
      description: "Research on quantum algorithms that can solve complex optimization problems more efficiently than classical algorithms.",
      domain: "Quantum Computing",
    },
  ];

  // Mock recent activities
  const recentActivities = [
    {
      id: 1,
      type: "status_change",
      project: "AI-Based Sentiment Analysis for Social Media",
      oldStatus: "Applied",
      newStatus: "Shortlisted",
      date: "2023-10-18T14:30:00",
      message: "You have been shortlisted for an interview.",
    },
    {
      id: 2,
      type: "application",
      project: "Blockchain for Supply Chain Management",
      date: "2023-10-10T09:15:00",
      message: "You applied for this project.",
    },
    {
      id: 3,
      type: "selection",
      project: "Smart City IoT Network Architecture",
      date: "2023-10-05T16:45:00",
      message: "You have been selected for this project.",
    },
    {
      id: 4,
      type: "rejection",
      project: "Quantum Computing Algorithms for Optimization Problems",
      date: "2023-09-25T11:20:00",
      message: "Your application was not selected for this project.",
    },
  ];

  // Mock upcoming meetings
  const upcomingMeetings = [
    {
      id: 1,
      faculty: "Dr. Sarah Williams",
      project: "AI-Based Sentiment Analysis for Social Media",
      date: "2023-10-25",
      time: "14:00 - 15:00",
      location: "Room 302, Computer Science Building",
      virtual: false,
    },
    {
      id: 2,
      faculty: "Prof. Michael Chen",
      project: "Blockchain for Supply Chain Management",
      date: "2023-10-27",
      time: "10:30 - 11:30",
      location: "Zoom Meeting",
      virtual: true,
      meetingLink: "https://university.zoom.us/j/123456789",
    },
  ];

  // Filter projects based on search query
  const filteredProjects = appliedProjects.filter(
    (project) =>
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.faculty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleWithdrawApplication = (projectId) => {
    // This would connect to an API in a real application
    console.log(`Withdrawing application for project ID: ${projectId}`);
    // Then update the UI accordingly
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={userData.profileImage}
                alt={userData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <Link to="/student-profile">
                  <Icon name="Edit" size={16} className="text-white" />
                </Link>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{userData.name}</h2>
            <p className="text-sm text-gray-500">{userData.department}</p>
            <p className="text-sm text-gray-500">{userData.semester}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/student-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/student-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/project-search-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="Search" size={20} className="mr-3" />
                Browse Projects
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  External Profiles
                </h3>
                <div className="mt-2 space-y-2">
                  {userData.githubLink && (
                    <a
                      href={userData.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Github" size={18} className="mr-3" />
                      GitHub
                    </a>
                  )}
                  {userData.linkedinLink && (
                    <a
                      href={userData.linkedinLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Linkedin" size={18} className="mr-3" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <DashboardHeader 
          userData={userData} 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
        />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Welcome section */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Welcome back, {userData.name.split(" ")[0]}!
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Here's what's happening with your project applications.
              </p>
            </div>

            {/* Profile completion and stats */}
            <div className="mt-4">
              <ProfileCompletion userData={userData} />
            </div>

            {/* Main dashboard content */}
            <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
              {/* Applied Projects Section - Takes 2/3 of the screen on large displays */}
              <div className="lg:col-span-2">
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-medium text-gray-900">
                      Your Applied Projects
                    </h2>
                    <Link
                      to="/project-search-page"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Plus" size={16} className="mr-2" />
                      Browse More Projects
                    </Link>
                  </div>

                  {filteredProjects.length > 0 ? (
                    <div className="space-y-4">
                      {filteredProjects.map((project) => (
                        <ProjectCard
                          key={project.id}
                          project={project}
                          onWithdraw={handleWithdrawApplication}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Icon
                        name="Search"
                        size={48}
                        className="mx-auto text-gray-300"
                      />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">
                        No projects found
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {searchQuery
                          ? `No projects matching "${searchQuery}"`
                          : "You haven't applied to any projects yet."}
                      </p>
                      <div className="mt-6">
                        <Link
                          to="/project-search-page"
                          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                        >
                          <Icon name="Search" size={16} className="mr-2" />
                          Browse Projects
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Activity and Meetings Section - Takes 1/3 of the screen on large displays */}
              <div className="space-y-6">
                {/* Upcoming Meetings */}
                <UpcomingMeetings meetings={upcomingMeetings} />

                {/* Recent Activity */}
                <RecentActivity activities={recentActivities} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default StudentDashboard;