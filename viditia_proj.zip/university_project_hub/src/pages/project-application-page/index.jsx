import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import ProjectHeader from "./components/ProjectHeader";
import ProjectDescription from "./components/ProjectDescription";
import FacultyInfo from "./components/FacultyInfo";
import ApplicationForm from "./components/ApplicationForm";
import ApplicationStatus from "./components/ApplicationStatus";

const ProjectApplicationPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [remainingDays, setRemainingDays] = useState(0);
  const [applicationSubmitted, setApplicationSubmitted] = useState(false);

  // Mock user data (same as in student dashboard)
  const userData = {
    name: "Alex Johnson",
    email: "alex.johnson@university.edu",
    department: "Computer Science",
    semester: "7th Semester",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    profileCompletion: 75,
    resumeUploaded: true,
    resumeVersions: [
      { id: 1, name: "General Resume", lastUpdated: "2023-09-15" },
      { id: 2, name: "Tech-focused Resume", lastUpdated: "2023-10-05" }
    ],
    githubLink: "https://github.com/alexjohnson",
    linkedinLink: "https://linkedin.com/in/alexjohnson",
  };

  // Mock project data
  const projectData = {
    id: "1",
    title: "AI-Based Sentiment Analysis for Social Media",
    faculty: {
      name: "Dr. Sarah Williams",
      department: "Computer Science",
      designation: "Associate Professor",
      image: "https://randomuser.me/api/portraits/women/68.jpg",
      bio: "Dr. Williams specializes in Natural Language Processing and Machine Learning. She has published over 30 research papers in top-tier conferences and journals. Her current research focuses on sentiment analysis, emotion detection, and social media analytics.",
      email: "sarah.williams@university.edu",
      officeHours: "Monday & Wednesday, 2:00 PM - 4:00 PM",
      officeLocation: "Computer Science Building, Room 305"
    },
    postedDate: "2023-09-28",
    deadline: "2023-11-15",
    status: "Open",
    description: `This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy. The system will be able to classify text as positive, negative, or neutral, and identify specific emotions like happiness, anger, sadness, etc.

The project will involve collecting and preprocessing social media data, implementing various machine learning algorithms (including traditional ML and deep learning approaches), and evaluating their performance. The final system will be deployed as a web application that can analyze sentiment in real-time.

Students will gain hands-on experience with natural language processing techniques, machine learning algorithms, and web development. This project is ideal for students interested in AI, NLP, and social media analytics.`,
    objectives: [
      "Develop a machine learning model for sentiment analysis with at least 85% accuracy",
      "Create a dataset of labeled social media posts for training and testing",
      "Implement and compare different ML algorithms (SVM, LSTM, BERT, etc.)",
      "Build a web interface for real-time sentiment analysis",
      "Document the methodology and results in a comprehensive report"
    ],
    requiredSkills: [
      "Python programming (intermediate to advanced level)",
      "Basic understanding of machine learning concepts",
      "Familiarity with NLP techniques",
      "Experience with libraries like TensorFlow, PyTorch, or scikit-learn (preferred)",
      "Web development skills (basic HTML, CSS, JavaScript)"
    ],
    learningOutcomes: [
      "Practical experience with the entire machine learning pipeline",
      "Advanced knowledge of NLP techniques and sentiment analysis",
      "Skills in data collection, preprocessing, and analysis",
      "Experience in deploying ML models in web applications",
      "Research paper writing and presentation skills"
    ],
    duration: "3-4 months",
    maxStudents: 2,
    currentApplications: 5,
    domain: "Artificial Intelligence",
    tags: ["Machine Learning", "NLP", "Social Media Analytics", "Web Development"]
  };

  useEffect(() => {
    // Simulate API call to fetch project data
    const fetchProject = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call using the id from params
        // For now, we'll just use our mock data
        setTimeout(() => {
          setProject(projectData);
          setLoading(false);
        }, 800);
      } catch (error) {
        console.error("Error fetching project:", error);
        setLoading(false);
      }
    };

    fetchProject();
  }, [id]);

  useEffect(() => {
    if (project) {
      // Calculate remaining days until deadline
      const deadline = new Date(project.deadline);
      const today = new Date();
      const diffTime = deadline - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setRemainingDays(diffDays);
    }
  }, [project]);

  const handleSubmitApplication = (formData) => {
    // In a real app, this would send the application data to an API
    console.log("Submitting application:", formData);
    
    // Simulate API call delay
    setTimeout(() => {
      setApplicationSubmitted(true);
      
      // Redirect to dashboard after successful submission
      setTimeout(() => {
        navigate("/student-dashboard");
      }, 3000);
    }, 1500);
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="text-center">
          <Icon name="Loader" size={48} className="mx-auto text-primary animate-spin" />
          <p className="mt-4 text-lg text-gray-700">Loading project details...</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="text-center max-w-md px-4">
          <Icon name="FileX" size={48} className="mx-auto text-error" />
          <h1 className="mt-4 text-2xl font-bold text-gray-900">Project Not Found</h1>
          <p className="mt-2 text-gray-500">The project you're looking for doesn't exist or has been removed.</p>
          <div className="mt-6">
            <Link
              to="/project-search-page"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Search" size={16} className="mr-2" />
              Browse Projects
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar - Same as in StudentDashboard */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={userData.profileImage}
                alt={userData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <Link to="/student-profile">
                  <Icon name="Edit" size={16} className="text-white" />
                </Link>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{userData.name}</h2>
            <p className="text-sm text-gray-500">{userData.department}</p>
            <p className="text-sm text-gray-500">{userData.semester}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/student-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/student-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/project-search-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-primary bg-primary-light rounded-md"
              >
                <Icon name="Search" size={20} className="mr-3" />
                Browse Projects
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  External Profiles
                </h3>
                <div className="mt-2 space-y-2">
                  {userData.githubLink && (
                    <a
                      href={userData.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Github" size={18} className="mr-3" />
                      GitHub
                    </a>
                  )}
                  {userData.linkedinLink && (
                    <a
                      href={userData.linkedinLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Linkedin" size={18} className="mr-3" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        {/* Header with back button */}
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Link
                  to="/project-search-page"
                  className="inline-flex items-center mr-4 text-gray-500 hover:text-gray-700"
                >
                  <Icon name="ArrowLeft" size={20} />
                  <span className="ml-1 text-sm font-medium">Back to Projects</span>
                </Link>
                <h1 className="text-lg font-medium text-gray-900 hidden sm:block">
                  Project Application
                </h1>
              </div>
              
              {/* Mobile menu button */}
              <div className="flex md:hidden">
                <button
                  type="button"
                  className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
                >
                  <span className="sr-only">Open main menu</span>
                  <Icon name="Menu" size={24} />
                </button>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Sticky application status indicator */}
            {remainingDays > 0 && !applicationSubmitted && (
              <ApplicationStatus 
                remainingDays={remainingDays} 
                currentApplications={project.currentApplications}
                maxStudents={project.maxStudents}
              />
            )}

            {/* Success message after submission */}
            {applicationSubmitted && (
              <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 max-w-md mx-auto">
                  <div className="text-center">
                    <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-success-light">
                      <Icon name="Check" size={24} className="text-success" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium text-gray-900">Application Submitted!</h3>
                    <p className="mt-2 text-sm text-gray-500">
                      Your application for "{project.title}" has been successfully submitted. You will be redirected to your dashboard.
                    </p>
                    <div className="mt-4">
                      <Link
                        to="/student-dashboard"
                        className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                      >
                        Go to Dashboard
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="py-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Project details - Takes 2/3 of the screen on large displays */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Project header section */}
                  <ProjectHeader project={project} />
                  
                  {/* Project description section */}
                  <ProjectDescription project={project} />
                </div>

                {/* Right sidebar - Takes 1/3 of the screen on large displays */}
                <div className="space-y-6">
                  {/* Faculty information */}
                  <FacultyInfo faculty={project.faculty} />
                  
                  {/* Application form */}
                  <ApplicationForm 
                    project={project} 
                    userData={userData} 
                    onSubmit={handleSubmitApplication} 
                  />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ProjectApplicationPage;