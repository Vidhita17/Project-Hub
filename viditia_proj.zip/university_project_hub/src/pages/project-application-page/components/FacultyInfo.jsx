import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const FacultyInfo = ({ faculty }) => {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900">Faculty Information</h2>
        
        <div className="mt-4 flex items-center">
          <div className="flex-shrink-0">
            <Image
              src={faculty.image}
              alt={faculty.name}
              className="h-16 w-16 rounded-full object-cover"
            />
          </div>
          <div className="ml-4">
            <h3 className="text-md font-medium text-gray-900">{faculty.name}</h3>
            <p className="text-sm text-gray-500">{faculty.designation}</p>
            <p className="text-sm text-gray-500">{faculty.department}</p>
          </div>
        </div>
        
        <div className="mt-4">
          <p className="text-sm text-gray-500">{faculty.bio}</p>
        </div>
        
        <div className="mt-6 space-y-3">
          <div className="flex items-center">
            <Icon name="Mail" size={16} className="text-gray-400" />
            <span className="ml-2 text-sm text-gray-500">{faculty.email}</span>
          </div>
          <div className="flex items-center">
            <Icon name="Clock" size={16} className="text-gray-400" />
            <span className="ml-2 text-sm text-gray-500">{faculty.officeHours}</span>
          </div>
          <div className="flex items-center">
            <Icon name="MapPin" size={16} className="text-gray-400" />
            <span className="ml-2 text-sm text-gray-500">{faculty.officeLocation}</span>
          </div>
        </div>
        
        <div className="mt-6">
          <button
            type="button"
            className="w-full inline-flex justify-center items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name="Calendar" size={16} className="mr-2" />
            Schedule a Meeting
          </button>
        </div>
      </div>
    </div>
  );
};

export default FacultyInfo;