import React from "react";
import Icon from "../../../components/AppIcon";

const ProjectDescription = ({ project }) => {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900">Project Description</h2>
        <div className="mt-4 text-sm text-gray-500 space-y-4">
          <p>{project.description}</p>
        </div>

        <div className="mt-6">
          <h3 className="text-md font-medium text-gray-900">Project Objectives</h3>
          <ul className="mt-2 space-y-2">
            {project.objectives.map((objective, index) => (
              <li key={index} className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  <Icon name="CheckCircle" size={16} className="text-primary" />
                </div>
                <span className="ml-2 text-sm text-gray-500">{objective}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6">
          <h3 className="text-md font-medium text-gray-900">Required Skills</h3>
          <ul className="mt-2 space-y-2">
            {project.requiredSkills.map((skill, index) => (
              <li key={index} className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  <Icon name="CheckSquare" size={16} className="text-primary" />
                </div>
                <span className="ml-2 text-sm text-gray-500">{skill}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6">
          <h3 className="text-md font-medium text-gray-900">Learning Outcomes</h3>
          <ul className="mt-2 space-y-2">
            {project.learningOutcomes.map((outcome, index) => (
              <li key={index} className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  <Icon name="GraduationCap" size={16} className="text-primary" />
                </div>
                <span className="ml-2 text-sm text-gray-500">{outcome}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon name="Clock" size={20} className="text-gray-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Estimated Duration</p>
                <p className="text-sm text-gray-500">{project.duration}</p>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon name="Users" size={20} className="text-gray-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Current Applications</p>
                <p className="text-sm text-gray-500">
                  {project.currentApplications} of {project.maxStudents} positions
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDescription;