import React from "react";
import Icon from "../../../components/AppIcon";

const ProjectHeader = ({ project }) => {
  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Status badge configuration
  const statusConfig = {
    Open: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    "Closing Soon": {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "Clock",
    },
    Closed: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  const config = statusConfig[project.status] || statusConfig.Open;

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{project.title}</h1>
            <p className="mt-2 text-sm text-gray-500">
              <span className="font-medium text-gray-700">{project.faculty.name}</span> • {project.faculty.department}
            </p>
          </div>
          <div
            className={`mt-2 sm:mt-0 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
          >
            <Icon name={config.icon} size={14} className="mr-1" />
            {project.status}
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Icon name="Calendar" size={20} className="text-gray-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-900">Posted On</p>
              <p className="text-sm text-gray-500">{formatDate(project.postedDate)}</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Icon name="Clock" size={20} className="text-gray-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-900">Application Deadline</p>
              <p className="text-sm text-gray-500">{formatDate(project.deadline)}</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Icon name="Users" size={20} className="text-gray-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-900">Team Size</p>
              <p className="text-sm text-gray-500">
                {project.maxStudents} {project.maxStudents === 1 ? "Student" : "Students"}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <div className="flex flex-wrap gap-2">
            <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary-light text-primary">
              <Icon name="Tag" size={12} className="mr-1" />
              {project.domain}
            </div>
            {project.tags.map((tag, index) => (
              <div
                key={index}
                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
              >
                {tag}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectHeader;