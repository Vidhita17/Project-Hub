import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const ApplicationForm = ({ project, userData, onSubmit }) => {
  const [statement, setStatement] = useState("");
  const [selectedResume, setSelectedResume] = useState(
    userData.resumeVersions && userData.resumeVersions.length > 0
      ? userData.resumeVersions[0].id
      : null
  );
  const [includeGithub, setIncludeGithub] = useState(true);
  const [includeLinkedin, setIncludeLinkedin] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const maxStatementLength = 1000;
  const minStatementLength = 100;

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate form
    const newErrors = {};
    if (statement.length < minStatementLength) {
      newErrors.statement = `Statement must be at least ${minStatementLength} characters.`;
    }
    if (!selectedResume && userData.resumeVersions && userData.resumeVersions.length > 0) {
      newErrors.resume = "Please select a resume.";
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    setIsSubmitting(true);
    
    // Prepare form data
    const formData = {
      projectId: project.id,
      statement,
      resumeId: selectedResume,
      includeGithub,
      includeLinkedin,
    };
    
    // Submit form
    onSubmit(formData);
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900">Apply for this Project</h2>
        
        <form onSubmit={handleSubmit} className="mt-4 space-y-6">
          <div>
            <label htmlFor="statement" className="block text-sm font-medium text-gray-700">
              Statement of Interest
            </label>
            <div className="mt-1">
              <textarea
                id="statement"
                name="statement"
                rows={6}
                className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border ${
                  errors.statement ? "border-error" : "border-gray-300"
                } rounded-md`}
                placeholder="Explain why you're interested in this project and how your skills align with the requirements..."
                value={statement}
                onChange={(e) => setStatement(e.target.value)}
                maxLength={maxStatementLength}
              ></textarea>
            </div>
            <div className="mt-1 flex justify-between">
              <p className={`text-xs ${
                statement.length < minStatementLength ? "text-error" : "text-gray-500"
              }`}>
                {statement.length} / {maxStatementLength} characters
              </p>
              {statement.length < minStatementLength && (
                <p className="text-xs text-error">
                  Minimum {minStatementLength} characters required
                </p>
              )}
            </div>
            {errors.statement && (
              <p className="mt-1 text-sm text-error">{errors.statement}</p>
            )}
          </div>
          
          {userData.resumeVersions && userData.resumeVersions.length > 0 ? (
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Select Resume
              </label>
              <div className="mt-1 space-y-2">
                {userData.resumeVersions.map((resume) => (
                  <div key={resume.id} className="flex items-center">
                    <input
                      id={`resume-${resume.id}`}
                      name="resume"
                      type="radio"
                      className="focus:ring-primary h-4 w-4 text-primary border-gray-300"
                      checked={selectedResume === resume.id}
                      onChange={() => setSelectedResume(resume.id)}
                    />
                    <label htmlFor={`resume-${resume.id}`} className="ml-3 flex items-center">
                      <Icon name="FileText" size={16} className="text-gray-400 mr-2" />
                      <div>
                        <p className="text-sm font-medium text-gray-700">{resume.name}</p>
                        <p className="text-xs text-gray-500">
                          Last updated: {new Date(resume.lastUpdated).toLocaleDateString()}
                        </p>
                      </div>
                    </label>
                  </div>
                ))}
              </div>
              {errors.resume && (
                <p className="mt-1 text-sm text-error">{errors.resume}</p>
              )}
              <div className="mt-2">
                <button
                  type="button"
                  className="inline-flex items-center text-sm text-primary hover:text-primary-dark"
                >
                  <Icon name="Upload" size={14} className="mr-1" />
                  Upload new resume
                </button>
              </div>
            </div>
          ) : (
            <div className="rounded-md bg-warning-light p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Icon name="AlertTriangle" size={18} className="text-warning" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-warning">Resume Required</h3>
                  <div className="mt-1 text-sm text-gray-700">
                    <p>You need to upload a resume to apply for this project.</p>
                    <button
                      type="button"
                      className="mt-2 inline-flex items-center text-sm font-medium text-warning hover:text-warning"
                    >
                      <Icon name="Upload" size={14} className="mr-1" />
                      Upload Resume
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-3">
            <div className="flex items-center">
              <input
                id="include-github"
                name="include-github"
                type="checkbox"
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                checked={includeGithub}
                onChange={() => setIncludeGithub(!includeGithub)}
                disabled={!userData.githubLink}
              />
              <label htmlFor="include-github" className="ml-3 flex items-center">
                <Icon name="Github" size={16} className="text-gray-500 mr-2" />
                <span className="text-sm text-gray-700">
                  Include GitHub Profile
                </span>
                {!userData.githubLink && (
                  <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                    Not Added
                  </span>
                )}
              </label>
            </div>
            
            <div className="flex items-center">
              <input
                id="include-linkedin"
                name="include-linkedin"
                type="checkbox"
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                checked={includeLinkedin}
                onChange={() => setIncludeLinkedin(!includeLinkedin)}
                disabled={!userData.linkedinLink}
              />
              <label htmlFor="include-linkedin" className="ml-3 flex items-center">
                <Icon name="Linkedin" size={16} className="text-gray-500 mr-2" />
                <span className="text-sm text-gray-700">
                  Include LinkedIn Profile
                </span>
                {!userData.linkedinLink && (
                  <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                    Not Added
                  </span>
                )}
              </label>
            </div>
          </div>
          
          <div>
            <button
              type="submit"
              disabled={isSubmitting || statement.length < minStatementLength || !selectedResume}
              className={`w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
                isSubmitting || statement.length < minStatementLength || !selectedResume
                  ? "bg-gray-400 cursor-not-allowed" :"bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              }`}
            >
              {isSubmitting ? (
                <>
                  <Icon name="Loader" size={16} className="animate-spin mr-2" />
                  Submitting...
                </>
              ) : (
                <>
                  <Icon name="Send" size={16} className="mr-2" />
                  Submit Application
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ApplicationForm;