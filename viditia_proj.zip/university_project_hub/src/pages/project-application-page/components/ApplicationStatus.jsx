import React from "react";
import Icon from "../../../components/AppIcon";

const ApplicationStatus = ({ remainingDays, currentApplications, maxStudents }) => {
  // Determine urgency level based on remaining days
  let urgencyLevel = "low";
  if (remainingDays <= 3) {
    urgencyLevel = "high";
  } else if (remainingDays <= 7) {
    urgencyLevel = "medium";
  }

  // Determine competition level based on applications vs max students
  let competitionLevel = "low";
  const applicationRatio = currentApplications / maxStudents;
  if (applicationRatio >= 2) {
    competitionLevel = "high";
  } else if (applicationRatio >= 1) {
    competitionLevel = "medium";
  }

  // Configure styles based on urgency
  const urgencyConfig = {
    high: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "Clock",
      message: "Deadline approaching soon!",
    },
    medium: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "Clock",
      message: "Application deadline is coming up.",
    },
    low: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Calendar",
      message: "You have time to prepare your application.",
    },
  };

  // Configure styles based on competition
  const competitionConfig = {
    high: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "Users",
      message: "High competition for this project.",
    },
    medium: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "Users",
      message: "Moderate competition for this project.",
    },
    low: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "Users",
      message: "Low competition for this project.",
    },
  };

  const urgencyConf = urgencyConfig[urgencyLevel];
  const competitionConf = competitionConfig[competitionLevel];

  return (
    <div className="sticky top-0 z-10 bg-white shadow-sm border-b border-gray-200 py-3 mb-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center">
            <div className={`flex-shrink-0 rounded-full p-1 ${urgencyConf.bgColor}`}>
              <Icon name={urgencyConf.icon} size={16} className={urgencyConf.textColor} />
            </div>
            <div className="ml-2">
              <p className="text-sm font-medium text-gray-900">
                {remainingDays} {remainingDays === 1 ? "day" : "days"} remaining
              </p>
              <p className="text-xs text-gray-500">{urgencyConf.message}</p>
            </div>
          </div>
          
          <div className="mt-2 sm:mt-0 flex items-center">
            <div className={`flex-shrink-0 rounded-full p-1 ${competitionConf.bgColor}`}>
              <Icon name={competitionConf.icon} size={16} className={competitionConf.textColor} />
            </div>
            <div className="ml-2">
              <p className="text-sm font-medium text-gray-900">
                {currentApplications} {currentApplications === 1 ? "application" : "applications"} for {maxStudents} {maxStudents === 1 ? "position" : "positions"}
              </p>
              <p className="text-xs text-gray-500">{competitionConf.message}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationStatus;