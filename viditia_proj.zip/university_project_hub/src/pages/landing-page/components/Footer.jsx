import React from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";

const Footer = () => {
  // Get current year for copyright
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800">
      <div className="max-w-7xl mx-auto py-12 px-4 overflow-hidden sm:px-6 lg:px-8">
        <nav
          className="-mx-5 -my-2 flex flex-wrap justify-center"
          aria-label="Footer"
        >
          <div className="px-5 py-2">
            <Link
              to="/landing-page"
              className="text-base text-gray-300 hover:text-white"
            >
              Home
            </Link>
          </div>
          <div className="px-5 py-2">
            <a
              href="#about"
              className="text-base text-gray-300 hover:text-white"
            >
              About
            </a>
          </div>
          <div className="px-5 py-2">
            <Link
              to="/project-search-page"
              className="text-base text-gray-300 hover:text-white"
            >
              Projects
            </Link>
          </div>
          <div className="px-5 py-2">
            <a
              href="#faculty"
              className="text-base text-gray-300 hover:text-white"
            >
              Faculty
            </a>
          </div>
          <div className="px-5 py-2">
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Privacy Policy
            </a>
          </div>
          <div className="px-5 py-2">
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Terms of Service
            </a>
          </div>
          <div className="px-5 py-2">
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Contact
            </a>
          </div>
        </nav>
        <div className="mt-8 flex justify-center space-x-6">
          <a href="#" className="text-gray-400 hover:text-gray-300">
            <span className="sr-only">Facebook</span>
            <Icon name="Facebook" size={24} />
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-300">
            <span className="sr-only">Instagram</span>
            <Icon name="Instagram" size={24} />
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-300">
            <span className="sr-only">Twitter</span>
            <Icon name="Twitter" size={24} />
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-300">
            <span className="sr-only">LinkedIn</span>
            <Icon name="Linkedin" size={24} />
          </a>
        </div>
        <div className="mt-8 flex items-center justify-center">
          <Icon name="Graduation" size={32} className="text-primary" />
          <span className="ml-2 text-xl font-semibold text-white">
            Project Hub
          </span>
        </div>
        <p className="mt-8 text-center text-base text-gray-400">
          &copy; {currentYear} University Project Hub. All rights reserved.
        </p>
        <p className="mt-2 text-center text-sm text-gray-400">
          A platform connecting students with faculty research projects.
        </p>
      </div>
    </footer>
  );
};

export default Footer;