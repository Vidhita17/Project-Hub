import React from "react";
import Icon from "../../../components/AppIcon";

const FeaturesSection = () => {
  // Features data
  const features = [
    {
      name: "Browse Projects by Domain",
      description:
        "Explore projects across various domains including AI, Blockchain, IoT, and more. Find the perfect match for your interests and career goals.",
      icon: "Search",
      color: "bg-primary",
    },
    {
      name: "Simple Application Process",
      description:
        "Apply to multiple projects with just a few clicks. Our streamlined process makes it easy to submit your credentials and express interest.",
      icon: "ClipboardList",
      color: "bg-primary",
    },
    {
      name: "Track Application Status",
      description:
        "Stay updated on your application status in real-time. Receive notifications when you\'re shortlisted, selected, or when there are updates.",
      icon: "Activity",
      color: "bg-primary",
    },
    {
      name: "Connect with Faculty",
      description:
        "Schedule meetings, receive feedback, and collaborate directly with faculty members on projects that interest you.",
      icon: "Users",
      color: "bg-primary",
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">
            Features
          </h2>
          <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
            Everything You Need to Succeed
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our platform provides all the tools necessary for students to find
            and secure meaningful projects, and for faculty to find talented
            students.
          </p>
        </div>

        <div className="mt-10">
          <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
            {features.map((feature) => (
              <div key={feature.name} className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md text-white bg-primary">
                  <Icon name={feature.icon} size={24} />
                </div>
                <div className="ml-16">
                  <h3 className="text-lg font-medium text-gray-900">
                    {feature.name}
                  </h3>
                  <p className="mt-2 text-base text-gray-500">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;