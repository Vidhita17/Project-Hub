import React from "react";
import Icon from "../../../components/AppIcon";
import { Link } from "react-router-dom";

const NoResults = ({ searchQuery, hasFilters, clearAllFilters }) => {
  return (
    <div className="bg-white shadow rounded-lg p-12 text-center">
      <Icon
        name="Search"
        size={48}
        className="mx-auto text-gray-300"
      />
      <h3 className="mt-4 text-lg font-medium text-gray-900">
        No projects found
      </h3>
      <p className="mt-2 text-sm text-gray-500 max-w-md mx-auto">
        {searchQuery && hasFilters
          ? `No projects matching "${searchQuery}" with the selected filters.`
          : searchQuery
          ? `No projects matching "${searchQuery}".`
          : hasFilters
          ? "No projects match the selected filters." :"There are no projects available at the moment."}
      </p>
      <div className="mt-6 space-y-4">
        {(searchQuery || hasFilters) && (
          <button
            onClick={clearAllFilters}
            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name="RefreshCw" size={16} className="mr-2" />
            Clear all filters
          </button>
        )}
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            to="/student-dashboard"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name="ArrowLeft" size={16} className="mr-2" />
            Back to Dashboard
          </Link>
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name="RefreshCw" size={16} className="mr-2" />
            Refresh Page
          </button>
        </div>
      </div>
      <div className="mt-8 border-t border-gray-200 pt-6">
        <h4 className="text-sm font-medium text-gray-900">Suggestions:</h4>
        <ul className="mt-2 text-sm text-gray-500 list-disc list-inside space-y-1 text-left max-w-md mx-auto">
          <li>Check if your search terms are spelled correctly</li>
          <li>Try using more general keywords</li>
          <li>Remove some filters to broaden your search</li>
          <li>Check back later as new projects are added regularly</li>
        </ul>
      </div>
    </div>
  );
};

export default NoResults;