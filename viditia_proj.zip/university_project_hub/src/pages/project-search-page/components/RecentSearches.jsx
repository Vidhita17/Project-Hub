import React from "react";
import Icon from "../../../components/AppIcon";

const RecentSearches = ({ searches, useSearch, clearSearch }) => {
  if (!searches || searches.length === 0) return null;

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-sm font-medium text-gray-900">Recent Searches</h2>
      </div>
      <div className="p-4">
        <ul className="space-y-2">
          {searches.map((search, index) => (
            <li key={index} className="flex items-center justify-between">
              <button
                onClick={() => useSearch(search)}
                className="text-sm text-primary hover:text-primary-dark truncate max-w-[80%] text-left"
              >
                <Icon name="Search" size={14} className="inline mr-2" />
                {search}
              </button>
              <button
                onClick={() => clearSearch(search)}
                className="text-gray-400 hover:text-gray-500"
                aria-label={`Remove ${search} from recent searches`}
              >
                <Icon name="X" size={14} />
              </button>
            </li>
          ))}
        </ul>
      </div>
      {searches.length > 0 && (
        <div className="border-t border-gray-200 p-4">
          <button
            onClick={() => searches.forEach(search => clearSearch(search))}
            className="text-xs text-gray-500 hover:text-gray-700"
          >
            Clear all recent searches
          </button>
        </div>
      )}
    </div>
  );
};

export default RecentSearches;