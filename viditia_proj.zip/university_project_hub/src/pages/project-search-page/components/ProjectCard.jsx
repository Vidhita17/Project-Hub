import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";

const ProjectCard = ({ project, viewMode, onApply }) => {
  const [showDetails, setShowDetails] = useState(false);
  const [confirmApply, setConfirmApply] = useState(false);

  // Status badge configuration
  const statusConfig = {
    Available: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Filled: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
    "Deadline Approaching": {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "Clock",
    },
  };

  const config = statusConfig[project.status];

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Calculate days remaining until deadline
  const calculateDaysRemaining = (deadlineString) => {
    const deadline = new Date(deadlineString);
    const today = new Date();
    const diffTime = Math.abs(deadline - today);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = calculateDaysRemaining(project.deadline);

  const handleApply = () => {
    if (confirmApply) {
      onApply(project.id);
      setConfirmApply(false);
    } else {
      setConfirmApply(true);
    }
  };

  return (
    <div className={`bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden ${
      viewMode === 'list' ? 'flex flex-col md:flex-row' : ''
    }`}>
      <div className={`p-5 ${viewMode === 'list' ? 'md:flex-1' : ''}`}>
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">
              {project.title}
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              {project.faculty} • {project.department}
            </p>
          </div>
          <div
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
          >
            <Icon name={config.icon} size={14} className="mr-1" />
            {project.status}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {project.tags.map((tag, index) => (
            <span
              key={index}
              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="mt-4 text-sm text-gray-700">
          <p className={viewMode === 'list' || showDetails ? '' : 'line-clamp-2'}>
            {project.description}
          </p>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center text-sm text-gray-500">
            <Icon name="Calendar" size={16} className="mr-1.5" />
            <span>
              Posted: {formatDate(project.postedDate)}
            </span>
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <Icon name="Clock" size={16} className="mr-1.5" />
            <span>
              Deadline: {formatDate(project.deadline)}
            </span>
          </div>
        </div>

        {viewMode === 'grid' && (
          <div className="mt-4 flex items-center justify-between">
            <button
              type="button"
              onClick={() => setShowDetails(!showDetails)}
              className="inline-flex items-center text-sm font-medium text-primary hover:text-primary-dark"
            >
              {showDetails ? "Show Less" : "Show More"}
              <Icon
                name={showDetails ? "ChevronUp" : "ChevronDown"}
                size={16}
                className="ml-1"
              />
            </button>

            {project.status === "Available" && (
              <div>
                {project.applied ? (
                  <span className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-success">
                    <Icon name="Check" size={14} className="mr-1.5" />
                    Applied
                  </span>
                ) : confirmApply ? (
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={() => setConfirmApply(false)}
                      className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleApply}
                      className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      Confirm
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleApply}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    <Icon name="Send" size={14} className="mr-1.5" />
                    Apply
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {showDetails && viewMode === 'grid' && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="space-y-3">
              <div>
                <h4 className="text-sm font-medium text-gray-900">
                  Requirements
                </h4>
                <p className="mt-1 text-sm text-gray-500">
                  {project.requirements}
                </p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-900">Domain</h4>
                <p className="mt-1 text-sm text-gray-500">{project.domain}</p>
              </div>
              {daysRemaining <= 7 && project.status === "Available" && (
                <div className="bg-warning-light bg-opacity-50 p-3 rounded-md">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Icon
                        name="AlertCircle"
                        size={18}
                        className="text-warning"
                      />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-warning">
                        Deadline approaching!
                      </h3>
                      <div className="mt-1 text-sm text-gray-700">
                        <p>
                          Only {daysRemaining} {daysRemaining === 1 ? 'day' : 'days'} left to apply.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {viewMode === 'list' && (
        <div className="p-5 border-t md:border-t-0 md:border-l border-gray-200 md:w-64 flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-medium text-gray-900">
              Requirements
            </h4>
            <p className="mt-1 text-sm text-gray-500 line-clamp-3">
              {project.requirements}
            </p>
          </div>
          
          <div className="mt-4">
            {daysRemaining <= 7 && project.status === "Available" && (
              <div className="mb-4 bg-warning-light bg-opacity-50 p-2 rounded-md">
                <div className="flex items-center">
                  <Icon
                    name="AlertCircle"
                    size={16}
                    className="text-warning"
                  />
                  <p className="ml-2 text-xs font-medium text-warning">
                    {daysRemaining} {daysRemaining === 1 ? 'day' : 'days'} left to apply
                  </p>
                </div>
              </div>
            )}
            
            {project.status === "Available" ? (
              project.applied ? (
                <span className="inline-flex w-full justify-center items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-success">
                  <Icon name="Check" size={16} className="mr-1.5" />
                  Applied
                </span>
              ) : (
                <Link
                  to={`/project-application-page?id=${project.id}`}
                  className="inline-flex w-full justify-center items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Send" size={16} className="mr-1.5" />
                  Apply Now
                </Link>
              )
            ) : (
              <span className="inline-flex w-full justify-center items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-500 bg-gray-100 cursor-not-allowed">
                <Icon name="XCircle" size={16} className="mr-1.5" />
                Not Available
              </span>
            )}
            
            <Link
              to={`/project-application-page?id=${project.id}&view=true`}
              className="mt-2 inline-flex w-full justify-center items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Info" size={16} className="mr-1.5" />
              View Details
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectCard;