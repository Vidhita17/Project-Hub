import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const FilterSection = ({ 
  domains, 
  departments, 
  faculties, 
  statuses, 
  filters, 
  handleFilterChange,
  clearAllFilters
}) => {
  const [expandedSections, setExpandedSections] = useState({
    domains: true,
    departments: true,
    faculties: true,
    statuses: true
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Handle checkbox change
  const handleCheckboxChange = (filterType, value) => {
    const currentValues = filters[filterType];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    handleFilterChange(filterType, newValues);
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900">Filters</h2>
        <button
          onClick={clearAllFilters}
          className="text-sm text-primary hover:text-primary-dark font-medium"
        >
          Clear All
        </button>
      </div>

      <div className="divide-y divide-gray-200">
        {/* Domain filter */}
        <div className="p-4">
          <button
            className="flex w-full items-center justify-between text-left"
            onClick={() => toggleSection('domains')}
          >
            <h3 className="text-sm font-medium text-gray-900">Domain</h3>
            <Icon 
              name={expandedSections.domains ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-gray-500"
            />
          </button>
          
          {expandedSections.domains && (
            <div className="mt-4 space-y-2 max-h-60 overflow-y-auto">
              {domains.map(domain => (
                <div key={domain} className="flex items-center">
                  <input
                    id={`domain-${domain}`}
                    name={`domain-${domain}`}
                    type="checkbox"
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                    checked={filters.domains.includes(domain)}
                    onChange={() => handleCheckboxChange('domains', domain)}
                  />
                  <label
                    htmlFor={`domain-${domain}`}
                    className="ml-3 text-sm text-gray-700"
                  >
                    {domain}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Department filter */}
        <div className="p-4">
          <button
            className="flex w-full items-center justify-between text-left"
            onClick={() => toggleSection('departments')}
          >
            <h3 className="text-sm font-medium text-gray-900">Department</h3>
            <Icon 
              name={expandedSections.departments ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-gray-500"
            />
          </button>
          
          {expandedSections.departments && (
            <div className="mt-4 space-y-2 max-h-60 overflow-y-auto">
              {departments.map(department => (
                <div key={department} className="flex items-center">
                  <input
                    id={`department-${department}`}
                    name={`department-${department}`}
                    type="checkbox"
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                    checked={filters.departments.includes(department)}
                    onChange={() => handleCheckboxChange('departments', department)}
                  />
                  <label
                    htmlFor={`department-${department}`}
                    className="ml-3 text-sm text-gray-700"
                  >
                    {department}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Faculty filter */}
        <div className="p-4">
          <button
            className="flex w-full items-center justify-between text-left"
            onClick={() => toggleSection('faculties')}
          >
            <h3 className="text-sm font-medium text-gray-900">Faculty</h3>
            <Icon 
              name={expandedSections.faculties ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-gray-500"
            />
          </button>
          
          {expandedSections.faculties && (
            <div className="mt-4 space-y-2 max-h-60 overflow-y-auto">
              {faculties.map(faculty => (
                <div key={faculty} className="flex items-center">
                  <input
                    id={`faculty-${faculty}`}
                    name={`faculty-${faculty}`}
                    type="checkbox"
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                    checked={filters.faculties.includes(faculty)}
                    onChange={() => handleCheckboxChange('faculties', faculty)}
                  />
                  <label
                    htmlFor={`faculty-${faculty}`}
                    className="ml-3 text-sm text-gray-700"
                  >
                    {faculty}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Status filter */}
        <div className="p-4">
          <button
            className="flex w-full items-center justify-between text-left"
            onClick={() => toggleSection('statuses')}
          >
            <h3 className="text-sm font-medium text-gray-900">Status</h3>
            <Icon 
              name={expandedSections.statuses ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-gray-500"
            />
          </button>
          
          {expandedSections.statuses && (
            <div className="mt-4 space-y-2">
              {statuses.map(status => (
                <div key={status} className="flex items-center">
                  <input
                    id={`status-${status}`}
                    name={`status-${status}`}
                    type="checkbox"
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                    checked={filters.statuses.includes(status)}
                    onChange={() => handleCheckboxChange('statuses', status)}
                  />
                  <label
                    htmlFor={`status-${status}`}
                    className="ml-3 text-sm text-gray-700"
                  >
                    {status}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FilterSection;