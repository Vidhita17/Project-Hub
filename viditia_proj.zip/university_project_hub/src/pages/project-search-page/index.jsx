import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import SearchHeader from "./components/SearchHeader";
import FilterSection from "./components/FilterSection";
import ProjectCard from "./components/ProjectCard";
import RecentSearches from "./components/RecentSearches";
import NoResults from "./components/NoResults";

const ProjectSearchPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState("grid"); // grid or list
  const [filters, setFilters] = useState({
    domains: [],
    departments: [],
    faculties: [],
    statuses: [],
  });
  const [recentSearches, setRecentSearches] = useState([
    "Machine Learning",
    "Blockchain",
    "IoT",
    "Artificial Intelligence",
  ]);
  const [isLoading, setIsLoading] = useState(false);

  // Mock user data
  const userData = {
    name: "Alex Johnson",
    email: "alex.johnson@university.edu",
    department: "Computer Science",
    semester: "7th Semester",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    profileCompletion: 75,
    resumeUploaded: true,
    githubLink: "https://github.com/alexjohnson",
    linkedinLink: "https://linkedin.com/in/alexjohnson",
  };

  // Mock projects data
  const allProjects = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      faculty: "Dr. Sarah Williams",
      department: "Computer Science",
      domain: "Artificial Intelligence",
      description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy.",
      status: "Available",
      postedDate: "2023-10-05",
      deadline: "2023-11-15",
      applied: false,
      tags: ["Machine Learning", "NLP", "Python"],
      requirements: "Strong knowledge of Python, experience with NLP libraries, and understanding of machine learning concepts.",
    },
    {
      id: 2,
      title: "Blockchain for Supply Chain Management",
      faculty: "Prof. Michael Chen",
      department: "Information Systems",
      domain: "Blockchain",
      description: "Implementation of blockchain technology to improve transparency and efficiency in supply chain management systems.",
      status: "Available",
      postedDate: "2023-10-10",
      deadline: "2023-11-20",
      applied: true,
      tags: ["Blockchain", "Smart Contracts", "Ethereum"],
      requirements: "Knowledge of blockchain concepts, experience with Solidity, and understanding of supply chain processes.",
    },
    {
      id: 3,
      title: "Smart City IoT Network Architecture",
      faculty: "Dr. Emily Rodriguez",
      department: "Electrical Engineering",
      domain: "Internet of Things",
      description: "Designing an efficient IoT network architecture for smart city applications with focus on scalability and security.",
      status: "Available",
      postedDate: "2023-09-28",
      deadline: "2023-11-10",
      applied: true,
      tags: ["IoT", "Network Security", "Embedded Systems"],
      requirements: "Knowledge of IoT protocols, experience with embedded systems, and understanding of network security.",
    },
    {
      id: 4,
      title: "Quantum Computing Algorithms for Optimization Problems",
      faculty: "Prof. James Wilson",
      department: "Physics",
      domain: "Quantum Computing",
      description: "Research on quantum algorithms that can solve complex optimization problems more efficiently than classical algorithms.",
      status: "Filled",
      postedDate: "2023-09-20",
      deadline: "2023-10-30",
      applied: false,
      tags: ["Quantum Computing", "Algorithms", "Optimization"],
      requirements: "Strong background in quantum mechanics, linear algebra, and algorithm design.",
    },
    {
      id: 5,
      title: "Augmented Reality for Educational Applications",
      faculty: "Dr. Lisa Thompson",
      department: "Education Technology",
      domain: "Augmented Reality",
      description: "Developing AR applications to enhance learning experiences in K-12 education with focus on STEM subjects.",
      status: "Available",
      postedDate: "2023-10-12",
      deadline: "2023-11-25",
      applied: false,
      tags: ["AR", "Unity", "Education"],
      requirements: "Experience with AR development tools (Unity/ARKit/ARCore), 3D modeling, and understanding of educational pedagogy.",
    },
    {
      id: 6,
      title: "Cybersecurity Risk Assessment Framework",
      faculty: "Prof. Robert Johnson",
      department: "Information Security",
      domain: "Cybersecurity",
      description: "Creating a comprehensive framework for assessing cybersecurity risks in enterprise environments.",
      status: "Available",
      postedDate: "2023-10-08",
      deadline: "2023-11-18",
      applied: false,
      tags: ["Cybersecurity", "Risk Assessment", "Enterprise Security"],
      requirements: "Knowledge of cybersecurity principles, risk assessment methodologies, and enterprise security architecture.",
    },
    {
      id: 7,
      title: "Natural Language Processing for Legal Document Analysis",
      faculty: "Dr. Jennifer Martinez",
      department: "Computer Science",
      domain: "Natural Language Processing",
      description: "Applying NLP techniques to analyze and extract information from legal documents to assist legal professionals.",
      status: "Available",
      postedDate: "2023-10-15",
      deadline: "2023-11-30",
      applied: false,
      tags: ["NLP", "Legal Tech", "Machine Learning"],
      requirements: "Strong programming skills, experience with NLP libraries, and interest in legal technology.",
    },
    {
      id: 8,
      title: "Renewable Energy Grid Integration",
      faculty: "Prof. David Brown",
      department: "Electrical Engineering",
      domain: "Renewable Energy",
      description: "Researching methods to efficiently integrate renewable energy sources into existing power grids.",
      status: "Filled",
      postedDate: "2023-09-25",
      deadline: "2023-10-25",
      applied: false,
      tags: ["Renewable Energy", "Power Systems", "Grid Integration"],
      requirements: "Knowledge of power systems, renewable energy technologies, and simulation tools.",
    },
  ];

  // Extract unique values for filters
  const uniqueDomains = [...new Set(allProjects.map(project => project.domain))];
  const uniqueDepartments = [...new Set(allProjects.map(project => project.department))];
  const uniqueFaculties = [...new Set(allProjects.map(project => project.faculty))];
  const uniqueStatuses = [...new Set(allProjects.map(project => project.status))];

  // Filter projects based on search query and filters
  const filteredProjects = allProjects.filter(project => {
    // Search query filter
    const matchesSearch = 
      searchQuery === "" || 
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.faculty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Domain filter
    const matchesDomain = 
      filters.domains.length === 0 || 
      filters.domains.includes(project.domain);
    
    // Department filter
    const matchesDepartment = 
      filters.departments.length === 0 || 
      filters.departments.includes(project.department);
    
    // Faculty filter
    const matchesFaculty = 
      filters.faculties.length === 0 || 
      filters.faculties.includes(project.faculty);
    
    // Status filter
    const matchesStatus = 
      filters.statuses.length === 0 || 
      filters.statuses.includes(project.status);
    
    return matchesSearch && matchesDomain && matchesDepartment && matchesFaculty && matchesStatus;
  });

  // Handle search submission
  const handleSearch = (query) => {
    setIsLoading(true);
    setSearchQuery(query);
    
    // Add to recent searches if not already there
    if (query && !recentSearches.includes(query)) {
      setRecentSearches(prev => [query, ...prev.slice(0, 4)]);
    }
    
    // Simulate API call delay
    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  };

  // Handle filter changes
  const handleFilterChange = (filterType, values) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: values
    }));
  };

  // Handle view mode toggle
  const toggleViewMode = () => {
    setViewMode(prev => prev === "grid" ? "list" : "grid");
  };

  // Handle applying to a project
  const handleApply = (projectId) => {
    // This would connect to an API in a real application
    console.log(`Applying for project ID: ${projectId}`);
    // Then update the UI accordingly
  };

  // Clear all filters
  const clearAllFilters = () => {
    setFilters({
      domains: [],
      departments: [],
      faculties: [],
      statuses: [],
    });
    setSearchQuery("");
  };

  // Clear a recent search
  const clearRecentSearch = (search) => {
    setRecentSearches(prev => prev.filter(item => item !== search));
  };

  // Use a recent search
  const useRecentSearch = (search) => {
    setSearchQuery(search);
    handleSearch(search);
  };

  // Simulate loading effect when filters change
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 300);
    return () => clearTimeout(timer);
  }, [filters]);

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={userData.profileImage}
                alt={userData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <Link to="/student-profile">
                  <Icon name="Edit" size={16} className="text-white" />
                </Link>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{userData.name}</h2>
            <p className="text-sm text-gray-500">{userData.department}</p>
            <p className="text-sm text-gray-500">{userData.semester}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/student-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/student-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/project-search-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="Search" size={20} className="mr-3" />
                Browse Projects
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  External Profiles
                </h3>
                <div className="mt-2 space-y-2">
                  {userData.githubLink && (
                    <a
                      href={userData.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Github" size={18} className="mr-3" />
                      GitHub
                    </a>
                  )}
                  {userData.linkedinLink && (
                    <a
                      href={userData.linkedinLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Linkedin" size={18} className="mr-3" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <SearchHeader 
          userData={userData} 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery}
          handleSearch={handleSearch}
          viewMode={viewMode}
          toggleViewMode={toggleViewMode}
        />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Page header */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Browse Projects
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Find and apply for projects that match your interests and skills.
              </p>
            </div>

            {/* Main content area */}
            <div className="mt-4">
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
                {/* Filters sidebar */}
                <div className="lg:col-span-1">
                  <FilterSection 
                    domains={uniqueDomains}
                    departments={uniqueDepartments}
                    faculties={uniqueFaculties}
                    statuses={uniqueStatuses}
                    filters={filters}
                    handleFilterChange={handleFilterChange}
                    clearAllFilters={clearAllFilters}
                  />
                  
                  {/* Recent searches */}
                  {recentSearches.length > 0 && (
                    <div className="mt-6">
                      <RecentSearches 
                        searches={recentSearches}
                        useSearch={useRecentSearch}
                        clearSearch={clearRecentSearch}
                      />
                    </div>
                  )}
                </div>

                {/* Projects grid/list */}
                <div className="lg:col-span-3">
                  {/* Results summary */}
                  <div className="bg-white shadow rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="text-lg font-medium text-gray-900">
                          {isLoading ? (
                            <span className="inline-flex items-center">
                              <Icon name="Loader" size={16} className="mr-2 animate-spin" />
                              Searching...
                            </span>
                          ) : (
                            `${filteredProjects.length} ${filteredProjects.length === 1 ? 'Project' : 'Projects'} Found`
                          )}
                        </h2>
                        {(searchQuery || Object.values(filters).some(arr => arr.length > 0)) && (
                          <div className="mt-1 flex flex-wrap items-center gap-2">
                            {searchQuery && (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
                                Search: {searchQuery}
                                <button 
                                  onClick={() => setSearchQuery("")}
                                  className="ml-1 focus:outline-none"
                                >
                                  <Icon name="X" size={12} />
                                </button>
                              </span>
                            )}
                            {filters.domains.map(domain => (
                              <span key={domain} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
                                Domain: {domain}
                                <button 
                                  onClick={() => handleFilterChange('domains', filters.domains.filter(d => d !== domain))}
                                  className="ml-1 focus:outline-none"
                                >
                                  <Icon name="X" size={12} />
                                </button>
                              </span>
                            ))}
                            {filters.departments.map(department => (
                              <span key={department} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
                                Department: {department}
                                <button 
                                  onClick={() => handleFilterChange('departments', filters.departments.filter(d => d !== department))}
                                  className="ml-1 focus:outline-none"
                                >
                                  <Icon name="X" size={12} />
                                </button>
                              </span>
                            ))}
                            {filters.faculties.map(faculty => (
                              <span key={faculty} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
                                Faculty: {faculty}
                                <button 
                                  onClick={() => handleFilterChange('faculties', filters.faculties.filter(f => f !== faculty))}
                                  className="ml-1 focus:outline-none"
                                >
                                  <Icon name="X" size={12} />
                                </button>
                              </span>
                            ))}
                            {filters.statuses.map(status => (
                              <span key={status} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
                                Status: {status}
                                <button 
                                  onClick={() => handleFilterChange('statuses', filters.statuses.filter(s => s !== status))}
                                  className="ml-1 focus:outline-none"
                                >
                                  <Icon name="X" size={12} />
                                </button>
                              </span>
                            ))}
                            {(searchQuery || Object.values(filters).some(arr => arr.length > 0)) && (
                              <button
                                onClick={clearAllFilters}
                                className="text-xs text-primary hover:text-primary-dark font-medium"
                              >
                                Clear All
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center">
                        <span className="mr-2 text-sm text-gray-500">View:</span>
                        <button
                          onClick={toggleViewMode}
                          className={`p-1.5 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary ${
                            viewMode === 'grid' ? 'bg-primary text-white' : 'bg-white text-gray-500 border border-gray-300'
                          }`}
                          aria-label="Grid view"
                        >
                          <Icon name="Grid" size={16} />
                        </button>
                        <button
                          onClick={toggleViewMode}
                          className={`ml-2 p-1.5 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary ${
                            viewMode === 'list' ? 'bg-primary text-white' : 'bg-white text-gray-500 border border-gray-300'
                          }`}
                          aria-label="List view"
                        >
                          <Icon name="List" size={16} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Projects display */}
                  {isLoading ? (
                    <div className="flex justify-center items-center py-12">
                      <Icon name="Loader" size={36} className="text-primary animate-spin" />
                    </div>
                  ) : filteredProjects.length > 0 ? (
                    <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
                      {filteredProjects.map(project => (
                        <ProjectCard
                          key={project.id}
                          project={project}
                          viewMode={viewMode}
                          onApply={handleApply}
                        />
                      ))}
                    </div>
                  ) : (
                    <NoResults 
                      searchQuery={searchQuery} 
                      hasFilters={Object.values(filters).some(arr => arr.length > 0)}
                      clearAllFilters={clearAllFilters}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ProjectSearchPage;