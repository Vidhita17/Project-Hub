import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import ApplicantList from "./components/ApplicantList";
import ApplicantDetail from "./components/ApplicantDetail";
import FilterBar from "./components/FilterBar";
import FacultyHeader from "./components/FacultyHeader";

const ApplicantReviewPage = () => {
  const { id } = useParams();
  const [selectedApplicantId, setSelectedApplicantId] = useState(id || null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showMobileDetail, setShowMobileDetail] = useState(false);

  // Mock faculty data
  const facultyData = {
    name: "Dr. Sarah Williams",
    email: "sarah.williams@university.edu",
    department: "Computer Science",
    position: "Associate Professor",
    profileImage: "https://randomuser.me/api/portraits/women/32.jpg",
    githubLink: "https://github.com/sarahwilliams",
    linkedinLink: "https://linkedin.com/in/sarahwilliams",
  };

  // Mock project data
  const projectData = {
    id: "proj-123",
    title: "AI-Based Sentiment Analysis for Social Media",
    description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy. Students will work on implementing various NLP techniques and compare their effectiveness.",
    domain: "Artificial Intelligence",
    department: "Computer Science",
    duration: "4 months",
    maxStudents: 3,
    prerequisites: "Machine Learning, Natural Language Processing, Python",
    createdDate: "2023-09-01",
    deadline: "2023-10-30",
    status: "Active",
  };

  // Mock applicants data
  const applicantsData = [
    {
      id: 1,
      name: "Alex Johnson",
      email: "alex.johnson@university.edu",
      department: "Computer Science",
      semester: "7th Semester",
      profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
      applicationDate: "2023-10-15",
      status: "New",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/alexjohnson",
      linkedinLink: "https://linkedin.com/in/alexjohnson",
      statementOfInterest: "I am very interested in this project as it aligns perfectly with my research interests in NLP and sentiment analysis. I have completed relevant coursework and have experience with Python and machine learning libraries.",
      gpa: 3.8,
      relevantCourses: ["Machine Learning", "Natural Language Processing", "Data Mining", "Advanced Python Programming"],
      facultyNotes: "",
      githubStats: {
        repositories: 15,
        stars: 25,
        contributions: 342,
        topLanguages: ["Python", "JavaScript", "Java"]
      }
    },
    {
      id: 2,
      name: "Emily Chen",
      email: "emily.chen@university.edu",
      department: "Computer Science",
      semester: "7th Semester",
      profileImage: "https://randomuser.me/api/portraits/women/33.jpg",
      applicationDate: "2023-10-12",
      status: "Shortlisted",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/emilychen",
      linkedinLink: "https://linkedin.com/in/emilychen",
      statementOfInterest: "I have been working on sentiment analysis for my research project and would love to contribute to this project. I have experience with BERT and other transformer models for NLP tasks.",
      gpa: 3.9,
      relevantCourses: ["Machine Learning", "Natural Language Processing", "Deep Learning", "Data Science"],
      facultyNotes: "Strong candidate with excellent NLP background. Consider for team lead role.",
      githubStats: {
        repositories: 20,
        stars: 45,
        contributions: 567,
        topLanguages: ["Python", "R", "C++"]
      }
    },
    {
      id: 3,
      name: "Michael Rodriguez",
      email: "michael.rodriguez@university.edu",
      department: "Data Science",
      semester: "6th Semester",
      profileImage: "https://randomuser.me/api/portraits/men/34.jpg",
      applicationDate: "2023-10-10",
      status: "Reviewed",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/michaelrodriguez",
      linkedinLink: "https://linkedin.com/in/michaelrodriguez",
      statementOfInterest: "I am passionate about applying machine learning to social media data and have completed several projects in this domain. I would bring strong analytical skills to this project.",
      gpa: 3.6,
      relevantCourses: ["Statistical Learning", "Big Data Analytics", "Social Media Mining", "Python for Data Science"],
      facultyNotes: "Good data science background, but less NLP experience than other candidates.",
      githubStats: {
        repositories: 12,
        stars: 18,
        contributions: 289,
        topLanguages: ["Python", "R", "SQL"]
      }
    },
    {
      id: 4,
      name: "Sophia Kim",
      email: "sophia.kim@university.edu",
      department: "Computer Science",
      semester: "8th Semester",
      profileImage: "https://randomuser.me/api/portraits/women/35.jpg",
      applicationDate: "2023-10-08",
      status: "Selected",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/sophiakim",
      linkedinLink: "https://linkedin.com/in/sophiakim",
      statementOfInterest: "As a senior student with experience in both NLP and social media analytics, I believe I can make significant contributions to this project. I have published a paper on sentiment analysis in Twitter data.",
      gpa: 4.0,
      relevantCourses: ["Advanced NLP", "Machine Learning", "Social Network Analysis", "Information Retrieval"],
      facultyNotes: "Exceptional candidate with published research. Already selected.",
      githubStats: {
        repositories: 25,
        stars: 78,
        contributions: 712,
        topLanguages: ["Python", "JavaScript", "TypeScript"]
      }
    },
    {
      id: 5,
      name: "David Patel",
      email: "david.patel@university.edu",
      department: "Electrical Engineering",
      semester: "7th Semester",
      profileImage: "https://randomuser.me/api/portraits/men/36.jpg",
      applicationDate: "2023-10-05",
      status: "Rejected",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/davidpatel",
      linkedinLink: "https://linkedin.com/in/davidpatel",
      statementOfInterest: "I am interested in expanding my knowledge in AI and machine learning through this project. While my background is in electrical engineering, I have taken courses in programming and data analysis.",
      gpa: 3.4,
      relevantCourses: ["Programming Fundamentals", "Signal Processing", "Introduction to AI", "Database Systems"],
      facultyNotes: "Background not closely aligned with project requirements.",
      githubStats: {
        repositories: 8,
        stars: 5,
        contributions: 120,
        topLanguages: ["C++", "MATLAB", "Python"]
      }
    },
    {
      id: 6,
      name: "Olivia Wilson",
      email: "olivia.wilson@university.edu",
      department: "Computer Science",
      semester: "7th Semester",
      profileImage: "https://randomuser.me/api/portraits/women/37.jpg",
      applicationDate: "2023-10-03",
      status: "New",
      resume: "/path/to/resume.pdf",
      githubLink: "https://github.com/oliviawilson",
      linkedinLink: "https://linkedin.com/in/oliviawilson",
      statementOfInterest: "I have a strong interest in NLP and have completed several projects involving text analysis. I am particularly interested in the challenges of sentiment analysis in social media contexts.",
      gpa: 3.7,
      relevantCourses: ["Machine Learning", "Text Mining", "Artificial Intelligence", "Web Development"],
      facultyNotes: "",
      githubStats: {
        repositories: 14,
        stars: 22,
        contributions: 310,
        topLanguages: ["Python", "HTML/CSS", "JavaScript"]
      }
    },
  ];

  // Filter and sort applicants
  const filteredApplicants = applicantsData
    .filter(applicant => {
      // Filter by status
      if (filterStatus !== "all" && applicant.status !== filterStatus) {
        return false;
      }
      
      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          applicant.name.toLowerCase().includes(query) ||
          applicant.email.toLowerCase().includes(query) ||
          applicant.department.toLowerCase().includes(query)
        );
      }
      
      return true;
    })
    .sort((a, b) => {
      // Sort by selected criteria
      if (sortBy === "date") {
        const dateA = new Date(a.applicationDate);
        const dateB = new Date(b.applicationDate);
        return sortOrder === "asc" ? dateA - dateB : dateB - dateA;
      } else if (sortBy === "name") {
        return sortOrder === "asc" 
          ? a.name.localeCompare(b.name) 
          : b.name.localeCompare(a.name);
      } else if (sortBy === "status") {
        return sortOrder === "asc" 
          ? a.status.localeCompare(b.status) 
          : b.status.localeCompare(a.status);
      }
      return 0;
    });

  // Set first applicant as selected if none is selected
  useEffect(() => {
    if (!selectedApplicantId && filteredApplicants.length > 0) {
      setSelectedApplicantId(filteredApplicants[0].id);
    }
  }, [selectedApplicantId, filteredApplicants]);

  const selectedApplicant = applicantsData.find(
    applicant => applicant.id === parseInt(selectedApplicantId)
  );

  const handleStatusChange = (applicantId, newStatus) => {
    // In a real application, this would update the database
    console.log(`Changing status of applicant ${applicantId} to ${newStatus}`);
    // For now, we'll just log it
  };

  const handleSaveNotes = (applicantId, notes) => {
    // In a real application, this would update the database
    console.log(`Saving notes for applicant ${applicantId}: ${notes}`);
    // For now, we'll just log it
  };

  const handleApplicantSelect = (id) => {
    setSelectedApplicantId(id);
    setShowMobileDetail(true);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={facultyData.profileImage}
                alt={facultyData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <Link to="/faculty-profile">
                  <Icon name="Edit" size={16} className="text-white" />
                </Link>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{facultyData.name}</h2>
            <p className="text-sm text-gray-500">{facultyData.department}</p>
            <p className="text-sm text-gray-500">{facultyData.position}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/faculty-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/faculty-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/applicant-review-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="Users" size={20} className="mr-3" />
                Review Applications
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  External Profiles
                </h3>
                <div className="mt-2 space-y-2">
                  {facultyData.githubLink && (
                    <a
                      href={facultyData.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Github" size={18} className="mr-3" />
                      GitHub
                    </a>
                  )}
                  {facultyData.linkedinLink && (
                    <a
                      href={facultyData.linkedinLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Linkedin" size={18} className="mr-3" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <FacultyHeader 
          facultyData={facultyData} 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery}
          showMobileMenu={showMobileMenu}
          setShowMobileMenu={setShowMobileMenu}
        />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Project header */}
            <div className="py-4">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-2xl font-semibold text-gray-900">
                    {projectData.title}
                  </h1>
                  <p className="mt-1 text-sm text-gray-500">
                    Review applicants for this project
                  </p>
                </div>
                <div className="mt-4 md:mt-0 flex items-center">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-light text-success">
                    <Icon name="CheckCircle" size={12} className="mr-1" />
                    {projectData.status}
                  </span>
                  <span className="ml-4 text-sm text-gray-500">
                    Application Deadline: {new Date(projectData.deadline).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Filter bar */}
            <FilterBar 
              filterStatus={filterStatus}
              setFilterStatus={setFilterStatus}
              sortBy={sortBy}
              setSortBy={setSortBy}
              sortOrder={sortOrder}
              setSortOrder={setSortOrder}
              totalApplicants={applicantsData.length}
              filteredCount={filteredApplicants.length}
            />

            {/* Split view container */}
            <div className="mt-4 bg-white shadow rounded-lg overflow-hidden">
              <div className="flex flex-col md:flex-row">
                {/* Applicant list - left panel */}
                <div className={`w-full md:w-1/3 border-r border-gray-200 ${showMobileDetail ? 'hidden' : 'block'} md:block`}>
                  <ApplicantList 
                    applicants={filteredApplicants}
                    selectedApplicantId={selectedApplicantId}
                    onApplicantSelect={handleApplicantSelect}
                  />
                </div>

                {/* Applicant details - right panel */}
                <div className={`w-full md:w-2/3 ${showMobileDetail ? 'block' : 'hidden'} md:block`}>
                  {selectedApplicant ? (
                    <ApplicantDetail 
                      applicant={selectedApplicant}
                      onStatusChange={handleStatusChange}
                      onSaveNotes={handleSaveNotes}
                      onBack={() => setShowMobileDetail(false)}
                    />
                  ) : (
                    <div className="flex items-center justify-center h-96">
                      <div className="text-center">
                        <Icon name="Users" size={48} className="mx-auto text-gray-300" />
                        <h3 className="mt-2 text-sm font-medium text-gray-900">No applicant selected</h3>
                        <p className="mt-1 text-sm text-gray-500">
                          Select an applicant from the list to view details
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ApplicantReviewPage;