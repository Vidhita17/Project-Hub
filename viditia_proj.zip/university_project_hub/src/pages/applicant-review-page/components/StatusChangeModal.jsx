import React from "react";
import Icon from "../../../components/AppIcon";

const StatusChangeModal = ({ currentStatus, newStatus, onConfirm, onCancel }) => {
  // Status configuration
  const statusConfig = {
    New: {
      icon: "Clock",
      color: "text-primary",
    },
    Reviewed: {
      icon: "CheckCircle2",
      color: "text-gray-700",
    },
    Shortlisted: {
      icon: "ListChecks",
      color: "text-warning",
    },
    Selected: {
      icon: "CheckCircle",
      color: "text-success",
    },
    Rejected: {
      icon: "XCircle",
      color: "text-error",
    },
  };

  // Get message based on status change
  const getMessage = () => {
    if (newStatus === "Selected") {
      return "This will mark the applicant as selected for your project. The applicant will be notified about this decision.";
    } else if (newStatus === "Shortlisted") {
      return "This will mark the applicant as shortlisted for your project. The applicant will be notified about this decision.";
    } else if (newStatus === "Rejected") {
      return "This will mark the applicant as rejected for your project. The applicant will be notified about this decision.";
    } else if (newStatus === "Reviewed") {
      return "This will mark the application as reviewed. The applicant will not be notified about this status change.";
    }
    return "Are you sure you want to change the status?";
  };

  return (
    <div className="fixed z-10 inset-0 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 bg-opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
          &#8203;
        </span>

        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <div>
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
              <Icon 
                name={statusConfig[newStatus].icon} 
                size={24} 
                className={statusConfig[newStatus].color} 
              />
            </div>
            <div className="mt-3 text-center sm:mt-5">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                Change Status to {newStatus}?
              </h3>
              <div className="mt-2">
                <p className="text-sm text-gray-500">
                  {getMessage()}
                </p>
              </div>
            </div>
          </div>
          <div className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
            <button
              type="button"
              onClick={onConfirm}
              className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary text-base font-medium text-white hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:col-start-2 sm:text-sm"
            >
              Confirm
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:mt-0 sm:col-start-1 sm:text-sm"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusChangeModal;