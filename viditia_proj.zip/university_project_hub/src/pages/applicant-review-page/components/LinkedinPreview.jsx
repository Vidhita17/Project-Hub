import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const LinkedinPreview = ({ applicant }) => {
  // Mock LinkedIn data
  const linkedinData = {
    headline: "Computer Science Student | Machine Learning Enthusiast | NLP Researcher",
    about: "Passionate about applying machine learning techniques to solve real-world problems. Currently focusing on natural language processing and sentiment analysis in social media data.",
    experience: [
      {
        title: "Research Assistant",
        company: "University AI Lab",
        duration: "Jun 2023 - Present",
        description: "Working on sentiment analysis models for social media content. Implementing and evaluating various NLP techniques."
      },
      {
        title: "Software Engineering Intern",
        company: "Tech Solutions Inc.",
        duration: "May 2022 - Aug 2022",
        description: "Developed and maintained web applications using React and Node.js. Implemented RESTful APIs and database integrations."
      }
    ],
    education: [
      {
        institution: "University of Technology",
        degree: "Bachelor of Science in Computer Science",
        duration: "2020 - 2024",
        description: "Specializing in Artificial Intelligence and Machine Learning. GPA: 3.8/4.0"
      }
    ],
    skills: ["Python", "Machine Learning", "Natural Language Processing", "TensorFlow", "PyTorch", "React", "Node.js", "SQL", "Git"]
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium text-gray-900">LinkedIn Profile</h3>
        <a
          href={applicant.linkedinLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
        >
          <Icon name="ExternalLink" size={14} className="mr-1.5" />
          View Profile
        </a>
      </div>

      {/* Profile header */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-500 to-blue-600"></div>
        <div className="px-4 sm:px-6 pb-5">
          <div className="flex items-end -mt-12">
            <div className="flex-shrink-0">
              <Image
                src={applicant.profileImage}
                alt={applicant.name}
                className="h-24 w-24 rounded-full ring-4 ring-white"
              />
            </div>
            <div className="ml-4 mt-10">
              <h2 className="text-xl font-bold text-gray-900">{applicant.name}</h2>
              <p className="text-sm text-gray-500">{linkedinData.headline}</p>
            </div>
          </div>
        </div>
      </div>

      {/* About */}
      <div>
        <h4 className="text-sm font-medium text-gray-900">About</h4>
        <div className="mt-2 p-4 bg-gray-50 rounded-md">
          <p className="text-sm text-gray-700">{linkedinData.about}</p>
        </div>
      </div>

      {/* Experience */}
      <div>
        <h4 className="text-sm font-medium text-gray-900">Experience</h4>
        <div className="mt-2 space-y-4">
          {linkedinData.experience.map((exp, index) => (
            <div key={index} className="border border-gray-200 rounded-md p-4">
              <div className="flex justify-between">
                <div>
                  <h5 className="text-sm font-medium text-gray-900">{exp.title}</h5>
                  <p className="text-sm text-gray-500">{exp.company}</p>
                </div>
                <p className="text-xs text-gray-500">{exp.duration}</p>
              </div>
              <p className="mt-2 text-sm text-gray-700">{exp.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Education */}
      <div>
        <h4 className="text-sm font-medium text-gray-900">Education</h4>
        <div className="mt-2 space-y-4">
          {linkedinData.education.map((edu, index) => (
            <div key={index} className="border border-gray-200 rounded-md p-4">
              <div className="flex justify-between">
                <div>
                  <h5 className="text-sm font-medium text-gray-900">{edu.institution}</h5>
                  <p className="text-sm text-gray-500">{edu.degree}</p>
                </div>
                <p className="text-xs text-gray-500">{edu.duration}</p>
              </div>
              <p className="mt-2 text-sm text-gray-700">{edu.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Skills */}
      <div>
        <h4 className="text-sm font-medium text-gray-900">Skills</h4>
        <div className="mt-2 flex flex-wrap gap-2">
          {linkedinData.skills.map((skill, index) => (
            <span
              key={index}
              className="inline-flex items-center px-2.5 py-0.5 rounded-md text-sm font-medium bg-gray-100 text-gray-800"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LinkedinPreview;