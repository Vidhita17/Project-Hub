import React from "react";
import Icon from "../../../components/AppIcon";

const FilterBar = ({ 
  filterStatus, 
  setFilterStatus, 
  sortBy, 
  setSortBy, 
  sortOrder, 
  setSortOrder,
  totalApplicants,
  filteredCount
}) => {
  // Status options for filtering
  const statusOptions = [
    { value: "all", label: "All" },
    { value: "New", label: "New" },
    { value: "Reviewed", label: "Reviewed" },
    { value: "Shortlisted", label: "Shortlisted" },
    { value: "Selected", label: "Selected" },
    { value: "Rejected", label: "Rejected" },
  ];

  // Sort options
  const sortOptions = [
    { value: "date", label: "Application Date" },
    { value: "name", label: "Name" },
    { value: "status", label: "Status" },
  ];

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <div>
            <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Filter by Status
            </label>
            <select
              id="status-filter"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
            >
              {statusOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="sort-by" className="block text-sm font-medium text-gray-700 mb-1">
              Sort by
            </label>
            <select
              id="sort-by"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="sort-order" className="block text-sm font-medium text-gray-700 mb-1">
              Order
            </label>
            <button
              type="button"
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon 
                name={sortOrder === "asc" ? "ArrowUp" : "ArrowDown"} 
                size={16} 
                className="mr-2" 
              />
              {sortOrder === "asc" ? "Ascending" : "Descending"}
            </button>
          </div>
        </div>
        
        <div className="text-sm text-gray-500">
          Showing {filteredCount} of {totalApplicants} applicants
        </div>
      </div>
    </div>
  );
};

export default FilterBar;