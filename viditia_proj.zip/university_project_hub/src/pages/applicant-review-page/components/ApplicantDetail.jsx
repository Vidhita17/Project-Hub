import React, { useState } from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";
import StatusChangeModal from "./StatusChangeModal";
import GithubPreview from "./GithubPreview";
import LinkedinPreview from "./LinkedinPreview";

const ApplicantDetail = ({ applicant, onStatusChange, onSaveNotes, onBack }) => {
  const [notes, setNotes] = useState(applicant.facultyNotes || "");
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [newStatus, setNewStatus] = useState("");
  const [activeTab, setActiveTab] = useState("profile");

  // Status badge configuration
  const statusConfig = {
    New: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Clock",
    },
    Reviewed: {
      bgColor: "bg-gray-100",
      textColor: "text-gray-700",
      icon: "CheckCircle2",
    },
    Shortlisted: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "ListChecks",
    },
    Selected: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Rejected: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  const config = statusConfig[applicant.status];

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleStatusClick = (status) => {
    setNewStatus(status);
    setShowStatusModal(true);
  };

  const confirmStatusChange = () => {
    onStatusChange(applicant.id, newStatus);
    setShowStatusModal(false);
  };

  const handleSaveNotes = () => {
    onSaveNotes(applicant.id, notes);
  };

  return (
    <div className="h-full overflow-y-auto max-h-[calc(100vh-220px)]">
      {/* Mobile back button */}
      <div className="md:hidden px-4 py-3 border-b border-gray-200 bg-gray-50">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center text-sm font-medium text-primary hover:text-primary-dark"
        >
          <Icon name="ChevronLeft" size={16} className="mr-1" />
          Back to list
        </button>
      </div>

      {/* Applicant header */}
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0 h-16 w-16">
              <Image
                src={applicant.profileImage}
                alt={applicant.name}
                className="h-16 w-16 rounded-full"
              />
            </div>
            <div className="ml-4">
              <h2 className="text-xl font-medium text-gray-900">{applicant.name}</h2>
              <div className="mt-1 flex flex-col sm:flex-row sm:flex-wrap sm:mt-0 sm:space-x-6">
                <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                  <Icon name="Mail" size={16} className="mr-1.5 text-gray-400" />
                  {applicant.email}
                </div>
                <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                  <Icon name="GraduationCap" size={16} className="mr-1.5 text-gray-400" />
                  {applicant.department}, {applicant.semester}
                </div>
                <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                  <Icon name="Calendar" size={16} className="mr-1.5 text-gray-400" />
                  Applied on {formatDate(applicant.applicationDate)}
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 sm:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
            <div
              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
            >
              <Icon name={config.icon} size={12} className="mr-1" />
              {applicant.status}
            </div>
            <div className="flex space-x-2">
              {applicant.status !== "Selected" && (
                <button
                  type="button"
                  onClick={() => handleStatusClick("Selected")}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-success hover:bg-success focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-success"
                >
                  <Icon name="CheckCircle" size={14} className="mr-1.5" />
                  Select
                </button>
              )}
              {applicant.status !== "Shortlisted" && applicant.status !== "Selected" && (
                <button
                  type="button"
                  onClick={() => handleStatusClick("Shortlisted")}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-warning hover:bg-warning focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-warning"
                >
                  <Icon name="ListChecks" size={14} className="mr-1.5" />
                  Shortlist
                </button>
              )}
              {applicant.status !== "Rejected" && (
                <button
                  type="button"
                  onClick={() => handleStatusClick("Rejected")}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-error hover:bg-error focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-error"
                >
                  <Icon name="XCircle" size={14} className="mr-1.5" />
                  Reject
                </button>
              )}
              {applicant.status !== "Reviewed" && applicant.status === "New" && (
                <button
                  type="button"
                  onClick={() => handleStatusClick("Reviewed")}
                  className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="CheckCircle2" size={14} className="mr-1.5" />
                  Mark as Reviewed
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex -mb-px">
          <button
            className={`px-6 py-3 border-b-2 text-sm font-medium ${
              activeTab === "profile" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={() => setActiveTab("profile")}
          >
            Profile
          </button>
          <button
            className={`px-6 py-3 border-b-2 text-sm font-medium ${
              activeTab === "github" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={() => setActiveTab("github")}
          >
            GitHub
          </button>
          <button
            className={`px-6 py-3 border-b-2 text-sm font-medium ${
              activeTab === "linkedin" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={() => setActiveTab("linkedin")}
          >
            LinkedIn
          </button>
          <button
            className={`px-6 py-3 border-b-2 text-sm font-medium ${
              activeTab === "notes" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
            onClick={() => setActiveTab("notes")}
          >
            Notes
          </button>
        </nav>
      </div>

      {/* Tab content */}
      <div className="px-6 py-5">
        {activeTab === "profile" && (
          <div className="space-y-6">
            {/* Academic info */}
            <div>
              <h3 className="text-lg font-medium text-gray-900">Academic Information</h3>
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="text-sm font-medium text-gray-500">GPA</div>
                  <div className="mt-1 text-lg font-semibold text-gray-900">{applicant.gpa}</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="text-sm font-medium text-gray-500">Semester</div>
                  <div className="mt-1 text-lg font-semibold text-gray-900">{applicant.semester}</div>
                </div>
              </div>
            </div>

            {/* Relevant courses */}
            <div>
              <h3 className="text-lg font-medium text-gray-900">Relevant Courses</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {applicant.relevantCourses.map((course, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2.5 py-0.5 rounded-md text-sm font-medium bg-gray-100 text-gray-800"
                  >
                    {course}
                  </span>
                ))}
              </div>
            </div>

            {/* Statement of interest */}
            <div>
              <h3 className="text-lg font-medium text-gray-900">Statement of Interest</h3>
              <div className="mt-2 p-4 bg-gray-50 rounded-md">
                <p className="text-sm text-gray-700">{applicant.statementOfInterest}</p>
              </div>
            </div>

            {/* Resume */}
            <div>
              <h3 className="text-lg font-medium text-gray-900">Resume</h3>
              <div className="mt-2 border border-gray-200 rounded-md p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Icon name="FileText" size={24} className="text-gray-400" />
                    <span className="ml-2 text-sm text-gray-700">resume.pdf</span>
                  </div>
                  <a
                    href={applicant.resume}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    <Icon name="Download" size={14} className="mr-1.5" />
                    Download
                  </a>
                </div>
                <div className="mt-4 border border-gray-200 rounded-md h-64 flex items-center justify-center bg-gray-50">
                  <div className="text-center">
                    <Icon name="FileText" size={48} className="mx-auto text-gray-300" />
                    <p className="mt-2 text-sm text-gray-500">Resume preview</p>
                  </div>
                </div>
              </div>
            </div>

            {/* External profiles */}
            <div>
              <h3 className="text-lg font-medium text-gray-900">External Profiles</h3>
              <div className="mt-2 space-y-2">
                {applicant.githubLink && (
                  <a
                    href={applicant.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-2 hover:bg-gray-50 rounded-md"
                  >
                    <Icon name="Github" size={20} className="text-gray-700" />
                    <span className="ml-2 text-sm text-primary">{applicant.githubLink}</span>
                  </a>
                )}
                {applicant.linkedinLink && (
                  <a
                    href={applicant.linkedinLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-2 hover:bg-gray-50 rounded-md"
                  >
                    <Icon name="Linkedin" size={20} className="text-gray-700" />
                    <span className="ml-2 text-sm text-primary">{applicant.linkedinLink}</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === "github" && (
          <GithubPreview applicant={applicant} />
        )}

        {activeTab === "linkedin" && (
          <LinkedinPreview applicant={applicant} />
        )}

        {activeTab === "notes" && (
          <div>
            <h3 className="text-lg font-medium text-gray-900">Faculty Notes</h3>
            <p className="mt-1 text-sm text-gray-500">
              These notes are private and only visible to you.
            </p>
            <div className="mt-4">
              <textarea
                rows={6}
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border border-gray-300 rounded-md"
                placeholder="Add your notes about this applicant here..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              ></textarea>
            </div>
            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={handleSaveNotes}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <Icon name="Save" size={16} className="mr-2" />
                Save Notes
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Status change confirmation modal */}
      {showStatusModal && (
        <StatusChangeModal
          currentStatus={applicant.status}
          newStatus={newStatus}
          onConfirm={confirmStatusChange}
          onCancel={() => setShowStatusModal(false)}
        />
      )}
    </div>
  );
};

export default ApplicantDetail;