import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const ApplicantList = ({ applicants, selectedApplicantId, onApplicantSelect }) => {
  // Status badge configuration
  const statusConfig = {
    New: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Clock",
    },
    Reviewed: {
      bgColor: "bg-gray-100",
      textColor: "text-gray-700",
      icon: "CheckCircle2",
    },
    Shortlisted: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "ListChecks",
    },
    Selected: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Rejected: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="h-full">
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h2 className="text-lg font-medium text-gray-900">Applicants</h2>
      </div>
      
      {applicants.length > 0 ? (
        <ul className="divide-y divide-gray-200 overflow-y-auto max-h-[calc(100vh-220px)]">
          {applicants.map((applicant) => {
            const config = statusConfig[applicant.status];
            const isSelected = parseInt(selectedApplicantId) === applicant.id;
            
            return (
              <li 
                key={applicant.id}
                className={`hover:bg-gray-50 cursor-pointer ${isSelected ? 'bg-primary-light' : ''}`}
                onClick={() => onApplicantSelect(applicant.id)}
              >
                <div className="px-4 py-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10">
                        <Image
                          src={applicant.profileImage}
                          alt={applicant.name}
                          className="h-10 w-10 rounded-full"
                        />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{applicant.name}</div>
                        <div className="text-sm text-gray-500">{applicant.department}</div>
                      </div>
                    </div>
                    <div
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
                    >
                      <Icon name={config.icon} size={12} className="mr-1" />
                      {applicant.status}
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-gray-500">
                    Applied on {formatDate(applicant.applicationDate)}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <div className="flex flex-col items-center justify-center h-64">
          <Icon name="Users" size={48} className="text-gray-300" />
          <p className="mt-2 text-sm text-gray-500">No applicants found</p>
        </div>
      )}
    </div>
  );
};

export default ApplicantList;