import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import ProfileHeader from "./components/ProfileHeader";
import PersonalInfoSection from "./components/PersonalInfoSection";
import ProjectsTable from "./components/ProjectsTable";
import PasswordSection from "./components/PasswordSection";

const FacultyProfile = () => {
  const [activeTab, setActiveTab] = useState("active");
  
  // Mock faculty data
  const facultyData = {
    id: 1,
    name: "Dr. Sarah Williams",
    designation: "Associate Professor",
    department: "Computer Science",
    email: "sarah.williams@university.edu",
    phone: "+1 (555) 123-4567",
    office: "Room 302, Computer Science Building",
    officeHours: "Monday, Wednesday: 2:00 PM - 4:00 PM",
    profileImage: "https://randomuser.me/api/portraits/women/32.jpg",
    biography: `I am a dedicated researcher and educator specializing in Artificial Intelligence and Machine Learning. With over 15 years of experience in the field, I have published numerous papers in top-tier conferences and journals.

My research focuses on developing novel machine learning algorithms for real-world applications, particularly in the areas of natural language processing and computer vision. I am passionate about mentoring students and helping them develop their research skills.

I received my Ph.D. in Computer Science from Stanford University and previously worked as a research scientist at Google AI before joining the university.`,
    researchInterests: [
      "Artificial Intelligence",
      "Machine Learning",
      "Natural Language Processing",
      "Computer Vision",
      "Human-Computer Interaction"
    ],
    education: [
      {
        degree: "Ph.D. in Computer Science",
        institution: "Stanford University",
        year: "2008"
      },
      {
        degree: "M.S. in Computer Science",
        institution: "Massachusetts Institute of Technology",
        year: "2004"
      },
      {
        degree: "B.S. in Computer Science",
        institution: "University of California, Berkeley",
        year: "2002"
      }
    ],
    publications: [
      {
        title: "Advances in Neural Network Architectures for Image Recognition",
        journal: "Journal of Artificial Intelligence Research",
        year: "2022"
      },
      {
        title: "Transformer Models for Efficient Natural Language Understanding",
        conference: "Conference on Neural Information Processing Systems (NeurIPS)",
        year: "2021"
      },
      {
        title: "Ethical Considerations in AI Development",
        journal: "AI Ethics Journal",
        year: "2020"
      }
    ]
  };

  // Mock projects data
  const activeProjects = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy.",
      domain: "Artificial Intelligence",
      postedDate: "2023-10-01",
      applicationDeadline: "2023-11-15",
      duration: "6 months",
      applicationsCount: 12,
      status: "Open",
      requirements: "Strong background in NLP, experience with Python and deep learning frameworks",
      applicants: [
        {
          id: 101,
          name: "Alex Johnson",
          department: "Computer Science",
          semester: "7th Semester",
          appliedDate: "2023-10-15",
          status: "Shortlisted",
          resumeUrl: "/resumes/alex_johnson.pdf",
          githubLink: "https://github.com/alexjohnson",
          linkedinLink: "https://linkedin.com/in/alexjohnson"
        },
        {
          id: 102,
          name: "Emily Chen",
          department: "Computer Science",
          semester: "7th Semester",
          appliedDate: "2023-10-10",
          status: "Applied",
          resumeUrl: "/resumes/emily_chen.pdf",
          githubLink: "https://github.com/emilychen",
          linkedinLink: "https://linkedin.com/in/emilychen"
        }
      ]
    },
    {
      id: 2,
      title: "Explainable AI for Healthcare Diagnostics",
      description: "Developing interpretable machine learning models for medical diagnosis that can explain their decision-making process to healthcare professionals.",
      domain: "Healthcare AI",
      postedDate: "2023-09-15",
      applicationDeadline: "2023-10-30",
      duration: "8 months",
      applicationsCount: 8,
      status: "Open",
      requirements: "Knowledge of medical imaging, experience with explainable AI techniques",
      applicants: [
        {
          id: 103,
          name: "Michael Rodriguez",
          department: "Biomedical Engineering",
          semester: "8th Semester",
          appliedDate: "2023-09-20",
          status: "Selected",
          resumeUrl: "/resumes/michael_rodriguez.pdf",
          githubLink: "https://github.com/michaelrodriguez",
          linkedinLink: "https://linkedin.com/in/michaelrodriguez"
        }
      ]
    },
    {
      id: 3,
      title: "Reinforcement Learning for Autonomous Vehicles",
      description: "Implementing and testing reinforcement learning algorithms for decision-making in autonomous driving scenarios.",
      domain: "Reinforcement Learning",
      postedDate: "2023-08-20",
      applicationDeadline: "2023-10-15",
      duration: "12 months",
      applicationsCount: 15,
      status: "Closed",
      requirements: "Strong background in reinforcement learning, experience with simulation environments",
      applicants: [
        {
          id: 104,
          name: "Sophia Lee",
          department: "Computer Science",
          semester: "8th Semester",
          appliedDate: "2023-08-25",
          status: "Selected",
          resumeUrl: "/resumes/sophia_lee.pdf",
          githubLink: "https://github.com/sophialee",
          linkedinLink: "https://linkedin.com/in/sophialee"
        },
        {
          id: 105,
          name: "David Kim",
          department: "Electrical Engineering",
          semester: "7th Semester",
          appliedDate: "2023-08-30",
          status: "Rejected",
          resumeUrl: "/resumes/david_kim.pdf",
          githubLink: "https://github.com/davidkim",
          linkedinLink: "https://linkedin.com/in/davidkim"
        }
      ]
    }
  ];

  const pastProjects = [
    {
      id: 4,
      title: "Deep Learning for Image Segmentation",
      description: "Developed advanced neural network architectures for precise image segmentation in medical imaging applications.",
      domain: "Computer Vision",
      postedDate: "2022-09-10",
      applicationDeadline: "2022-10-15",
      duration: "6 months",
      applicationsCount: 10,
      status: "Completed",
      requirements: "Experience with CNN architectures, medical image processing",
      applicants: [
        {
          id: 106,
          name: "James Wilson",
          department: "Computer Science",
          semester: "8th Semester (Graduated)",
          appliedDate: "2022-09-15",
          status: "Selected",
          resumeUrl: "/resumes/james_wilson.pdf",
          githubLink: "https://github.com/jameswilson",
          linkedinLink: "https://linkedin.com/in/jameswilson"
        }
      ],
      outcome: "Published paper in IEEE Conference on Computer Vision and Pattern Recognition (CVPR)"
    },
    {
      id: 5,
      title: "Natural Language Processing for Legal Document Analysis",
      description: "Created NLP models to automatically extract and classify important information from legal documents.",
      domain: "Natural Language Processing",
      postedDate: "2022-02-15",
      applicationDeadline: "2022-03-30",
      duration: "9 months",
      applicationsCount: 7,
      status: "Completed",
      requirements: "Knowledge of NLP techniques, interest in legal text processing",
      applicants: [
        {
          id: 107,
          name: "Olivia Martinez",
          department: "Computer Science",
          semester: "8th Semester (Graduated)",
          appliedDate: "2022-02-20",
          status: "Selected",
          resumeUrl: "/resumes/olivia_martinez.pdf",
          githubLink: "https://github.com/oliviamartinez",
          linkedinLink: "https://linkedin.com/in/oliviamartinez"
        }
      ],
      outcome: "Developed software now used by the university\'s law department"
    }
  ];

  // Filter projects based on active tab
  const displayedProjects = activeTab === "active" ? activeProjects : pastProjects;

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={facultyData.profileImage}
                alt={facultyData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <button>
                  <Icon name="Edit" size={16} className="text-white" />
                </button>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{facultyData.name}</h2>
            <p className="text-sm text-gray-500">{facultyData.designation}</p>
            <p className="text-sm text-gray-500">{facultyData.department}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/faculty-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/faculty-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/applicant-review-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="Users" size={20} className="mr-3" />
                Review Applicants
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Project Management
                </h3>
                <div className="mt-2 space-y-2">
                  <Link
                    to="/faculty-dashboard"
                    className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                  >
                    <Icon name="Plus" size={18} className="mr-3" />
                    Create New Project
                  </Link>
                  <Link
                    to="/faculty-dashboard"
                    className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                  >
                    <Icon name="ClipboardList" size={18} className="mr-3" />
                    Manage Projects
                  </Link>
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <ProfileHeader facultyData={facultyData} />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Page header */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Faculty Profile
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Manage your personal information and project offerings.
              </p>
            </div>

            {/* Personal Information Section */}
            <div className="mt-4">
              <PersonalInfoSection facultyData={facultyData} />
            </div>

            {/* Projects Section */}
            <div className="mt-8">
              <div className="bg-white shadow rounded-lg overflow-hidden">
                <div className="px-6 py-5 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium text-gray-900">
                      Your Projects
                    </h2>
                    <Link
                      to="/faculty-dashboard"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Plus" size={16} className="mr-2" />
                      Create New Project
                    </Link>
                  </div>
                  <div className="mt-4 border-b border-gray-200">
                    <nav className="-mb-px flex space-x-8">
                      <button
                        onClick={() => setActiveTab("active")}
                        className={`${
                          activeTab === "active" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                        } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                      >
                        Active Projects
                      </button>
                      <button
                        onClick={() => setActiveTab("past")}
                        className={`${
                          activeTab === "past" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                        } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                      >
                        Past Projects
                      </button>
                    </nav>
                  </div>
                </div>
                <ProjectsTable 
                  projects={displayedProjects} 
                  isPastProjects={activeTab === "past"} 
                />
              </div>
            </div>

            {/* Password Management Section */}
            <div className="mt-8">
              <PasswordSection />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default FacultyProfile;