import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const ApplicantsList = ({ applicants, projectId }) => {
  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Status badge configuration
  const statusConfig = {
    Applied: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Clock",
    },
    Shortlisted: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "ListChecks",
    },
    Selected: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Rejected: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  return (
    <div>
      <h4 className="font-medium text-gray-900 mb-3">Applicants ({applicants.length})</h4>
      
      {applicants.length > 0 ? (
        <div className="overflow-x-auto border border-gray-200 rounded-md">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Applied On
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {applicants.map((applicant) => {
                const config = statusConfig[applicant.status] || statusConfig.Applied;
                return (
                  <tr key={applicant.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-8 w-8">
                          <Image
                            src={`https://randomuser.me/api/portraits/${applicant.id % 2 === 0 ? 'women' : 'men'}/${applicant.id % 100}.jpg`}
                            alt={applicant.name}
                            className="h-8 w-8 rounded-full"
                          />
                        </div>
                        <div className="ml-3">
                          <div className="text-sm font-medium text-gray-900">{applicant.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{applicant.department}</div>
                      <div className="text-xs text-gray-500">{applicant.semester}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatDate(applicant.appliedDate)}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
                      >
                        <Icon name={config.icon} size={12} className="mr-1" />
                        {applicant.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        {applicant.resumeUrl && (
                          <a
                            href={applicant.resumeUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                            title="Download Resume"
                          >
                            <Icon name="FileText" size={16} />
                          </a>
                        )}
                        {applicant.githubLink && (
                          <a
                            href={applicant.githubLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                            title="GitHub Profile"
                          >
                            <Icon name="Github" size={16} />
                          </a>
                        )}
                        {applicant.linkedinLink && (
                          <a
                            href={applicant.linkedinLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                            title="LinkedIn Profile"
                          >
                            <Icon name="Linkedin" size={16} />
                          </a>
                        )}
                        <Link
                          to={`/applicant-review-page?projectId=${projectId}&applicantId=${applicant.id}`}
                          className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                          title="Review Application"
                        >
                          <Icon name="Eye" size={16} />
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-6 bg-gray-50 rounded-md">
          <Icon
            name="Users"
            size={36}
            className="mx-auto text-gray-300"
          />
          <h3 className="mt-2 text-sm font-medium text-gray-900">
            No applicants yet
          </h3>
          <p className="mt-1 text-sm text-gray-500">
            No students have applied to this project yet.
          </p>
        </div>
      )}
    </div>
  );
};

export default ApplicantsList;