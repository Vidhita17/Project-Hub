import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const PasswordSection = () => {
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [errors, setErrors] = useState({});
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData({
      ...passwordData,
      [name]: value
    });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!passwordData.currentPassword) {
      newErrors.currentPassword = "Current password is required";
    }
    
    if (!passwordData.newPassword) {
      newErrors.newPassword = "New password is required";
    } else if (passwordData.newPassword.length < 8) {
      newErrors.newPassword = "Password must be at least 8 characters";
    }
    
    if (!passwordData.confirmPassword) {
      newErrors.confirmPassword = "Please confirm your new password";
    } else if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      // In a real application, this would send the password update to an API
      console.log("Changing password:", passwordData);
      
      // Reset form and show success message
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
      setIsChangingPassword(false);
      
      // Here you would typically show a success notification
    }
  };

  const handleCancel = () => {
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
    setErrors({});
    setIsChangingPassword(false);
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">
            Password Management
          </h2>
          {!isChangingPassword && (
            <button
              type="button"
              onClick={() => setIsChangingPassword(true)}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Lock" size={16} className="mr-2" />
              Change Password
            </button>
          )}
        </div>
      </div>

      <div className="px-6 py-5">
        {isChangingPassword ? (
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700">
                  Current Password
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <input
                    type={showCurrentPassword ? "text" : "password"}
                    name="currentPassword"
                    id="currentPassword"
                    value={passwordData.currentPassword}
                    onChange={handleInputChange}
                    className={`block w-full pr-10 border ${
                      errors.currentPassword ? "border-error focus:ring-error focus:border-error" : "border-gray-300 focus:ring-primary focus:border-primary"
                    } rounded-md shadow-sm py-2 px-3 focus:outline-none sm:text-sm`}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    <Icon name={showCurrentPassword ? "EyeOff" : "Eye"} size={16} />
                  </button>
                </div>
                {errors.currentPassword && (
                  <p className="mt-1 text-sm text-error">{errors.currentPassword}</p>
                )}
              </div>

              <div>
                <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700">
                  New Password
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <input
                    type={showNewPassword ? "text" : "password"}
                    name="newPassword"
                    id="newPassword"
                    value={passwordData.newPassword}
                    onChange={handleInputChange}
                    className={`block w-full pr-10 border ${
                      errors.newPassword ? "border-error focus:ring-error focus:border-error" : "border-gray-300 focus:ring-primary focus:border-primary"
                    } rounded-md shadow-sm py-2 px-3 focus:outline-none sm:text-sm`}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    <Icon name={showNewPassword ? "EyeOff" : "Eye"} size={16} />
                  </button>
                </div>
                {errors.newPassword ? (
                  <p className="mt-1 text-sm text-error">{errors.newPassword}</p>
                ) : (
                  <p className="mt-1 text-xs text-gray-500">
                    Password must be at least 8 characters long.
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                  Confirm New Password
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    name="confirmPassword"
                    id="confirmPassword"
                    value={passwordData.confirmPassword}
                    onChange={handleInputChange}
                    className={`block w-full pr-10 border ${
                      errors.confirmPassword ? "border-error focus:ring-error focus:border-error" : "border-gray-300 focus:ring-primary focus:border-primary"
                    } rounded-md shadow-sm py-2 px-3 focus:outline-none sm:text-sm`}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    <Icon name={showConfirmPassword ? "EyeOff" : "Eye"} size={16} />
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="mt-1 text-sm text-error">{errors.confirmPassword}</p>
                )}
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={handleCancel}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <Icon name="Save" size={16} className="mr-2" />
                Update Password
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center py-6">
            <Icon
              name="Shield"
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              Password Management
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Your password was last changed on October 15, 2023.
            </p>
            <p className="mt-1 text-sm text-gray-500">
              It's recommended to change your password every 90 days for security reasons.
            </p>
            <div className="mt-6">
              <button
                type="button"
                onClick={() => setIsChangingPassword(true)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <Icon name="Lock" size={16} className="mr-2" />
                Change Password
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PasswordSection;