import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const PersonalInfoSection = ({ facultyData }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({
    name: facultyData.name,
    designation: facultyData.designation,
    department: facultyData.department,
    email: facultyData.email,
    phone: facultyData.phone,
    office: facultyData.office,
    officeHours: facultyData.officeHours,
    biography: facultyData.biography
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedData({
      ...editedData,
      [name]: value
    });
  };

  const handleSave = () => {
    // In a real application, this would send the updated data to an API
    console.log("Saving updated faculty data:", editedData);
    setIsEditing(false);
    // Here you would typically update the facultyData state in the parent component
  };

  const handleCancel = () => {
    setEditedData({
      name: facultyData.name,
      designation: facultyData.designation,
      department: facultyData.department,
      email: facultyData.email,
      phone: facultyData.phone,
      office: facultyData.office,
      officeHours: facultyData.officeHours,
      biography: facultyData.biography
    });
    setIsEditing(false);
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">
            Personal Information
          </h2>
          <button
            type="button"
            onClick={() => isEditing ? handleSave() : setIsEditing(true)}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name={isEditing ? "Save" : "Edit"} size={16} className="mr-2" />
            {isEditing ? "Save Changes" : "Edit Profile"}
          </button>
        </div>
      </div>

      <div className="px-6 py-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500">Basic Information</h3>
            <div className="mt-4 space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={editedData.name}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.name}</p>
                )}
              </div>
              <div>
                <label htmlFor="designation" className="block text-sm font-medium text-gray-700">
                  Designation
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="designation"
                    id="designation"
                    value={editedData.designation}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.designation}</p>
                )}
              </div>
              <div>
                <label htmlFor="department" className="block text-sm font-medium text-gray-700">
                  Department
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="department"
                    id="department"
                    value={editedData.department}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.department}</p>
                )}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-500">Contact Information</h3>
            <div className="mt-4 space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email Address
                </label>
                {isEditing ? (
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={editedData.email}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.email}</p>
                )}
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                  Phone Number
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="phone"
                    id="phone"
                    value={editedData.phone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.phone}</p>
                )}
              </div>
              <div>
                <label htmlFor="office" className="block text-sm font-medium text-gray-700">
                  Office Location
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="office"
                    id="office"
                    value={editedData.office}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.office}</p>
                )}
              </div>
              <div>
                <label htmlFor="officeHours" className="block text-sm font-medium text-gray-700">
                  Office Hours
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="officeHours"
                    id="officeHours"
                    value={editedData.officeHours}
                    onChange={handleInputChange}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                  />
                ) : (
                  <p className="mt-1 text-sm text-gray-900">{facultyData.officeHours}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-500">Biography</h3>
          {isEditing ? (
            <textarea
              name="biography"
              id="biography"
              rows={6}
              value={editedData.biography}
              onChange={handleInputChange}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            />
          ) : (
            <p className="mt-1 text-sm text-gray-900 whitespace-pre-line">{facultyData.biography}</p>
          )}
        </div>

        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-500">Research Interests</h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {facultyData.researchInterests.map((interest, index) => (
              <span
                key={index}
                className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-primary-light text-primary"
              >
                {interest}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-500">Education</h3>
          <ul className="mt-2 space-y-2">
            {facultyData.education.map((edu, index) => (
              <li key={index} className="text-sm text-gray-900">
                <span className="font-medium">{edu.degree}</span> - {edu.institution}, {edu.year}
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-500">Selected Publications</h3>
          <ul className="mt-2 space-y-2">
            {facultyData.publications.map((pub, index) => (
              <li key={index} className="text-sm text-gray-900">
                <span className="font-medium">{pub.title}</span>
                {pub.journal && <span> - {pub.journal}</span>}
                {pub.conference && <span> - {pub.conference}</span>}
                <span>, {pub.year}</span>
              </li>
            ))}
          </ul>
        </div>

        {isEditing && (
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={handleCancel}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Save Changes
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalInfoSection;