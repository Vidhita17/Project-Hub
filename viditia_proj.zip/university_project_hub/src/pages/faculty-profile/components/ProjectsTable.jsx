import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";
import ApplicantsList from "./ApplicantsList";

const ProjectsTable = ({ projects, isPastProjects }) => {
  const [expandedProject, setExpandedProject] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: 'postedDate', direction: 'desc' });

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Handle sorting
  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // Get sorted projects
  const getSortedProjects = () => {
    const sortableProjects = [...projects];
    if (sortConfig.key) {
      sortableProjects.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableProjects;
  };

  // Get sort direction indicator
  const getSortDirectionIndicator = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? 
      <Icon name="ChevronUp" size={16} className="ml-1" /> : 
      <Icon name="ChevronDown" size={16} className="ml-1" />;
  };

  // Status badge configuration
  const statusConfig = {
    Open: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Closed: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
    Completed: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "CheckSquare",
    },
  };

  // Toggle project expansion
  const toggleProjectExpansion = (projectId) => {
    if (expandedProject === projectId) {
      setExpandedProject(null);
    } else {
      setExpandedProject(projectId);
    }
  };

  return (
    <div className="overflow-x-auto">
      {projects.length > 0 ? (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => requestSort('title')}
              >
                <div className="flex items-center">
                  Project Title
                  {getSortDirectionIndicator('title')}
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => requestSort('postedDate')}
              >
                <div className="flex items-center">
                  Posted Date
                  {getSortDirectionIndicator('postedDate')}
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => requestSort('applicationsCount')}
              >
                <div className="flex items-center">
                  Applications
                  {getSortDirectionIndicator('applicationsCount')}
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => requestSort('status')}
              >
                <div className="flex items-center">
                  Status
                  {getSortDirectionIndicator('status')}
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {getSortedProjects().map((project) => {
              const config = statusConfig[project.status] || statusConfig.Open;
              return (
                <React.Fragment key={project.id}>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{project.title}</div>
                          <div className="text-sm text-gray-500">{project.domain}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatDate(project.postedDate)}</div>
                      <div className="text-sm text-gray-500">
                        {isPastProjects ? 
                          `Duration: ${project.duration}` : 
                          `Deadline: ${formatDate(project.applicationDeadline)}`
                        }
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{project.applicationsCount} applicants</div>
                      {project.applicants && (
                        <button
                          onClick={() => toggleProjectExpansion(project.id)}
                          className="text-sm text-primary hover:text-primary-dark flex items-center"
                        >
                          View details
                          <Icon
                            name={expandedProject === project.id ? "ChevronUp" : "ChevronDown"}
                            size={16}
                            className="ml-1"
                          />
                        </button>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
                      >
                        <Icon name={config.icon} size={12} className="mr-1" />
                        {project.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button
                          type="button"
                          className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                          title="Edit project"
                        >
                          <Icon name="Edit" size={16} />
                        </button>
                        <Link
                          to={`/applicant-review-page?projectId=${project.id}`}
                          className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                          title="Review applicants"
                        >
                          <Icon name="Users" size={16} />
                        </Link>
                        {!isPastProjects && project.status === "Open" && (
                          <button
                            type="button"
                            className="inline-flex items-center p-1.5 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                            title="Close applications"
                          >
                            <Icon name="XCircle" size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                  {expandedProject === project.id && (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 bg-gray-50">
                        <div className="text-sm text-gray-900 mb-4">
                          <h4 className="font-medium">Project Description</h4>
                          <p className="mt-1 text-gray-700">{project.description}</p>
                          
                          <h4 className="font-medium mt-3">Requirements</h4>
                          <p className="mt-1 text-gray-700">{project.requirements}</p>
                          
                          {isPastProjects && project.outcome && (
                            <>
                              <h4 className="font-medium mt-3">Outcome</h4>
                              <p className="mt-1 text-gray-700">{project.outcome}</p>
                            </>
                          )}
                        </div>
                        
                        <ApplicantsList 
                          applicants={project.applicants} 
                          projectId={project.id} 
                        />
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      ) : (
        <div className="text-center py-12">
          <Icon
            name="ClipboardList"
            size={48}
            className="mx-auto text-gray-300"
          />
          <h3 className="mt-2 text-sm font-medium text-gray-900">
            No projects found
          </h3>
          <p className="mt-1 text-sm text-gray-500">
            {isPastProjects
              ? "You don't have any past projects."
              : "You haven't created any projects yet."}
          </p>
          {!isPastProjects && (
            <div className="mt-6">
              <Link
                to="/faculty-dashboard"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <Icon name="Plus" size={16} className="mr-2" />
                Create New Project
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProjectsTable;