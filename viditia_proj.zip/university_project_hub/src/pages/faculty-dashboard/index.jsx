import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import DashboardHeader from "./components/DashboardHeader";
import ProjectStats from "./components/ProjectStats";
import ProjectCard from "./components/ProjectCard";
import NotificationCenter from "./components/NotificationCenter";
import UpcomingMeetings from "./components/UpcomingMeetings";

const FacultyDashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("active");
  
  // Mock faculty data
  const facultyData = {
    name: "Dr. Sarah Williams",
    email: "sarah.williams@university.edu",
    department: "Computer Science",
    position: "Associate Professor",
    profileImage: "https://randomuser.me/api/portraits/women/68.jpg",
    profileCompletion: 90,
    researchInterests: ["Artificial Intelligence", "Machine Learning", "Natural Language Processing"],
    officeHours: "Monday & Wednesday, 2:00 PM - 4:00 PM",
    officeLocation: "Room 302, Computer Science Building",
  };

  // Mock projects data
  const projectsData = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy. Students will work with large datasets and implement various NLP techniques.",
      domain: "Artificial Intelligence",
      postedDate: "2023-09-15",
      deadline: "2023-10-30",
      status: "Active",
      applicantsCount: 8,
      maxStudents: 2,
      shortlistedCount: 3,
      selectedCount: 1,
      requirements: ["Strong Python skills", "Experience with NLP libraries", "Knowledge of machine learning algorithms"],
    },
    {
      id: 2,
      title: "Deep Learning for Medical Image Analysis",
      description: "Develop deep learning models for analyzing medical images to detect abnormalities. The project will involve working with CT scans and MRI data to build accurate diagnostic tools.",
      domain: "Computer Vision",
      postedDate: "2023-09-20",
      deadline: "2023-10-25",
      status: "Active",
      applicantsCount: 12,
      maxStudents: 3,
      shortlistedCount: 5,
      selectedCount: 0,
      requirements: ["Experience with TensorFlow or PyTorch", "Understanding of CNN architectures", "Image processing knowledge"],
    },
    {
      id: 3,
      title: "Blockchain-based Academic Credential Verification",
      description: "Design and implement a blockchain-based system for verifying academic credentials. The system should provide a secure and tamper-proof way to store and verify degrees and certificates.",
      domain: "Blockchain",
      postedDate: "2023-08-10",
      deadline: "2023-09-25",
      status: "Closed",
      applicantsCount: 6,
      maxStudents: 2,
      shortlistedCount: 4,
      selectedCount: 2,
      requirements: ["Knowledge of blockchain technology", "Smart contract development", "Web development skills"],
    },
    {
      id: 4,
      title: "Automated Essay Grading System",
      description: "Create an AI-powered system that can automatically grade student essays based on content, grammar, structure, and coherence. The system should provide detailed feedback to help students improve their writing.",
      domain: "Natural Language Processing",
      postedDate: "2023-09-05",
      deadline: "2023-10-15",
      status: "Active",
      applicantsCount: 5,
      maxStudents: 2,
      shortlistedCount: 2,
      selectedCount: 0,
      requirements: ["NLP experience", "Machine learning knowledge", "Good understanding of language structure"],
    },
    {
      id: 5,
      title: "Smart Campus IoT Network",
      description: "Design and prototype an IoT network for university campuses to monitor energy usage, classroom occupancy, and environmental conditions. The project will involve hardware and software components.",
      domain: "Internet of Things",
      postedDate: "2023-09-25",
      deadline: "2023-11-10",
      status: "Active",
      applicantsCount: 3,
      maxStudents: 4,
      shortlistedCount: 0,
      selectedCount: 0,
      requirements: ["IoT device programming", "Network protocols knowledge", "Data visualization skills"],
    },
    {
      id: 6,
      title: "Virtual Reality for Architecture Education",
      description: "Develop a VR application that allows architecture students to experience and interact with their 3D building designs in virtual reality. The application should support collaborative viewing and annotation.",
      domain: "Virtual Reality",
      postedDate: "2023-08-05",
      deadline: "2023-09-20",
      status: "Closed",
      applicantsCount: 10,
      maxStudents: 3,
      shortlistedCount: 5,
      selectedCount: 3,
      requirements: ["Unity or Unreal Engine experience", "3D modeling skills", "VR development knowledge"],
    },
  ];

  // Mock notifications
  const notifications = [
    {
      id: 1,
      type: "application",
      message: "New application received for AI-Based Sentiment Analysis project",
      project: "AI-Based Sentiment Analysis for Social Media",
      time: "2 hours ago",
      read: false,
    },
    {
      id: 2,
      type: "deadline",
      message: "Application deadline for Automated Essay Grading System is tomorrow",
      project: "Automated Essay Grading System",
      time: "5 hours ago",
      read: false,
    },
    {
      id: 3,
      type: "meeting",
      message: "Meeting scheduled with Alex Johnson for project discussion",
      project: "AI-Based Sentiment Analysis for Social Media",
      time: "1 day ago",
      read: true,
    },
    {
      id: 4,
      type: "system",
      message: "Your project \'Deep Learning for Medical Image Analysis\' is trending with high applications",
      project: "Deep Learning for Medical Image Analysis",
      time: "2 days ago",
      read: true,
    },
  ];

  // Mock upcoming meetings
  const upcomingMeetings = [
    {
      id: 1,
      student: "Alex Johnson",
      project: "AI-Based Sentiment Analysis for Social Media",
      date: "2023-10-25",
      time: "14:00 - 15:00",
      location: "Room 302, Computer Science Building",
      virtual: false,
      studentImage: "https://randomuser.me/api/portraits/men/32.jpg",
    },
    {
      id: 2,
      student: "Emily Chen",
      project: "Deep Learning for Medical Image Analysis",
      date: "2023-10-27",
      time: "10:30 - 11:30",
      location: "Zoom Meeting",
      virtual: true,
      meetingLink: "https://university.zoom.us/j/123456789",
      studentImage: "https://randomuser.me/api/portraits/women/44.jpg",
    },
  ];

  // Filter projects based on search query and active tab
  const filteredProjects = projectsData.filter(
    (project) =>
      (activeTab === "active" ? project.status === "Active" : project.status === "Closed") &&
      (project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
       project.domain.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Calculate statistics
  const stats = {
    totalProjects: projectsData.length,
    activeProjects: projectsData.filter(project => project.status === "Active").length,
    totalApplicants: projectsData.reduce((sum, project) => sum + project.applicantsCount, 0),
    selectedStudents: projectsData.reduce((sum, project) => sum + project.selectedCount, 0),
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={facultyData.profileImage}
                alt={facultyData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <Link to="/faculty-profile">
                  <Icon name="Edit" size={16} className="text-white" />
                </Link>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{facultyData.name}</h2>
            <p className="text-sm text-gray-500">{facultyData.department}</p>
            <p className="text-sm text-gray-500">{facultyData.position}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/faculty-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/faculty-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/applicant-review-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="Users" size={20} className="mr-3" />
                Review Applicants
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Office Hours
                </h3>
                <div className="mt-2 space-y-2">
                  <div className="flex items-center px-4 py-2 text-sm text-gray-700">
                    <Icon name="Clock" size={18} className="mr-3 text-gray-400" />
                    {facultyData.officeHours}
                  </div>
                  <div className="flex items-center px-4 py-2 text-sm text-gray-700">
                    <Icon name="MapPin" size={18} className="mr-3 text-gray-400" />
                    {facultyData.officeLocation}
                  </div>
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <DashboardHeader 
          facultyData={facultyData} 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          notifications={notifications}
        />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Welcome section */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Welcome, {facultyData.name}!
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Manage your projects and student applications from your dashboard.
              </p>
            </div>

            {/* Project statistics */}
            <div className="mt-4">
              <ProjectStats stats={stats} />
            </div>

            {/* Main dashboard content */}
            <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
              {/* Projects Section - Takes 2/3 of the screen on large displays */}
              <div className="lg:col-span-2">
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-medium text-gray-900">
                      Your Projects
                    </h2>
                    <Link
                      to="/faculty-dashboard"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Plus" size={16} className="mr-2" />
                      Post New Project
                    </Link>
                  </div>

                  {/* Tabs */}
                  <div className="border-b border-gray-200 mb-6">
                    <nav className="-mb-px flex space-x-8">
                      <button
                        onClick={() => setActiveTab("active")}
                        className={`${
                          activeTab === "active" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                        } whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm`}
                      >
                        Active Projects
                      </button>
                      <button
                        onClick={() => setActiveTab("closed")}
                        className={`${
                          activeTab === "closed" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                        } whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm`}
                      >
                        Closed Projects
                      </button>
                    </nav>
                  </div>

                  {filteredProjects.length > 0 ? (
                    <div className="space-y-4">
                      {filteredProjects.map((project) => (
                        <ProjectCard
                          key={project.id}
                          project={project}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Icon
                        name="Search"
                        size={48}
                        className="mx-auto text-gray-300"
                      />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">
                        No projects found
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {searchQuery
                          ? `No ${activeTab} projects matching "${searchQuery}"`
                          : `You don't have any ${activeTab} projects.`}
                      </p>
                      <div className="mt-6">
                        <Link
                          to="/faculty-dashboard"
                          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                        >
                          <Icon name="Plus" size={16} className="mr-2" />
                          Post New Project
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Notifications and Meetings Section - Takes 1/3 of the screen on large displays */}
              <div className="space-y-6">
                {/* Upcoming Meetings */}
                <UpcomingMeetings meetings={upcomingMeetings} />

                {/* Notification Center */}
                <NotificationCenter notifications={notifications} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default FacultyDashboard;