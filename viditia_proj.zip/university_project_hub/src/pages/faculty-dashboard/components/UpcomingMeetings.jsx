import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const UpcomingMeetings = ({ meetings }) => {
  // Format date
  const formatDate = (dateString) => {
    const options = { weekday: "short", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Upcoming Meetings
        </h3>
      </div>
      <div className="px-6 py-5">
        {meetings.length > 0 ? (
          <div className="space-y-5">
            {meetings.map((meeting) => (
              <div
                key={meeting.id}
                className="bg-gray-50 rounded-lg p-4 border border-gray-200"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3">
                    <Image
                      src={meeting.studentImage}
                      alt={meeting.student}
                      className="h-10 w-10 rounded-full"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">
                      Meeting with {meeting.student}
                    </h4>
                    <p className="mt-1 text-sm text-gray-500">
                      {meeting.project}
                    </p>
                  </div>
                  <div
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      meeting.virtual
                        ? "bg-primary-light text-primary" :"bg-gray-100 text-gray-800"
                    }`}
                  >
                    <Icon
                      name={meeting.virtual ? "Video" : "MapPin"}
                      size={12}
                      className="mr-1"
                    />
                    {meeting.virtual ? "Virtual" : "In-person"}
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Icon
                      name="Calendar"
                      size={16}
                      className="text-gray-400 mr-1.5"
                    />
                    <span className="text-sm text-gray-500">
                      {formatDate(meeting.date)}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Icon
                      name="Clock"
                      size={16}
                      className="text-gray-400 mr-1.5"
                    />
                    <span className="text-sm text-gray-500">{meeting.time}</span>
                  </div>
                </div>

                <div className="mt-4 flex items-center">
                  <Icon
                    name={meeting.virtual ? "Link" : "MapPin"}
                    size={16}
                    className="text-gray-400 mr-1.5 flex-shrink-0"
                  />
                  <span className="text-sm text-gray-500 truncate">
                    {meeting.location}
                  </span>
                </div>

                <div className="mt-4 flex justify-between">
                  {meeting.virtual && meeting.meetingLink && (
                    <a
                      href={meeting.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Video" size={14} className="mr-1.5" />
                      Join Meeting
                    </a>
                  )}
                  <div className="flex space-x-2">
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Calendar" size={14} className="mr-1.5" />
                      Add to Calendar
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Edit" size={14} className="mr-1.5" />
                      Reschedule
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <Icon
              name="Calendar"
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No upcoming meetings
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Your scheduled meetings will appear here.
            </p>
          </div>
        )}
      </div>
      {meetings.length > 0 && (
        <div className="border-t border-gray-200 px-6 py-3">
          <button
            type="button"
            className="text-sm font-medium text-primary hover:text-primary-dark w-full text-center"
          >
            View all meetings
          </button>
        </div>
      )}
    </div>
  );
};

export default UpcomingMeetings;