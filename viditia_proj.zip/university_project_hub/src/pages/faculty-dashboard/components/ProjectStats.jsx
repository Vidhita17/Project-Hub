import React from "react";
import Icon from "../../../components/AppIcon";

const ProjectStats = ({ stats }) => {
  // Stats for the dashboard
  const statItems = [
    {
      name: "Total Projects",
      value: stats.totalProjects,
      icon: "Layers",
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
    {
      name: "Active Projects",
      value: stats.activeProjects,
      icon: "Activity",
      color: "text-success",
      bgColor: "bg-success-light",
    },
    {
      name: "Total Applicants",
      value: stats.totalApplicants,
      icon: "Users",
      color: "text-warning",
      bgColor: "bg-warning-light",
    },
    {
      name: "Selected Students",
      value: stats.selectedStudents,
      icon: "CheckCircle",
      color: "text-success",
      bgColor: "bg-success-light",
    },
  ];

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6">
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Project Statistics
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Overview of your projects and applications.
            </p>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-200">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-gray-200">
          {statItems.map((stat, index) => (
            <div key={index} className="px-6 py-5">
              <div className="flex items-center">
                <div
                  className={`flex-shrink-0 rounded-md p-3 ${stat.bgColor}`}
                >
                  <Icon name={stat.icon} size={20} className={stat.color} />
                </div>
                <div className="ml-4">
                  <div className="text-2xl font-semibold text-gray-900">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-500">{stat.name}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectStats;