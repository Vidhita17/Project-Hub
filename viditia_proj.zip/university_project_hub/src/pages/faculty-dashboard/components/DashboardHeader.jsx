import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const DashboardHeader = ({ facultyData, searchQuery, setSearchQuery, notifications }) => {
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between h-16">
          {/* Mobile menu button */}
          <div className="flex md:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              <span className="sr-only">Open main menu</span>
              <Icon name={showMobileMenu ? "X" : "Menu"} size={24} />
            </button>
          </div>

          {/* Logo - visible only on mobile */}
          <div className="flex items-center md:hidden">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={28} className="text-primary" />
              <span className="ml-2 text-lg font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>

          {/* Search bar */}
          <div className="hidden md:flex md:flex-1 md:items-center">
            <div className="max-w-lg w-full">
              <label htmlFor="search" className="sr-only">
                Search projects
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Icon name="Search" size={20} className="text-gray-400" />
                </div>
                <input
                  id="search"
                  name="search"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary focus:border-primary sm:text-sm"
                  placeholder="Search projects by title or domain"
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Right side icons */}
          <div className="flex items-center">
            {/* Notifications dropdown */}
            <div className="relative ml-3">
              <button
                type="button"
                className="relative p-1 text-gray-500 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <span className="sr-only">View notifications</span>
                <Icon name="Bell" size={24} />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-error text-white text-xs font-medium flex items-center justify-center transform -translate-y-1/2 translate-x-1/2">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notifications dropdown panel */}
              {showNotifications && (
                <div className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
                  <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
                    <div className="px-4 py-2 border-b border-gray-200">
                      <h3 className="text-sm font-medium text-gray-900">Notifications</h3>
                    </div>
                    {notifications.length > 0 ? (
                      <div className="max-h-96 overflow-y-auto">
                        {notifications.map((notification) => (
                          <div
                            key={notification.id}
                            className={`px-4 py-3 hover:bg-gray-50 ${
                              !notification.read ? "bg-primary-light" : ""
                            }`}
                          >
                            <div className="flex justify-between">
                              <p className="text-sm font-medium text-gray-900">{notification.type === "application" ? "New Application" : notification.type === "deadline" ? "Deadline Reminder" : notification.type === "meeting" ? "Meeting Scheduled" : "System Notification"}</p>
                              <p className="text-xs text-gray-500">{notification.time}</p>
                            </div>
                            <p className="text-sm text-gray-500 mt-1">{notification.message}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="px-4 py-6 text-center">
                        <Icon name="Bell" size={24} className="mx-auto text-gray-300" />
                        <p className="mt-1 text-sm text-gray-500">No notifications yet</p>
                      </div>
                    )}
                    <div className="border-t border-gray-200 px-4 py-2">
                      <button
                        type="button"
                        className="text-sm text-primary hover:text-primary-dark w-full text-center"
                      >
                        View all notifications
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Profile dropdown */}
            <div className="hidden md:ml-4 md:flex md:items-center">
              <div className="ml-3 relative">
                <div>
                  <button
                    type="button"
                    className="flex items-center max-w-xs text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    id="user-menu-button"
                  >
                    <span className="sr-only">Open user menu</span>
                    <Image
                      src={facultyData.profileImage}
                      alt={facultyData.name}
                      className="h-8 w-8 rounded-full"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 hidden lg:block">
                      {facultyData.name}
                    </span>
                    <Icon name="ChevronDown" size={16} className="ml-1 text-gray-400 hidden lg:block" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu, show/hide based on menu state */}
      {showMobileMenu && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/faculty-dashboard"
              className="bg-primary text-white block pl-3 pr-4 py-2 text-base font-medium"
            >
              Dashboard
            </Link>
            <Link
              to="/faculty-profile"
              className="text-gray-700 hover:bg-gray-50 hover:text-gray-900 block pl-3 pr-4 py-2 text-base font-medium"
            >
              Profile
            </Link>
            <Link
              to="/applicant-review-page"
              className="text-gray-700 hover:bg-gray-50 hover:text-gray-900 block pl-3 pr-4 py-2 text-base font-medium"
            >
              Review Applicants
            </Link>
          </div>

          {/* Mobile search */}
          <div className="pt-2 pb-3 px-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Icon name="Search" size={20} className="text-gray-400" />
              </div>
              <input
                id="mobile-search"
                name="search"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary focus:border-primary sm:text-sm"
                placeholder="Search projects"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Office hours */}
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="px-4 space-y-1">
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                Office Hours
              </div>
              <div className="flex items-center text-gray-700 pl-3 pr-4 py-2 text-base">
                <Icon name="Clock" size={20} className="mr-3 text-gray-400" />
                {facultyData.officeHours}
              </div>
              <div className="flex items-center text-gray-700 pl-3 pr-4 py-2 text-base">
                <Icon name="MapPin" size={20} className="mr-3 text-gray-400" />
                {facultyData.officeLocation}
              </div>
            </div>
          </div>

          {/* Logout */}
          <div className="pt-2 pb-3 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center text-gray-700 hover:bg-gray-50 hover:text-gray-900 pl-3 pr-4 py-2 text-base font-medium"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default DashboardHeader;