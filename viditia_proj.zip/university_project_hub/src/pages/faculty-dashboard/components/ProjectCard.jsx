import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";

const ProjectCard = ({ project }) => {
  const [showDetails, setShowDetails] = useState(false);

  // Status badge configuration
  const statusConfig = {
    Active: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Closed: {
      bgColor: "bg-gray-100",
      textColor: "text-gray-700",
      icon: "Archive",
    },
    Draft: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "FileEdit",
    },
  };

  const config = statusConfig[project.status];

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Calculate days remaining until deadline
  const calculateDaysRemaining = (deadlineString) => {
    const deadline = new Date(deadlineString);
    const today = new Date();
    const diffTime = deadline - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = project.status === "Active" ? calculateDaysRemaining(project.deadline) : null;

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">
              {project.title}
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Domain: {project.domain}
            </p>
          </div>
          <div
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
          >
            <Icon name={config.icon} size={14} className="mr-1" />
            {project.status}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="flex items-center text-sm text-gray-500">
            <Icon name="Calendar" size={16} className="mr-1.5" />
            Posted: {formatDate(project.postedDate)}
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <Icon name="Clock" size={16} className="mr-1.5" />
            {project.status === "Active" ? (
              <>
                Deadline: {formatDate(project.deadline)}
                {daysRemaining <= 3 && (
                  <span className="ml-1 text-error">
                    ({daysRemaining} {daysRemaining === 1 ? "day" : "days"} left)
                  </span>
                )}
              </>
            ) : (
              <>Closed: {formatDate(project.deadline)}</>
            )}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center text-sm text-gray-500">
              <Icon name="Users" size={16} className="mr-1.5" />
              {project.applicantsCount} Applicants
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Icon name="CheckSquare" size={16} className="mr-1.5" />
              {project.selectedCount}/{project.maxStudents} Selected
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            className="inline-flex items-center text-sm font-medium text-primary hover:text-primary-dark"
          >
            {showDetails ? "Hide Details" : "View Details"}
            <Icon
              name={showDetails ? "ChevronUp" : "ChevronDown"}
              size={16}
              className="ml-1"
            />
          </button>
        </div>

        {showDetails && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="space-y-3">
              <div>
                <h4 className="text-sm font-medium text-gray-900">
                  Project Description
                </h4>
                <p className="mt-1 text-sm text-gray-500">
                  {project.description}
                </p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-900">Requirements</h4>
                <ul className="mt-1 text-sm text-gray-500 list-disc pl-5 space-y-1">
                  {project.requirements.map((req, index) => (
                    <li key={index}>{req}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-900">Application Status</h4>
                <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                  <div className="bg-primary-light bg-opacity-50 rounded-md p-2">
                    <div className="text-lg font-semibold text-primary">{project.applicantsCount}</div>
                    <div className="text-xs text-gray-500">Total</div>
                  </div>
                  <div className="bg-warning-light bg-opacity-50 rounded-md p-2">
                    <div className="text-lg font-semibold text-warning">{project.shortlistedCount}</div>
                    <div className="text-xs text-gray-500">Shortlisted</div>
                  </div>
                  <div className="bg-success-light bg-opacity-50 rounded-md p-2">
                    <div className="text-lg font-semibold text-success">{project.selectedCount}</div>
                    <div className="text-xs text-gray-500">Selected</div>
                  </div>
                </div>
              </div>
              <div className="flex justify-between pt-3">
                <Link
                  to={`/applicant-review-page?project=${project.id}`}
                  className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Users" size={16} className="mr-1.5" />
                  View Applicants
                </Link>
                <div className="space-x-2">
                  <button
                    type="button"
                    className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    <Icon name="Edit" size={16} className="mr-1.5" />
                    Edit
                  </button>
                  {project.status === "Active" && (
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      <Icon name="Archive" size={16} className="mr-1.5" />
                      Close
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectCard;