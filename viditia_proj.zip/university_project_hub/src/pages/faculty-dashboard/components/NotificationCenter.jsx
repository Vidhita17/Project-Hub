import React from "react";
import Icon from "../../../components/AppIcon";

const NotificationCenter = ({ notifications }) => {
  // Notification icon and color configuration
  const notificationConfig = {
    application: {
      icon: "UserPlus",
      bgColor: "bg-primary-light",
      iconColor: "text-primary",
    },
    deadline: {
      icon: "Clock",
      bgColor: "bg-warning-light",
      iconColor: "text-warning",
    },
    meeting: {
      icon: "Calendar",
      bgColor: "bg-success-light",
      iconColor: "text-success",
    },
    system: {
      icon: "Bell",
      bgColor: "bg-gray-100",
      iconColor: "text-gray-700",
    },
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Notifications
        </h3>
      </div>
      <div className="px-6 py-5">
        {notifications.length > 0 ? (
          <div className="flow-root">
            <ul className="-mb-8">
              {notifications.map((notification, notificationIdx) => {
                const config = notificationConfig[notification.type];
                return (
                  <li key={notification.id}>
                    <div className="relative pb-8">
                      {notificationIdx !== notifications.length - 1 ? (
                        <span
                          className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200"
                          aria-hidden="true"
                        ></span>
                      ) : null}
                      <div className="relative flex items-start space-x-3">
                        <div>
                          <div
                            className={`relative px-1 ${config.bgColor} rounded-full flex items-center justify-center h-10 w-10`}
                          >
                            <Icon
                              name={config.icon}
                              size={20}
                              className={config.iconColor}
                            />
                          </div>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div>
                            <div className="text-sm">
                              <span className="font-medium text-gray-900">
                                {notification.project}
                              </span>
                            </div>
                            <p className="mt-0.5 text-sm text-gray-500">
                              {notification.time}
                            </p>
                          </div>
                          <div className="mt-2 text-sm text-gray-700">
                            <p>{notification.message}</p>
                          </div>
                          {!notification.read && (
                            <div className="mt-2">
                              <button
                                type="button"
                                className="text-xs text-primary hover:text-primary-dark font-medium"
                              >
                                Mark as read
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          <div className="text-center py-6">
            <Icon
              name="Bell"
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No notifications
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              You're all caught up! New notifications will appear here.
            </p>
          </div>
        )}
      </div>
      {notifications.length > 0 && (
        <div className="border-t border-gray-200 px-6 py-3">
          <button
            type="button"
            className="text-sm font-medium text-primary hover:text-primary-dark w-full text-center"
          >
            View all notifications
          </button>
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;