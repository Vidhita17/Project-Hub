import React from "react";
import Icon from "../../../components/AppIcon";

const ProfessionalLinksSection = ({
  links,
  isEditing,
  onEdit,
  onChange,
  onSubmit,
  onCancel,
}) => {
  // Function to validate URL format
  const isValidUrl = (url) => {
    if (!url) return true; // Empty is valid (optional field)
    try {
      new URL(url);
      return true;
    } catch (e) {
      return false;
    }
  };

  // Function to get domain name from URL
  const getDomainName = (url) => {
    if (!url) return "";
    try {
      const domain = new URL(url).hostname;
      return domain.replace("www.", "");
    } catch (e) {
      return url;
    }
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium leading-6 text-gray-900">
            Professional Links
          </h3>
          {!isEditing && (
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Edit" size={16} className="mr-2" />
              Edit
            </button>
          )}
        </div>
      </div>

      <div className="px-6 py-5">
        {isEditing ? (
          <form onSubmit={onSubmit}>
            <div className="space-y-4">
              <div>
                <label
                  htmlFor="github"
                  className="flex items-center text-sm font-medium text-gray-700"
                >
                  <Icon name="Github" size={20} className="mr-2" />
                  GitHub Profile
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="github"
                    id="github"
                    value={links.github}
                    onChange={onChange}
                    placeholder="https://github.com/username"
                    className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                      links.github && !isValidUrl(links.github)
                        ? "border-error" :""
                    }`}
                  />
                  {links.github && !isValidUrl(links.github) && (
                    <p className="mt-1 text-xs text-error">
                      Please enter a valid URL
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label
                  htmlFor="linkedin"
                  className="flex items-center text-sm font-medium text-gray-700"
                >
                  <Icon name="Linkedin" size={20} className="mr-2" />
                  LinkedIn Profile
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="linkedin"
                    id="linkedin"
                    value={links.linkedin}
                    onChange={onChange}
                    placeholder="https://linkedin.com/in/username"
                    className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                      links.linkedin && !isValidUrl(links.linkedin)
                        ? "border-error" :""
                    }`}
                  />
                  {links.linkedin && !isValidUrl(links.linkedin) && (
                    <p className="mt-1 text-xs text-error">
                      Please enter a valid URL
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label
                  htmlFor="portfolio"
                  className="flex items-center text-sm font-medium text-gray-700"
                >
                  <Icon name="Globe" size={20} className="mr-2" />
                  Portfolio Website
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="portfolio"
                    id="portfolio"
                    value={links.portfolio}
                    onChange={onChange}
                    placeholder="https://yourportfolio.com"
                    className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                      links.portfolio && !isValidUrl(links.portfolio)
                        ? "border-error" :""
                    }`}
                  />
                  {links.portfolio && !isValidUrl(links.portfolio) && (
                    <p className="mt-1 text-xs text-error">
                      Please enter a valid URL
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={onCancel}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                disabled={
                  (links.github && !isValidUrl(links.github)) ||
                  (links.linkedin && !isValidUrl(links.linkedin)) ||
                  (links.portfolio && !isValidUrl(links.portfolio))
                }
              >
                Save
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon
                  name="Github"
                  size={24}
                  className="text-gray-500"
                />
              </div>
              <div className="ml-4 flex-1">
                <h4 className="text-sm font-medium text-gray-900">
                  GitHub Profile
                </h4>
                {links.github ? (
                  <a
                    href={links.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 text-sm text-primary hover:text-primary-dark"
                  >
                    {getDomainName(links.github)}
                  </a>
                ) : (
                  <p className="mt-1 text-sm text-gray-500">Not provided</p>
                )}
              </div>
            </div>

            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon
                  name="Linkedin"
                  size={24}
                  className="text-gray-500"
                />
              </div>
              <div className="ml-4 flex-1">
                <h4 className="text-sm font-medium text-gray-900">
                  LinkedIn Profile
                </h4>
                {links.linkedin ? (
                  <a
                    href={links.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 text-sm text-primary hover:text-primary-dark"
                  >
                    {getDomainName(links.linkedin)}
                  </a>
                ) : (
                  <p className="mt-1 text-sm text-gray-500">Not provided</p>
                )}
              </div>
            </div>

            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon
                  name="Globe"
                  size={24}
                  className="text-gray-500"
                />
              </div>
              <div className="ml-4 flex-1">
                <h4 className="text-sm font-medium text-gray-900">
                  Portfolio Website
                </h4>
                {links.portfolio ? (
                  <a
                    href={links.portfolio}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 text-sm text-primary hover:text-primary-dark"
                  >
                    {getDomainName(links.portfolio)}
                  </a>
                ) : (
                  <p className="mt-1 text-sm text-gray-500">Not provided</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfessionalLinksSection;