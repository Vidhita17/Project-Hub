import React from "react";
import Icon from "../../../components/AppIcon";

const PersonalInfoSection = ({ 
  personalInfo, 
  isEditing, 
  onEdit, 
  onChange, 
  onSubmit, 
  onCancel 
}) => {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium leading-6 text-gray-900">
            Personal Information
          </h3>
          {!isEditing && (
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="Edit" size={16} className="mr-2" />
              Edit
            </button>
          )}
        </div>
      </div>

      <div className="px-6 py-5">
        {isEditing ? (
          <form onSubmit={onSubmit}>
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
              <div className="sm:col-span-3">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={personalInfo.name}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                    required
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email Address
                </label>
                <div className="mt-1">
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={personalInfo.email}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                    required
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="studentId" className="block text-sm font-medium text-gray-700">
                  Student ID
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="studentId"
                    id="studentId"
                    value={personalInfo.studentId}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md bg-gray-50"
                    disabled
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">Student ID cannot be changed</p>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                  Phone Number
                </label>
                <div className="mt-1">
                  <input
                    type="tel"
                    name="phone"
                    id="phone"
                    value={personalInfo.phone}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="department" className="block text-sm font-medium text-gray-700">
                  Department
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="department"
                    id="department"
                    value={personalInfo.department}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md bg-gray-50"
                    disabled
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">Contact administration to change department</p>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="dateOfBirth" className="block text-sm font-medium text-gray-700">
                  Date of Birth
                </label>
                <div className="mt-1">
                  <input
                    type="date"
                    name="dateOfBirth"
                    id="dateOfBirth"
                    value={personalInfo.dateOfBirth}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="semester" className="block text-sm font-medium text-gray-700">
                  Semester
                </label>
                <div className="mt-1">
                  <select
                    id="semester"
                    name="semester"
                    value={personalInfo.semester}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  >
                    <option>1st Semester</option>
                    <option>2nd Semester</option>
                    <option>3rd Semester</option>
                    <option>4th Semester</option>
                    <option>5th Semester</option>
                    <option>6th Semester</option>
                    <option>7th Semester</option>
                    <option>8th Semester</option>
                  </select>
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="year" className="block text-sm font-medium text-gray-700">
                  Year
                </label>
                <div className="mt-1">
                  <select
                    id="year"
                    name="year"
                    value={personalInfo.year}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  >
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                  </select>
                </div>
              </div>

              <div className="sm:col-span-6">
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                  Address
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="address"
                    id="address"
                    value={personalInfo.address}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <label htmlFor="bio" className="block text-sm font-medium text-gray-700">
                  Bio
                </label>
                <div className="mt-1">
                  <textarea
                    id="bio"
                    name="bio"
                    rows={4}
                    value={personalInfo.bio}
                    onChange={onChange}
                    className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Brief description for your profile. This will be visible to faculty members.
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={onCancel}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Save
              </button>
            </div>
          </form>
        ) : (
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Full Name</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.name}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Email Address</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.email}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Student ID</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.studentId}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Phone Number</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.phone || "Not provided"}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Department</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.department}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Date of Birth</h4>
              <p className="mt-1 text-sm text-gray-900">
                {personalInfo.dateOfBirth
                  ? new Date(personalInfo.dateOfBirth).toLocaleDateString()
                  : "Not provided"}
              </p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Semester</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.semester}</p>
            </div>

            <div className="sm:col-span-3">
              <h4 className="text-sm font-medium text-gray-500">Year</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.year}</p>
            </div>

            <div className="sm:col-span-6">
              <h4 className="text-sm font-medium text-gray-500">Address</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.address || "Not provided"}</p>
            </div>

            <div className="sm:col-span-6">
              <h4 className="text-sm font-medium text-gray-500">Bio</h4>
              <p className="mt-1 text-sm text-gray-900">{personalInfo.bio || "No bio provided"}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalInfoSection;