import React, { useRef, useState } from "react";
import Icon from "../../../components/AppIcon";

const ResumeSection = ({ resumeUploaded, resumeUrl, resumeUploadDate, onUpload }) => {
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "application/pdf") {
        setSelectedFile(file);
        onUpload(file);
      } else {
        alert("Please upload a PDF file only.");
      }
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.type === "application/pdf") {
        setSelectedFile(file);
        onUpload(file);
      } else {
        alert("Please upload a PDF file only.");
      }
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Resume</h3>
      </div>

      <div className="px-6 py-5">
        {resumeUploaded ? (
          <div className="flex flex-col sm:flex-row sm:items-start">
            <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-4">
              <div className="w-full sm:w-32 h-40 border border-gray-200 rounded-md overflow-hidden bg-gray-50 flex items-center justify-center">
                <Icon name="FileText" size={48} className="text-gray-400" />
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">resume.pdf</h4>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-light text-success">
                  <Icon name="Check" size={12} className="mr-1" />
                  Uploaded
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                Uploaded on {formatDate(resumeUploadDate)}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <a
                  href={resumeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Eye" size={16} className="mr-2" />
                  View
                </a>
                <button
                  type="button"
                  onClick={handleButtonClick}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="RefreshCw" size={16} className="mr-2" />
                  Update
                </button>
              </div>
              <p className="mt-4 text-sm text-gray-500">
                Your resume is visible to faculty members when you apply for projects.
                Make sure it's up to date with your latest skills and experiences.
              </p>
            </div>
          </div>
        ) : (
          <div
            className={`border-2 border-dashed rounded-lg p-6 ${
              dragActive ? "border-primary bg-primary-light bg-opacity-10" : "border-gray-300"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="text-center">
              <Icon
                name="Upload"
                size={36}
                className="mx-auto text-gray-400"
              />
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900">
                  Upload your resume
                </h4>
                <p className="mt-1 text-sm text-gray-500">
                  Drag and drop your resume PDF file here, or click to browse
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  PDF only, max 5MB
                </p>
              </div>
              <div className="mt-4">
                <button
                  type="button"
                  onClick={handleButtonClick}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Upload" size={16} className="mr-2" />
                  Upload Resume
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResumeSection;