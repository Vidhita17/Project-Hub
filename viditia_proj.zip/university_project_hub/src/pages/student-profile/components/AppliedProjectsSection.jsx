import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const AppliedProjectsSection = ({ projects }) => {
  const [expandedProject, setExpandedProject] = useState(null);

  // Format date
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Status badge configuration
  const statusConfig = {
    Applied: {
      bgColor: "bg-primary-light",
      textColor: "text-primary",
      icon: "Clock",
    },
    Shortlisted: {
      bgColor: "bg-warning-light",
      textColor: "text-warning",
      icon: "ListChecks",
    },
    Selected: {
      bgColor: "bg-success-light",
      textColor: "text-success",
      icon: "CheckCircle",
    },
    Rejected: {
      bgColor: "bg-error-light",
      textColor: "text-error",
      icon: "XCircle",
    },
  };

  const toggleProjectDetails = (projectId) => {
    if (expandedProject === projectId) {
      setExpandedProject(null);
    } else {
      setExpandedProject(projectId);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Applied Projects
        </h3>
      </div>

      <div className="px-6 py-5">
        {projects.length > 0 ? (
          <div className="overflow-hidden">
            <div className="hidden md:block">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Project
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Faculty
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Applied On
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Status
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {projects.map((project) => {
                    const config = statusConfig[project.status];
                    return (
                      <tr key={project.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {project.title}
                          </div>
                          <div className="text-sm text-gray-500">
                            {project.domain}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {project.faculty}
                          </div>
                          <div className="text-sm text-gray-500">
                            {project.department}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(project.appliedDate)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
                          >
                            <Icon
                              name={config.icon}
                              size={12}
                              className="mr-1"
                            />
                            {project.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => toggleProjectDetails(project.id)}
                            className="text-primary hover:text-primary-dark"
                          >
                            {expandedProject === project.id
                              ? "Hide Details" :"View Details"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile view */}
            <div className="md:hidden space-y-4">
              {projects.map((project) => {
                const config = statusConfig[project.status];
                return (
                  <div
                    key={project.id}
                    className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden"
                  >
                    <div className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-sm font-medium text-gray-900">
                            {project.title}
                          </h3>
                          <p className="mt-1 text-xs text-gray-500">
                            {project.faculty} • {project.department}
                          </p>
                        </div>
                        <div
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}
                        >
                          <Icon
                            name={config.icon}
                            size={12}
                            className="mr-1"
                          />
                          {project.status}
                        </div>
                      </div>

                      <div className="mt-3 text-xs text-gray-500">
                        <div className="flex items-center">
                          <Icon
                            name="Calendar"
                            size={12}
                            className="mr-1.5"
                          />
                          Applied on {formatDate(project.appliedDate)}
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => toggleProjectDetails(project.id)}
                          className="inline-flex items-center text-xs font-medium text-primary hover:text-primary-dark"
                        >
                          {expandedProject === project.id
                            ? "Hide Details" :"View Details"}
                          <Icon
                            name={
                              expandedProject === project.id
                                ? "ChevronUp" :"ChevronDown"
                            }
                            size={14}
                            className="ml-1"
                          />
                        </button>
                      </div>

                      {expandedProject === project.id && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs text-gray-700">
                            <p className="font-medium">Description:</p>
                            <p className="mt-1">{project.description}</p>
                            <p className="mt-2 font-medium">Domain:</p>
                            <p className="mt-1">{project.domain}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <Icon
              name="ClipboardList"
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No projects applied
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              You haven't applied to any projects yet.
            </p>
            <div className="mt-6">
              <a
                href="/project-search-page"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Browse Projects
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AppliedProjectsSection;