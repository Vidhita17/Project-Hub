import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";
import Image from "../../components/AppImage";
import ProfileHeader from "./components/ProfileHeader";
import PersonalInfoSection from "./components/PersonalInfoSection";
import ResumeSection from "./components/ResumeSection";
import ProfessionalLinksSection from "./components/ProfessionalLinksSection";
import AppliedProjectsSection from "./components/AppliedProjectsSection";
import PasswordSection from "./components/PasswordSection";

const StudentProfile = () => {
  // Mock user data
  const userData = {
    name: "Alex Johnson",
    email: "alex.johnson@university.edu",
    studentId: "ST2023456",
    department: "Computer Science",
    semester: "7th Semester",
    year: "4th Year",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    phone: "+1 (555) 123-4567",
    dateOfBirth: "1999-05-15",
    address: "123 Campus Avenue, University Town, UT 12345",
    bio: "Final year Computer Science student with a passion for AI and machine learning. Looking for challenging projects to apply my skills and knowledge.",
    resumeUploaded: true,
    resumeUrl: "/resume.pdf",
    resumeUploadDate: "2023-09-10",
    githubLink: "https://github.com/alexjohnson",
    linkedinLink: "https://linkedin.com/in/alexjohnson",
    portfolioLink: "https://alexjohnson.dev",
  };

  // Mock applied projects data
  const appliedProjects = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      faculty: "Dr. Sarah Williams",
      department: "Computer Science",
      appliedDate: "2023-10-15",
      status: "Shortlisted",
      description: "This project aims to develop a machine learning model that can analyze sentiment in social media posts with high accuracy.",
      domain: "Artificial Intelligence",
    },
    {
      id: 2,
      title: "Blockchain for Supply Chain Management",
      faculty: "Prof. Michael Chen",
      department: "Information Systems",
      appliedDate: "2023-10-10",
      status: "Applied",
      description: "Implementation of blockchain technology to improve transparency and efficiency in supply chain management systems.",
      domain: "Blockchain",
    },
    {
      id: 3,
      title: "Smart City IoT Network Architecture",
      faculty: "Dr. Emily Rodriguez",
      department: "Electrical Engineering",
      appliedDate: "2023-09-28",
      status: "Selected",
      description: "Designing an efficient IoT network architecture for smart city applications with focus on scalability and security.",
      domain: "Internet of Things",
    },
    {
      id: 4,
      title: "Quantum Computing Algorithms for Optimization Problems",
      faculty: "Prof. James Wilson",
      department: "Physics",
      appliedDate: "2023-09-20",
      status: "Rejected",
      description: "Research on quantum algorithms that can solve complex optimization problems more efficiently than classical algorithms.",
      domain: "Quantum Computing",
    },
  ];

  const [personalInfo, setPersonalInfo] = useState({
    name: userData.name,
    email: userData.email,
    studentId: userData.studentId,
    department: userData.department,
    semester: userData.semester,
    year: userData.year,
    phone: userData.phone,
    dateOfBirth: userData.dateOfBirth,
    address: userData.address,
    bio: userData.bio,
  });

  const [professionalLinks, setProfessionalLinks] = useState({
    github: userData.githubLink || "",
    linkedin: userData.linkedinLink || "",
    portfolio: userData.portfolioLink || "",
  });

  const [isEditingPersonalInfo, setIsEditingPersonalInfo] = useState(false);
  const [isEditingLinks, setIsEditingLinks] = useState(false);

  const handlePersonalInfoChange = (e) => {
    const { name, value } = e.target;
    setPersonalInfo((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleLinksChange = (e) => {
    const { name, value } = e.target;
    setProfessionalLinks((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePersonalInfoSubmit = (e) => {
    e.preventDefault();
    // In a real app, this would send the data to an API
    console.log("Updated personal info:", personalInfo);
    setIsEditingPersonalInfo(false);
  };

  const handleLinksSubmit = (e) => {
    e.preventDefault();
    // In a real app, this would send the data to an API
    console.log("Updated professional links:", professionalLinks);
    setIsEditingLinks(false);
  };

  const handleResumeUpload = (file) => {
    // In a real app, this would upload the file to a server
    console.log("Resume uploaded:", file.name);
  };

  const handlePasswordChange = (currentPassword, newPassword) => {
    // In a real app, this would send the password change request to an API
    console.log("Password change requested");
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/landing-page" className="flex items-center">
              <Icon name="Graduation" size={32} className="text-primary" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Project Hub
              </span>
            </Link>
          </div>
          <div className="mt-8 flex flex-col items-center">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src={userData.profileImage}
                alt={userData.name}
                className="rounded-full object-cover w-full h-full border-2 border-primary"
              />
              <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
                <button>
                  <Icon name="Edit" size={16} className="text-white" />
                </button>
              </div>
            </div>
            <h2 className="text-lg font-semibold text-gray-900">{userData.name}</h2>
            <p className="text-sm text-gray-500">{userData.department}</p>
            <p className="text-sm text-gray-500">{userData.semester}</p>
          </div>
          <div className="mt-8 flex-grow">
            <nav className="px-2 space-y-1">
              <Link
                to="/student-dashboard"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="LayoutDashboard" size={20} className="mr-3" />
                Dashboard
              </Link>
              <Link
                to="/student-profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
              >
                <Icon name="User" size={20} className="mr-3" />
                Profile
              </Link>
              <Link
                to="/project-search-page"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
              >
                <Icon name="Search" size={20} className="mr-3" />
                Browse Projects
              </Link>
              <div className="px-4 py-3">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  External Profiles
                </h3>
                <div className="mt-2 space-y-2">
                  {userData.githubLink && (
                    <a
                      href={userData.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Github" size={18} className="mr-3" />
                      GitHub
                    </a>
                  )}
                  {userData.linkedinLink && (
                    <a
                      href={userData.linkedinLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                    >
                      <Icon name="Linkedin" size={18} className="mr-3" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </nav>
          </div>
          <div className="flex-shrink-0 p-4 border-t border-gray-200">
            <Link
              to="/authentication-page"
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LogOut" size={20} className="mr-3" />
              Log out
            </Link>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <ProfileHeader userData={userData} />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Page header */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Student Profile
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Manage your personal information and professional details.
              </p>
            </div>

            {/* Profile sections */}
            <div className="mt-6 space-y-8">
              {/* Personal Information Section */}
              <PersonalInfoSection 
                personalInfo={personalInfo}
                isEditing={isEditingPersonalInfo}
                onEdit={() => setIsEditingPersonalInfo(true)}
                onChange={handlePersonalInfoChange}
                onSubmit={handlePersonalInfoSubmit}
                onCancel={() => setIsEditingPersonalInfo(false)}
              />

              {/* Resume Section */}
              <ResumeSection 
                resumeUploaded={userData.resumeUploaded}
                resumeUrl={userData.resumeUrl}
                resumeUploadDate={userData.resumeUploadDate}
                onUpload={handleResumeUpload}
              />

              {/* Professional Links Section */}
              <ProfessionalLinksSection 
                links={professionalLinks}
                isEditing={isEditingLinks}
                onEdit={() => setIsEditingLinks(true)}
                onChange={handleLinksChange}
                onSubmit={handleLinksSubmit}
                onCancel={() => setIsEditingLinks(false)}
              />

              {/* Applied Projects Section */}
              <AppliedProjectsSection projects={appliedProjects} />

              {/* Password Section */}
              <PasswordSection onPasswordChange={handlePasswordChange} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default StudentProfile;