import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../../components/AppIcon";

import SchedulerHeader from "./components/SchedulerHeader";
import SchedulerSidebar from "./components/SchedulerSidebar";
import CalendarView from "./components/CalendarView";
import MeetingDetails from "./components/MeetingDetails";
import UpcomingMeetings from "./components/UpcomingMeetings";
import MeetingHistory from "./components/MeetingHistory";

const MeetingScheduler = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedFaculty, setSelectedFaculty] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const [meetingAgenda, setMeetingAgenda] = useState("");
  const [currentStep, setCurrentStep] = useState(1);
  const [viewMode, setViewMode] = useState("calendar"); // calendar, upcoming, history

  // Mock user data
  const userData = {
    name: "Alex Johnson",
    email: "alex.johnson@university.edu",
    department: "Computer Science",
    semester: "7th Semester",
    profileImage: "https://randomuser.me/api/portraits/men/32.jpg",
    profileCompletion: 75,
    resumeUploaded: true,
    githubLink: "https://github.com/alexjohnson",
    linkedinLink: "https://linkedin.com/in/alexjohnson",
    role: "student", // student or faculty
  };

  // Mock faculty data
  const facultyList = [
    {
      id: 1,
      name: "Dr. Sarah Williams",
      department: "Computer Science",
      image: "https://randomuser.me/api/portraits/women/68.jpg",
      expertise: ["Artificial Intelligence", "Machine Learning", "Data Science"],
      projects: [1, 3],
    },
    {
      id: 2,
      name: "Prof. Michael Chen",
      department: "Information Systems",
      image: "https://randomuser.me/api/portraits/men/75.jpg",
      expertise: ["Blockchain", "Cybersecurity", "Cloud Computing"],
      projects: [2],
    },
    {
      id: 3,
      name: "Dr. Emily Rodriguez",
      department: "Electrical Engineering",
      image: "https://randomuser.me/api/portraits/women/45.jpg",
      expertise: ["Internet of Things", "Embedded Systems", "Wireless Networks"],
      projects: [3],
    },
  ];

  // Mock projects data
  const projects = [
    {
      id: 1,
      title: "AI-Based Sentiment Analysis for Social Media",
      faculty: "Dr. Sarah Williams",
      facultyId: 1,
      department: "Computer Science",
      status: "Shortlisted",
    },
    {
      id: 2,
      title: "Blockchain for Supply Chain Management",
      faculty: "Prof. Michael Chen",
      facultyId: 2,
      department: "Information Systems",
      status: "Applied",
    },
    {
      id: 3,
      title: "Smart City IoT Network Architecture",
      faculty: "Dr. Emily Rodriguez",
      facultyId: 3,
      department: "Electrical Engineering",
      status: "Selected",
    },
  ];

  // Mock upcoming meetings
  const upcomingMeetings = [
    {
      id: 1,
      faculty: "Dr. Sarah Williams",
      facultyId: 1,
      project: "AI-Based Sentiment Analysis for Social Media",
      projectId: 1,
      date: "2023-10-25",
      time: "14:00 - 15:00",
      location: "Room 302, Computer Science Building",
      virtual: false,
      status: "confirmed",
      agenda: "Discuss initial project requirements and timeline",
    },
    {
      id: 2,
      faculty: "Prof. Michael Chen",
      facultyId: 2,
      project: "Blockchain for Supply Chain Management",
      projectId: 2,
      date: "2023-10-27",
      time: "10:30 - 11:30",
      location: "Zoom Meeting",
      virtual: true,
      meetingLink: "https://university.zoom.us/j/123456789",
      status: "pending",
      agenda: "Review blockchain implementation options",
    },
  ];

  // Mock meeting history
  const meetingHistory = [
    {
      id: 101,
      faculty: "Dr. Sarah Williams",
      facultyId: 1,
      project: "AI-Based Sentiment Analysis for Social Media",
      projectId: 1,
      date: "2023-10-10",
      time: "13:00 - 14:00",
      location: "Room 302, Computer Science Building",
      virtual: false,
      status: "completed",
      notes: "Discussed project scope and initial requirements. Faculty suggested focusing on Twitter data analysis first.",
    },
    {
      id: 102,
      faculty: "Prof. Michael Chen",
      facultyId: 2,
      project: "Blockchain for Supply Chain Management",
      projectId: 2,
      date: "2023-10-05",
      time: "11:00 - 12:00",
      location: "Zoom Meeting",
      virtual: true,
      status: "cancelled",
      cancellationReason: "Faculty had an emergency meeting",
    },
  ];

  // Mock availability slots
  const generateAvailabilitySlots = (facultyId, date) => {
    // This would come from an API in a real application
    const slots = [];
    const startHour = 9; // 9 AM
    const endHour = 17; // 5 PM
    
    for (let hour = startHour; hour < endHour; hour++) {
      // Morning slots
      if (hour < 12) {
        slots.push({
          id: `${facultyId}-${date.toISOString().split('T')[0]}-${hour}-00`,
          time: `${hour}:00 - ${hour}:30`,
          status: Math.random() > 0.7 ? "booked" : "available",
          studentName: Math.random() > 0.7 ? "John Doe" : null,
        });
        
        slots.push({
          id: `${facultyId}-${date.toISOString().split('T')[0]}-${hour}-30`,
          time: `${hour}:30 - ${hour + 1}:00`,
          status: Math.random() > 0.7 ? "booked" : "available",
          studentName: Math.random() > 0.7 ? "Jane Smith" : null,
        });
      } 
      // Afternoon slots (after lunch break)
      else if (hour >= 13) {
        slots.push({
          id: `${facultyId}-${date.toISOString().split('T')[0]}-${hour}-00`,
          time: `${hour}:00 - ${hour}:30`,
          status: Math.random() > 0.7 ? "booked" : "available",
          studentName: Math.random() > 0.7 ? "Alex Johnson" : null,
        });
        
        slots.push({
          id: `${facultyId}-${date.toISOString().split('T')[0]}-${hour}-30`,
          time: `${hour}:30 - ${hour + 1}:00`,
          status: Math.random() > 0.7 ? "booked" : "available",
          studentName: Math.random() > 0.7 ? "Emily Wilson" : null,
        });
      }
    }
    
    return slots;
  };

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
    const faculty = facultyList.find(f => f.id === project.facultyId);
    setSelectedFaculty(faculty);
    setCurrentStep(2);
  };

  const handleTimeSlotSelect = (slot) => {
    setSelectedTimeSlot(slot);
    setCurrentStep(3);
  };

  const handleScheduleMeeting = () => {
    // This would connect to an API in a real application
    console.log("Scheduling meeting with:", {
      faculty: selectedFaculty,
      project: selectedProject,
      timeSlot: selectedTimeSlot,
      agenda: meetingAgenda,
    });
    
    // Reset form and show success message
    alert("Meeting request sent successfully!");
    setCurrentStep(1);
    setSelectedProject(null);
    setSelectedFaculty(null);
    setSelectedTimeSlot(null);
    setMeetingAgenda("");
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <SchedulerSidebar userData={userData} />

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <SchedulerHeader 
          userData={userData} 
          viewMode={viewMode}
          setViewMode={setViewMode}
        />

        <main className="flex-1 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {/* Page header */}
            <div className="py-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Meeting Scheduler
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Schedule meetings with faculty members for your projects.
              </p>
            </div>

            {/* View mode tabs */}
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => setViewMode("calendar")}
                  className={`${
                    viewMode === "calendar" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                >
                  <Icon name="Calendar" size={20} className="inline-block mr-2" />
                  Schedule New Meeting
                </button>
                <button
                  onClick={() => setViewMode("upcoming")}
                  className={`${
                    viewMode === "upcoming" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                >
                  <Icon name="Clock" size={20} className="inline-block mr-2" />
                  Upcoming Meetings
                </button>
                <button
                  onClick={() => setViewMode("history")}
                  className={`${
                    viewMode === "history" ?"border-primary text-primary" :"border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                >
                  <Icon name="History" size={20} className="inline-block mr-2" />
                  Meeting History
                </button>
              </nav>
            </div>

            {/* Main content based on view mode */}
            <div className="mt-6">
              {viewMode === "calendar" && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Step 1: Select Project */}
                  <div className={`lg:col-span-1 ${currentStep !== 1 ? 'hidden lg:block' : ''}`}>
                    <div className="bg-white shadow rounded-lg p-6">
                      <h2 className="text-lg font-medium text-gray-900 mb-4">
                        Step 1: Select Project
                      </h2>
                      <div className="space-y-4">
                        {projects.length > 0 ? (
                          projects.map((project) => (
                            <div
                              key={project.id}
                              className={`border rounded-lg p-4 cursor-pointer transition-all ${
                                selectedProject?.id === project.id
                                  ? "border-primary bg-primary-light" :"border-gray-200 hover:border-primary hover:bg-gray-50"
                              }`}
                              onClick={() => handleProjectSelect(project)}
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="text-sm font-medium text-gray-900">
                                    {project.title}
                                  </h3>
                                  <p className="mt-1 text-xs text-gray-500">
                                    {project.faculty} • {project.department}
                                  </p>
                                </div>
                                <div
                                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    project.status === "Selected" ?"bg-success-light text-success"
                                      : project.status === "Shortlisted" ?"bg-warning-light text-warning" :"bg-primary-light text-primary"
                                  }`}
                                >
                                  {project.status}
                                </div>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-6">
                            <Icon
                              name="FileText"
                              size={36}
                              className="mx-auto text-gray-300"
                            />
                            <h3 className="mt-2 text-sm font-medium text-gray-900">
                              No projects found
                            </h3>
                            <p className="mt-1 text-sm text-gray-500">
                              You need to apply for projects first.
                            </p>
                            <div className="mt-6">
                              <Link
                                to="/project-search-page"
                                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                              >
                                <Icon name="Search" size={16} className="mr-2" />
                                Browse Projects
                              </Link>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Step 2: Select Time Slot */}
                  <div className={`lg:col-span-2 ${currentStep < 2 ? 'hidden lg:block' : ''}`}>
                    {currentStep >= 2 && selectedFaculty ? (
                      <CalendarView
                        faculty={selectedFaculty}
                        selectedDate={selectedDate}
                        setSelectedDate={setSelectedDate}
                        availabilitySlots={generateAvailabilitySlots(selectedFaculty.id, selectedDate)}
                        selectedTimeSlot={selectedTimeSlot}
                        onTimeSlotSelect={handleTimeSlotSelect}
                      />
                    ) : (
                      <div className="bg-white shadow rounded-lg p-6 h-full flex items-center justify-center">
                        <div className="text-center">
                          <Icon
                            name="Calendar"
                            size={48}
                            className="mx-auto text-gray-300"
                          />
                          <h3 className="mt-2 text-sm font-medium text-gray-900">
                            Select a project first
                          </h3>
                          <p className="mt-1 text-sm text-gray-500">
                            Choose a project to see faculty availability.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Step 3: Meeting Details */}
                  {currentStep === 3 && (
                    <div className="lg:col-span-3">
                      <MeetingDetails
                        faculty={selectedFaculty}
                        project={selectedProject}
                        timeSlot={selectedTimeSlot}
                        selectedDate={selectedDate}
                        meetingAgenda={meetingAgenda}
                        setMeetingAgenda={setMeetingAgenda}
                        onSchedule={handleScheduleMeeting}
                        onBack={() => {
                          setCurrentStep(2);
                          setSelectedTimeSlot(null);
                        }}
                      />
                    </div>
                  )}
                </div>
              )}

              {viewMode === "upcoming" && (
                <UpcomingMeetings meetings={upcomingMeetings} />
              )}

              {viewMode === "history" && (
                <MeetingHistory meetings={meetingHistory} />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default MeetingScheduler;