import React, { useState } from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const CalendarView = ({
  faculty,
  selectedDate,
  setSelectedDate,
  availabilitySlots,
  selectedTimeSlot,
  onTimeSlotSelect,
}) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Calendar navigation
  const nextMonth = () => {
    const nextMonthDate = new Date(currentMonth);
    nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
    setCurrentMonth(nextMonthDate);
  };

  const prevMonth = () => {
    const prevMonthDate = new Date(currentMonth);
    prevMonthDate.setMonth(prevMonthDate.getMonth() - 1);
    setCurrentMonth(prevMonthDate);
  };

  // Format date for display
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    });
  };

  // Generate calendar days
  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    // First day of the month
    const firstDay = new Date(year, month, 1);
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0);
    
    // Get the day of the week for the first day (0 = Sunday, 1 = Monday, etc.)
    const firstDayOfWeek = firstDay.getDay();
    
    // Calculate days from previous month to show
    const daysFromPrevMonth = firstDayOfWeek;
    
    // Calculate total days to show (previous month days + current month days)
    const totalDays = daysFromPrevMonth + lastDay.getDate();
    
    // Calculate rows needed (7 days per row)
    const rows = Math.ceil(totalDays / 7);
    
    const days = [];
    let dayCount = 1 - daysFromPrevMonth;
    
    for (let i = 0; i < rows * 7; i++) {
      const currentDate = new Date(year, month, dayCount);
      const isCurrentMonth = currentDate.getMonth() === month;
      const isToday = new Date().toDateString() === currentDate.toDateString();
      const isSelected = selectedDate.toDateString() === currentDate.toDateString();
      
      days.push({
        date: currentDate,
        dayOfMonth: currentDate.getDate(),
        isCurrentMonth,
        isToday,
        isSelected,
      });
      
      dayCount++;
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();
  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Image
              src={faculty.image}
              alt={faculty.name}
              className="h-12 w-12 rounded-full mr-4"
            />
            <div>
              <h2 className="text-lg font-medium text-gray-900">
                {faculty.name}
              </h2>
              <p className="text-sm text-gray-500">{faculty.department}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-light text-primary">
              <span className="h-2 w-2 rounded-full bg-primary mr-1"></span>
              Available
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
              <span className="h-2 w-2 rounded-full bg-gray-500 mr-1"></span>
              Booked
            </span>
          </div>
        </div>
      </div>

      {/* Calendar */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium text-gray-900">
            {currentMonth.toLocaleDateString("en-US", {
              month: "long",
              year: "numeric",
            })}
          </h3>
          <div className="flex space-x-2">
            <button
              type="button"
              onClick={prevMonth}
              className="inline-flex items-center p-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="ChevronLeft" size={16} />
            </button>
            <button
              type="button"
              onClick={nextMonth}
              className="inline-flex items-center p-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <Icon name="ChevronRight" size={16} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-4">
          {weekDays.map((day) => (
            <div
              key={day}
              className="text-center text-xs font-medium text-gray-500 py-2"
            >
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((day, index) => (
            <button
              key={index}
              onClick={() => setSelectedDate(day.date)}
              disabled={!day.isCurrentMonth}
              className={`
                h-10 w-full rounded-md flex items-center justify-center text-sm
                ${!day.isCurrentMonth ? "text-gray-300" : ""}
                ${day.isToday ? "font-bold" : ""}
                ${
                  day.isSelected
                    ? "bg-primary text-white"
                    : day.isCurrentMonth
                    ? "hover:bg-gray-100" :""
                }
              `}
            >
              {day.dayOfMonth}
            </button>
          ))}
        </div>
      </div>

      {/* Time slots */}
      <div className="p-6 border-t border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Available Time Slots for {formatDate(selectedDate)}
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {availabilitySlots.map((slot) => (
            <button
              key={slot.id}
              onClick={() => slot.status === "available" && onTimeSlotSelect(slot)}
              disabled={slot.status !== "available"}
              className={`
                p-3 border rounded-md text-sm font-medium flex items-center justify-between
                ${
                  selectedTimeSlot?.id === slot.id
                    ? "border-primary bg-primary-light text-primary"
                    : slot.status === "available" ?"border-gray-300 hover:border-primary hover:bg-gray-50" :"border-gray-200 bg-gray-100 text-gray-500 cursor-not-allowed"
                }
              `}
            >
              <span>{slot.time}</span>
              {slot.status === "available" ? (
                <Icon name="Check" size={16} className="text-success" />
              ) : (
                <span className="text-xs text-gray-500">Booked</span>
              )}
            </button>
          ))}
        </div>
        {availabilitySlots.length === 0 && (
          <div className="text-center py-6">
            <Icon
              name="Calendar" 
              size={36}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No available slots
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Try selecting a different date.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarView;