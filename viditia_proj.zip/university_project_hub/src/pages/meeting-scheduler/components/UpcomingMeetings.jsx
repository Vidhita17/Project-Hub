import React from "react";
import Icon from "../../../components/AppIcon";


const UpcomingMeetings = ({ meetings }) => {
  // Format date
  const formatDate = (dateString) => {
    const options = { weekday: "long", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Calculate time remaining
  const getTimeRemaining = (dateString) => {
    const meetingDate = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(meetingDate - now);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays > 1) {
      return `${diffDays} days remaining`;
    } else if (diffDays === 1) {
      return "Tomorrow";
    } else {
      return "Today";
    }
  };

  // Get status badge configuration
  const getStatusConfig = (status) => {
    switch (status) {
      case "confirmed":
        return {
          bgColor: "bg-success-light",
          textColor: "text-success",
          icon: "CheckCircle",
          label: "Confirmed",
        };
      case "pending":
        return {
          bgColor: "bg-warning-light",
          textColor: "text-warning",
          icon: "Clock",
          label: "Pending",
        };
      case "rescheduled":
        return {
          bgColor: "bg-primary-light",
          textColor: "text-primary",
          icon: "RefreshCw",
          label: "Rescheduled",
        };
      default:
        return {
          bgColor: "bg-gray-100",
          textColor: "text-gray-800",
          icon: "Calendar",
          label: status,
        };
    }
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Upcoming Meetings
        </h3>
        <p className="mt-1 text-sm text-gray-500">
          Your scheduled meetings with faculty members.
        </p>
      </div>

      <div className="px-6 py-5">
        {meetings.length > 0 ? (
          <div className="space-y-6">
            {meetings.map((meeting) => {
              const statusConfig = getStatusConfig(meeting.status);
              return (
                <div
                  key={meeting.id}
                  className="bg-gray-50 rounded-lg p-5 border border-gray-200"
                >
                  <div className="sm:flex sm:items-center sm:justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">
                        {meeting.project}
                      </h4>
                      <div className="mt-1 flex items-center">
                        <Icon
                          name="User"
                          size={16}
                          className="text-gray-400 mr-1.5"
                        />
                        <span className="text-sm text-gray-500">
                          {meeting.faculty}
                        </span>
                      </div>
                    </div>
                    <div
                      className={`mt-2 sm:mt-0 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusConfig.bgColor} ${statusConfig.textColor}`}
                    >
                      <Icon name={statusConfig.icon} size={12} className="mr-1" />
                      {statusConfig.label}
                    </div>
                  </div>

                  <div className="mt-4 sm:flex sm:items-center">
                    <div className="sm:flex-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="flex items-center">
                          <Icon
                            name="Calendar"
                            size={16}
                            className="text-gray-400 mr-1.5"
                          />
                          <span className="text-sm text-gray-500">
                            {formatDate(meeting.date)}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Icon
                            name="Clock"
                            size={16}
                            className="text-gray-400 mr-1.5"
                          />
                          <span className="text-sm text-gray-500">
                            {meeting.time}
                          </span>
                        </div>
                      </div>

                      <div className="mt-4 flex items-center">
                        <Icon
                          name={meeting.virtual ? "Video" : "MapPin"}
                          size={16}
                          className="text-gray-400 mr-1.5"
                        />
                        <span className="text-sm text-gray-500">
                          {meeting.location}
                        </span>
                      </div>

                      {meeting.agenda && (
                        <div className="mt-4">
                          <h5 className="text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Agenda
                          </h5>
                          <p className="mt-1 text-sm text-gray-500">
                            {meeting.agenda}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="mt-4 sm:mt-0 sm:ml-6 sm:flex-shrink-0 flex flex-col items-center">
                      <div className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs font-medium text-gray-700">
                        {getTimeRemaining(meeting.date)}
                      </div>
                      <div className="mt-3 flex space-x-2">
                        {meeting.virtual && meeting.meetingLink && (
                          <a
                            href={meeting.meetingLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                          >
                            <Icon name="Video" size={12} className="mr-1" />
                            Join
                          </a>
                        )}
                        <button
                          type="button"
                          className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                        >
                          <Icon name="Calendar" size={12} className="mr-1" />
                          Add
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Icon
              name="Calendar"
              size={48}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No upcoming meetings
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              You don't have any scheduled meetings yet.
            </p>
            <div className="mt-6">
              <button
                type="button"
                onClick={() => {}}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <Icon name="Plus" size={16} className="mr-2" />
                Schedule a Meeting
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UpcomingMeetings;