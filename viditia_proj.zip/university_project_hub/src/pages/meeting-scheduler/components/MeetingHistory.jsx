import React, { useState } from "react";
import Icon from "../../../components/AppIcon";

const MeetingHistory = ({ meetings }) => {
  const [expandedMeetingId, setExpandedMeetingId] = useState(null);

  // Format date
  const formatDate = (dateString) => {
    const options = { weekday: "short", month: "short", day: "numeric", year: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Get status badge configuration
  const getStatusConfig = (status) => {
    switch (status) {
      case "completed":
        return {
          bgColor: "bg-success-light",
          textColor: "text-success",
          icon: "CheckCircle",
          label: "Completed",
        };
      case "cancelled":
        return {
          bgColor: "bg-error-light",
          textColor: "text-error",
          icon: "XCircle",
          label: "Cancelled",
        };
      case "missed":
        return {
          bgColor: "bg-warning-light",
          textColor: "text-warning",
          icon: "AlertTriangle",
          label: "Missed",
        };
      default:
        return {
          bgColor: "bg-gray-100",
          textColor: "text-gray-800",
          icon: "Calendar",
          label: status,
        };
    }
  };

  const toggleExpand = (meetingId) => {
    if (expandedMeetingId === meetingId) {
      setExpandedMeetingId(null);
    } else {
      setExpandedMeetingId(meetingId);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">
          Meeting History
        </h3>
        <p className="mt-1 text-sm text-gray-500">
          Your past meetings with faculty members.
        </p>
      </div>

      <div className="px-6 py-5">
        {meetings.length > 0 ? (
          <div className="space-y-4">
            {meetings.map((meeting) => {
              const statusConfig = getStatusConfig(meeting.status);
              const isExpanded = expandedMeetingId === meeting.id;
              
              return (
                <div
                  key={meeting.id}
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <div 
                    className="p-4 bg-gray-50 flex items-center justify-between cursor-pointer"
                    onClick={() => toggleExpand(meeting.id)}
                  >
                    <div className="flex items-center">
                      <div
                        className={`flex-shrink-0 rounded-md p-2 ${statusConfig.bgColor}`}
                      >
                        <Icon
                          name={statusConfig.icon}
                          size={16}
                          className={statusConfig.textColor}
                        />
                      </div>
                      <div className="ml-3">
                        <h4 className="text-sm font-medium text-gray-900">
                          {meeting.project}
                        </h4>
                        <div className="mt-1 flex items-center text-xs text-gray-500">
                          <span>{formatDate(meeting.date)}</span>
                          <span className="mx-1">•</span>
                          <span>{meeting.time}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusConfig.bgColor} ${statusConfig.textColor} mr-2`}
                      >
                        {statusConfig.label}
                      </span>
                      <Icon
                        name={isExpanded ? "ChevronUp" : "ChevronDown"}
                        size={16}
                        className="text-gray-400"
                      />
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="p-4 border-t border-gray-200">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h5 className="text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Faculty
                          </h5>
                          <p className="mt-1 text-sm text-gray-900">
                            {meeting.faculty}
                          </p>
                        </div>
                        <div>
                          <h5 className="text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Location
                          </h5>
                          <p className="mt-1 text-sm text-gray-900">
                            {meeting.location}
                            {meeting.virtual && " (Virtual)"}
                          </p>
                        </div>
                      </div>

                      {meeting.notes && (
                        <div className="mt-4">
                          <h5 className="text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Meeting Notes
                          </h5>
                          <p className="mt-1 text-sm text-gray-500">
                            {meeting.notes}
                          </p>
                        </div>
                      )}

                      {meeting.cancellationReason && (
                        <div className="mt-4">
                          <h5 className="text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Cancellation Reason
                          </h5>
                          <p className="mt-1 text-sm text-gray-500">
                            {meeting.cancellationReason}
                          </p>
                        </div>
                      )}

                      <div className="mt-4 flex justify-end">
                        <button
                          type="button"
                          className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                        >
                          <Icon name="Calendar" size={14} className="mr-1.5" />
                          Schedule Follow-up
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Icon
              name="History"
              size={48}
              className="mx-auto text-gray-300"
            />
            <h3 className="mt-2 text-sm font-medium text-gray-900">
              No meeting history
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Your past meetings will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MeetingHistory;