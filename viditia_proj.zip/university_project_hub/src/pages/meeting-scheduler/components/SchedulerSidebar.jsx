import React from "react";
import { Link } from "react-router-dom";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const SchedulerSidebar = ({ userData }) => {
  return (
    <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
      <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200">
        <div className="flex items-center flex-shrink-0 px-4">
          <Link to="/landing-page" className="flex items-center">
            <Icon name="Graduation" size={32} className="text-primary" />
            <span className="ml-2 text-xl font-semibold text-gray-900">
              Project Hub
            </span>
          </Link>
        </div>
        <div className="mt-8 flex flex-col items-center">
          <div className="relative w-24 h-24 mb-4">
            <Image
              src={userData.profileImage}
              alt={userData.name}
              className="rounded-full object-cover w-full h-full border-2 border-primary"
            />
            <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1">
              <Link to="/student-profile">
                <Icon name="Edit" size={16} className="text-white" />
              </Link>
            </div>
          </div>
          <h2 className="text-lg font-semibold text-gray-900">{userData.name}</h2>
          <p className="text-sm text-gray-500">{userData.department}</p>
          <p className="text-sm text-gray-500">{userData.semester}</p>
        </div>
        <div className="mt-8 flex-grow">
          <nav className="px-2 space-y-1">
            <Link
              to="/student-dashboard"
              className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="LayoutDashboard" size={20} className="mr-3" />
              Dashboard
            </Link>
            <Link
              to="/meeting-scheduler"
              className="flex items-center px-4 py-3 text-sm font-medium text-white bg-primary rounded-md"
            >
              <Icon name="Calendar" size={20} className="mr-3" />
              Meeting Scheduler
            </Link>
            <Link
              to="/student-profile"
              className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="User" size={20} className="mr-3" />
              Profile
            </Link>
            <Link
              to="/project-search-page"
              className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
            >
              <Icon name="Search" size={20} className="mr-3" />
              Browse Projects
            </Link>
            <div className="px-4 py-3">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                External Profiles
              </h3>
              <div className="mt-2 space-y-2">
                {userData.githubLink && (
                  <a
                    href={userData.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                  >
                    <Icon name="Github" size={18} className="mr-3" />
                    GitHub
                  </a>
                )}
                {userData.linkedinLink && (
                  <a
                    href={userData.linkedinLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
                  >
                    <Icon name="Linkedin" size={18} className="mr-3" />
                    LinkedIn
                  </a>
                )}
              </div>
            </div>
          </nav>
        </div>
        <div className="flex-shrink-0 p-4 border-t border-gray-200">
          <Link
            to="/authentication-page"
            className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md"
          >
            <Icon name="LogOut" size={20} className="mr-3" />
            Log out
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SchedulerSidebar;