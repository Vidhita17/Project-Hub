import React from "react";
import Icon from "../../../components/AppIcon";
import Image from "../../../components/AppImage";

const MeetingDetails = ({
  faculty,
  project,
  timeSlot,
  selectedDate,
  meetingAgenda,
  setMeetingAgenda,
  onSchedule,
  onBack,
}) => {
  // Format date for display
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">
          Meeting Details
        </h2>
        <p className="mt-1 text-sm text-gray-500">
          Review and confirm your meeting details.
        </p>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-2">
              Faculty Information
            </h3>
            <div className="flex items-center p-4 bg-gray-50 rounded-lg">
              <Image
                src={faculty.image}
                alt={faculty.name}
                className="h-12 w-12 rounded-full mr-4"
              />
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {faculty.name}
                </p>
                <p className="text-sm text-gray-500">{faculty.department}</p>
                <div className="mt-1 flex flex-wrap gap-1">
                  {faculty.expertise.map((skill, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-2">
              Project Information
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm font-medium text-gray-900">
                {project.title}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                {project.department}
              </p>
              <div className="mt-2">
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    project.status === "Selected" ?"bg-success-light text-success"
                      : project.status === "Shortlisted" ?"bg-warning-light text-warning" :"bg-primary-light text-primary"
                  }`}
                >
                  {project.status}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-900 mb-2">
            Meeting Schedule
          </h3>
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Icon name="Calendar" size={20} className="text-gray-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">
                  {formatDate(selectedDate)}
                </p>
              </div>
            </div>
            <div className="flex items-center mt-3">
              <div className="flex-shrink-0">
                <Icon name="Clock" size={20} className="text-gray-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">
                  {timeSlot.time}
                </p>
              </div>
            </div>
            <div className="flex items-center mt-3">
              <div className="flex-shrink-0">
                <Icon name="MapPin" size={20} className="text-gray-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">
                  Room 302, Computer Science Building
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  (Default location, will be confirmed by faculty)
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <label
            htmlFor="meeting-agenda"
            className="block text-sm font-medium text-gray-900 mb-2"
          >
            Meeting Agenda
          </label>
          <div className="mt-1">
            <textarea
              id="meeting-agenda"
              name="meeting-agenda"
              rows={4}
              className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="Briefly describe what you'd like to discuss in this meeting..."
              value={meetingAgenda}
              onChange={(e) => setMeetingAgenda(e.target.value)}
            />
          </div>
          <p className="mt-2 text-sm text-gray-500">
            A clear agenda helps the faculty prepare for the meeting.
          </p>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <Icon name="ArrowLeft" size={16} className="mr-2" />
            Back
          </button>
          <button
            type="button"
            onClick={onSchedule}
            disabled={!meetingAgenda.trim()}
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
              meetingAgenda.trim()
                ? "bg-primary hover:bg-primary-dark" :"bg-gray-300 cursor-not-allowed"
            } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary`}
          >
            <Icon name="Calendar" size={16} className="mr-2" />
            Schedule Meeting
          </button>
        </div>
      </div>
    </div>
  );
};

export default MeetingDetails;