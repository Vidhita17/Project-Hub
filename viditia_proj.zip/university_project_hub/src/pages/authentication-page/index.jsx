import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Icon from "../../components/AppIcon";

import LoginForm from "./components/LoginForm";
import SignupForm from "./components/SignupForm";
import RoleSelector from "./components/RoleSelector";
import AuthFooter from "./components/AuthFooter";

const AuthenticationPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("login");
  const [selectedRole, setSelectedRole] = useState("student");

  // Mock statistics for social proof
  const statistics = {
    totalStudents: "5,200+",
    totalFaculty: "320+",
    totalProjects: "1,450+",
    successRate: "92%",
  };

  const handleLogin = (credentials) => {
    console.log("Login credentials:", credentials);
    // In a real app, this would validate credentials with an API
    
    // Mock credentials for demo purposes
    if (
      (credentials.email === "student@university.edu" && 
       credentials.password === "Student123" && 
       selectedRole === "student") ||
      (credentials.email === "faculty@university.edu" && 
       credentials.password === "Faculty123" && 
       selectedRole === "faculty")
    ) {
      // Navigate based on role
      if (selectedRole === "student") {
        navigate("/student-dashboard");
      } else {
        navigate("/faculty-dashboard");
      }
    } else {
      // This would show an error message in a real app
      alert("Invalid credentials. Please try again.");
    }
  };

  const handleSignup = (userData) => {
    console.log("Signup data:", userData);
    // In a real app, this would register the user via an API
    
    // For demo purposes, simulate successful registration
    alert(`Account created successfully! Please log in.`);
    setActiveTab("login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Link to="/landing-page" className="flex items-center">
            <Icon name="Graduation" size={40} className="text-primary" />
            <span className="ml-2 text-2xl font-semibold text-gray-900">
              Project Hub
            </span>
          </Link>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          {activeTab === "login" ? "Sign in to your account" : "Create a new account"}
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          {activeTab === "login" ? (
            <>
              Or{" "}
              <button
                onClick={() => setActiveTab("signup")}
                className="font-medium text-primary hover:text-primary-dark focus:outline-none focus:underline transition ease-in-out duration-150"
              >
                create a new account
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button
                onClick={() => setActiveTab("login")}
                className="font-medium text-primary hover:text-primary-dark focus:outline-none focus:underline transition ease-in-out duration-150"
              >
                Sign in
              </button>
            </>
          )}
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {/* Role selector */}
          <RoleSelector selectedRole={selectedRole} setSelectedRole={setSelectedRole} />

          {/* Tab content */}
          <div className="mt-6">
            {activeTab === "login" ? (
              <LoginForm onSubmit={handleLogin} selectedRole={selectedRole} />
            ) : (
              <SignupForm onSubmit={handleSignup} selectedRole={selectedRole} />
            )}
          </div>

          {/* Divider */}
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  Or continue with
                </span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
              <div>
                <button
                  type="button"
                  className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Github" size={20} className="mr-2" />
                  <span>GitHub</span>
                </button>
              </div>
              <div>
                <button
                  type="button"
                  className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Icon name="Linkedin" size={20} className="mr-2" />
                  <span>LinkedIn</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Social proof section */}
        <AuthFooter statistics={statistics} />
      </div>
    </div>
  );
};

export default AuthenticationPage;