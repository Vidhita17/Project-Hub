import React from "react";
import Icon from "../../../components/AppIcon";

const RoleSelector = ({ selectedRole, setSelectedRole }) => {
  return (
    <div className="mb-6">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        I am a:
      </label>
      <div className="grid grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => setSelectedRole("student")}
          className={`relative flex items-center justify-center px-4 py-3 border ${
            selectedRole === "student" ?"bg-primary-light border-primary" :"border-gray-300 hover:bg-gray-50"
          } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary`}
        >
          <div className="flex flex-col items-center">
            <Icon
              name="GraduationCap"
              size={24}
              className={selectedRole === "student" ? "text-primary" : "text-gray-500"}
            />
            <span
              className={`mt-1 text-sm font-medium ${
                selectedRole === "student" ? "text-primary" : "text-gray-700"
              }`}
            >
              Student
            </span>
          </div>
          {selectedRole === "student" && (
            <div className="absolute top-2 right-2">
              <Icon name="CheckCircle" size={16} className="text-primary" />
            </div>
          )}
        </button>

        <button
          type="button"
          onClick={() => setSelectedRole("faculty")}
          className={`relative flex items-center justify-center px-4 py-3 border ${
            selectedRole === "faculty" ?"bg-primary-light border-primary" :"border-gray-300 hover:bg-gray-50"
          } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary`}
        >
          <div className="flex flex-col items-center">
            <Icon
              name="BookOpen"
              size={24}
              className={selectedRole === "faculty" ? "text-primary" : "text-gray-500"}
            />
            <span
              className={`mt-1 text-sm font-medium ${
                selectedRole === "faculty" ? "text-primary" : "text-gray-700"
              }`}
            >
              Faculty
            </span>
          </div>
          {selectedRole === "faculty" && (
            <div className="absolute top-2 right-2">
              <Icon name="CheckCircle" size={16} className="text-primary" />
            </div>
          )}
        </button>
      </div>
    </div>
  );
};

export default RoleSelector;