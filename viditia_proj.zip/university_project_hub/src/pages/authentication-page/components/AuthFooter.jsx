import React from "react";
import Icon from "../../../components/AppIcon";

const AuthFooter = ({ statistics }) => {
  const currentYear = new Date().getFullYear();
  
  return (
    <div className="mt-8">
      {/* Social proof statistics */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-center text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">
            Join our growing community
          </h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div className="text-center">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-light text-primary mx-auto">
                <Icon name="Users" size={24} />
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-900">{statistics.totalStudents}</p>
              <p className="text-sm text-gray-500">Students</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-light text-primary mx-auto">
                <Icon name="BookOpen" size={24} />
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-900">{statistics.totalFaculty}</p>
              <p className="text-sm text-gray-500">Faculty</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-light text-primary mx-auto">
                <Icon name="Briefcase" size={24} />
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-900">{statistics.totalProjects}</p>
              <p className="text-sm text-gray-500">Projects</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-light text-primary mx-auto">
                <Icon name="TrendingUp" size={24} />
              </div>
              <p className="mt-2 text-lg font-semibold text-gray-900">{statistics.successRate}</p>
              <p className="text-sm text-gray-500">Success Rate</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer links */}
      <div className="mt-8 text-center">
        <p className="text-xs text-gray-500">
          &copy; {currentYear} Project Hub. All rights reserved.
        </p>
        <div className="mt-2 flex justify-center space-x-4">
          <a href="#" className="text-xs text-gray-500 hover:text-gray-700">
            Privacy Policy
          </a>
          <a href="#" className="text-xs text-gray-500 hover:text-gray-700">
            Terms of Service
          </a>
          <a href="#" className="text-xs text-gray-500 hover:text-gray-700">
            Contact Us
          </a>
        </div>
      </div>
    </div>
  );
};

export default AuthFooter;