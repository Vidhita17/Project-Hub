/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html",
  ],
  theme: {
    extend: {
      colors: {
        // Primary colors
        primary: {
          DEFAULT: '#2563EB', // blue-600
          light: '#DBEAFE',   // blue-100
          dark: '#1E40AF',    // blue-800
          100: '#DBEAFE',     // blue-100
          200: '#BFDBFE',     // blue-200
          300: '#93C5FD',     // blue-300
          400: '#60A5FA',     // blue-400
          500: '#3B82F6',     // blue-500
          600: '#2563EB',     // blue-600
          700: '#1D4ED8',     // blue-700
          800: '#1E40AF',     // blue-800
          900: '#1E3A8A',     // blue-900
        },
        // Neutral colors
        white: '#FFFFFF',     // white
        gray: {
          50: '#F9FAFB',      // gray-50
          100: '#F3F4F6',     // gray-100
          200: '#E5E7EB',     // gray-200
          300: '#D1D5DB',     // gray-300
          500: '#6B7280',     // gray-500
          700: '#374151',     // gray-700
          900: '#111827',     // gray-900
        },
        // Semantic colors
        success: {
          DEFAULT: '#16A34A', // green-600
          light: '#DCFCE7',   // green-100
        },
        warning: {
          DEFAULT: '#F59E0B', // amber-500
          light: '#FEF3C7',   // amber-100
        },
        error: {
          DEFAULT: '#DC2626', // red-600
          light: '#FEE2E2',   // red-100
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
        display: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'Consolas', 'Liberation Mono', 'Courier New', 'monospace'],
      },
      fontSize: {
        'xs': ['12px', { lineHeight: '16px' }],
        'sm': ['14px', { lineHeight: '20px' }],
        'base': ['16px', { lineHeight: '24px' }],
        'lg': ['18px', { lineHeight: '28px' }],
        'xl': ['20px', { lineHeight: '28px' }],
        '2xl': ['24px', { lineHeight: '32px' }],
        '3xl': ['30px', { lineHeight: '36px' }],
        '4xl': ['36px', { lineHeight: '40px' }],
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('tailwindcss-animate'),
  ],
}